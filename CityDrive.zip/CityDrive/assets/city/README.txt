Put city model (glb/gltf) here
