extends Node3D

# ================= تنظیمات (اینجا را تغییر بدهید) =================
const CITY_DIR := "res://assets/city/"
const CARS_DIR := "res://assets/cars/"
const MODEL_EXTS := ["glb", "gltf", "scn", "tscn", "fbx", "obj", "dae"]
const MAP_GAP := 80.0            # فاصله بین مپ‌ها (متر) که با جاده وصل می‌شود
const ROAD_WIDTH := 16.0
const CITY_SCALE := 1.0          # اگر شهر خیلی بزرگ/کوچک بود
const CAR_SCALE := 1.0           # اگر ماشین خیلی بزرگ/کوچک بود
const CAR_YAW_DEG := 0.0         # اگر ماشین کج یا برعکس بود: 90 / 180 / -90
const CAR_MASS := 900.0
const ENGINE_POWER := 2600.0
const MAX_STEER := 0.5
const SPAWN_POS := Vector3(0, 2.5, 0)

var car: VehicleBody3D
var cam: Camera3D
var car_files: Array = []
var car_index := 0
var cam_dist := 8.0
var steer_angle := 0.0
var fingers := {}
var btns := {}
var speed_label: Label
var maps: Array = []
var map_index := 0


func _ready() -> void:
	_setup_environment()
	_load_city()
	cam = Camera3D.new()
	cam.far = 1500.0
	add_child(cam)
	cam.current = true
	car_files = _list_models(CARS_DIR)
	await get_tree().physics_frame
	await get_tree().physics_frame
	_goto_map(0)
	_build_ui()


# ---------------------------------------------------------------- محیط
func _setup_environment() -> void:
	var env := Environment.new()
	var sky := Sky.new()
	sky.sky_material = ProceduralSkyMaterial.new()
	env.background_mode = Environment.BG_SKY
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
	var we := WorldEnvironment.new()
	we.environment = env
	add_child(we)
	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-55, 35, 0)
	sun.shadow_enabled = true
	sun.directional_shadow_max_distance = 120.0
	add_child(sun)


func _list_models(dir_path: String) -> Array:
	var out: Array = []
	var d := DirAccess.open(dir_path)
	if d == null:
		return out
	for f in d.get_files():
		# در APK فایل‌ها به شکل .import / .remap دیده می‌شوند
		var n: String = f.trim_suffix(".import").trim_suffix(".remap")
		var full := dir_path + n
		if n.get_extension().to_lower() in MODEL_EXTS and not out.has(full):
			out.append(full)
	for sub in d.get_directories():
		for p in _list_models(dir_path + sub + "/"):
			if not out.has(p):
				out.append(p)
	out.sort()
	return out


# ---------------------------------------------------------------- شهر
func _load_city() -> void:
	# هر زیرپوشه در assets/city یک مپ است (همه فایل‌های داخلش با هم یک مپ می‌شوند)
	var groups := {}
	for p in _list_models(CITY_DIR):
		var rel: String = p.trim_prefix(CITY_DIR)
		var key: String = rel.get_slice("/", 0) if "/" in rel else "_root"
		if not groups.has(key):
			groups[key] = []
		groups[key].append(p)
	if groups.is_empty():
		_make_placeholder_city()
		return
	var cursor := 0.0
	var keys: Array = groups.keys()
	keys.sort()
	for key in keys:
		var root := Node3D.new()
		root.name = "Map_" + str(key)
		root.scale = Vector3.ONE * CITY_SCALE
		add_child(root)
		for p in groups[key]:
			var res = load(p)
			if res is PackedScene:
				root.add_child(res.instantiate())
		_add_collisions(root)
		var a := _node_aabb(root)
		if a.size == Vector3.ZERO:
			continue
		# مپ را کنار مپ قبلی بچین: کف روی y=0 و وسط روی z=0
		var off := Vector3(cursor - a.position.x, -a.position.y, -a.get_center().z)
		root.global_position += off
		a.position += off
		if maps.size() > 0:
			_make_connector(cursor - MAP_GAP, cursor)
		maps.append({"name": str(key), "aabb": a})
		cursor += a.size.x + MAP_GAP
	if maps.is_empty():
		_make_placeholder_city()


func _node_aabb(n: Node) -> AABB:
	var meshes: Array = []
	_collect_meshes(n, meshes)
	var result := AABB()
	var first := true
	for m in meshes:
		var mi := m as MeshInstance3D
		var a: AABB = mi.global_transform * mi.get_aabb()
		if first:
			result = a
			first = false
		else:
			result = result.merge(a)
	return result


func _make_connector(x0: float, x1: float) -> void:
	var b := StaticBody3D.new()
	var sh := BoxShape3D.new()
	sh.size = Vector3(x1 - x0 + 4.0, 0.4, ROAD_WIDTH)
	var cs := CollisionShape3D.new()
	cs.shape = sh
	b.add_child(cs)
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = sh.size
	mi.mesh = bm
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color(0.15, 0.15, 0.17)
	mi.material_override = mat
	b.add_child(mi)
	b.position = Vector3((x0 + x1) * 0.5, -0.2, 0)
	add_child(b)


func _add_collisions(n: Node) -> void:
	var meshes: Array = []
	_collect_meshes(n, meshes)
	for m in meshes:
		(m as MeshInstance3D).create_trimesh_collision()


func _collect_meshes(n: Node, out: Array) -> void:
	if n is MeshInstance3D and n.mesh != null:
		out.append(n)
	for c in n.get_children():
		_collect_meshes(c, out)


func _make_placeholder_city() -> void:
	var ground := StaticBody3D.new()
	var cs := CollisionShape3D.new()
	var bs := BoxShape3D.new()
	bs.size = Vector3(1200, 2, 1200)
	cs.shape = bs
	cs.position.y = -1.0
	ground.add_child(cs)
	var mi := MeshInstance3D.new()
	var pm := PlaneMesh.new()
	pm.size = Vector2(1200, 1200)
	mi.mesh = pm
	var gm := StandardMaterial3D.new()
	gm.albedo_color = Color(0.2, 0.2, 0.22)
	mi.material_override = gm
	ground.add_child(mi)
	add_child(ground)
	maps.append({"name": "demo", "aabb": AABB(Vector3(-300, 0, -300), Vector3(600, 60, 600))})
	var rng := RandomNumberGenerator.new()
	rng.seed = 7
	for x in range(-6, 6):
		for z in range(-6, 6):
			var h := rng.randf_range(8.0, 60.0)
			var b := StaticBody3D.new()
			var bc := CollisionShape3D.new()
			var sh := BoxShape3D.new()
			sh.size = Vector3(30, h, 30)
			bc.shape = sh
			b.add_child(bc)
			var bm := MeshInstance3D.new()
			var box := BoxMesh.new()
			box.size = sh.size
			bm.mesh = box
			var mat := StandardMaterial3D.new()
			var g := rng.randf_range(0.4, 0.8)
			mat.albedo_color = Color(g, g, g + 0.05)
			bm.material_override = mat
			b.add_child(bm)
			b.position = Vector3(x * 50 + 25, h * 0.5, z * 50 + 25)
			add_child(b)


# ---------------------------------------------------------------- ماشین
func _spawn_car(t: Transform3D) -> void:
	if car != null:
		car.queue_free()
	car = VehicleBody3D.new()
	car.mass = CAR_MASS
	car.center_of_mass_mode = RigidBody3D.CENTER_OF_MASS_MODE_CUSTOM
	car.angular_damp = 1.0
	add_child(car)
	car.global_transform = t

	var model: Node3D = null
	if car_files.size() > 0:
		var res = load(car_files[car_index])
		if res is PackedScene:
			model = res.instantiate()
	if model == null:
		model = _make_box_car()

	var holder := Node3D.new()
	holder.rotation_degrees.y = CAR_YAW_DEG
	holder.scale = Vector3.ONE * CAR_SCALE
	car.add_child(holder)
	holder.add_child(model)

	# ابعاد مدل را حساب کن و مدل را وسط/روی زمین قرار بده
	var aabb := _model_aabb(holder)
	var off := -Vector3(aabb.get_center().x, aabb.position.y, aabb.get_center().z)
	holder.position = off
	aabb.position += off
	var size := aabb.size

	# بدنه برخوردی
	var box_h := size.y * 0.65
	var cs := CollisionShape3D.new()
	var bs := BoxShape3D.new()
	bs.size = Vector3(size.x * 0.95, box_h, size.z * 0.95)
	cs.shape = bs
	cs.position = Vector3(0, size.y * 0.35 + box_h * 0.5, 0)
	car.add_child(cs)
	car.center_of_mass = Vector3(0, size.y * 0.25, 0)

	# چرخ‌ها (خودکار با اندازه مدل)
	var r := clampf(size.y * 0.25, 0.2, 0.6)
	var rest := 0.2
	var hx := size.x * 0.5 * 0.88
	var hz := size.z * 0.32
	for i in 4:
		var front := i < 2
		var w := VehicleWheel3D.new()
		var sx := -1.0 if i % 2 == 0 else 1.0
		var sz := -1.0 if front else 1.0
		w.position = Vector3(hx * sx, r + rest, hz * sz)
		w.use_as_steering = front
		w.use_as_traction = true
		w.wheel_radius = r
		w.wheel_rest_length = rest
		w.suspension_travel = 0.3
		w.suspension_stiffness = 45.0
		w.suspension_max_force = 9000.0
		w.wheel_friction_slip = 3.0 if front else 2.6
		w.wheel_roll_influence = 0.3
		car.add_child(w)

	cam_dist = maxf(6.0, size.z * 1.7)
	var back := car.global_transform.basis.z
	back.y = 0.0
	cam.global_position = car.global_position + back.normalized() * cam_dist + Vector3.UP * (size.y + 2.0)


func _model_aabb(holder: Node3D) -> AABB:
	var meshes: Array = []
	_collect_meshes(holder, meshes)
	if meshes.is_empty():
		return AABB(Vector3(-1, 0, -2), Vector3(2, 1.2, 4))
	var inv := car.global_transform.affine_inverse()
	var result := AABB()
	var first := true
	for m in meshes:
		var mi := m as MeshInstance3D
		var a: AABB = (inv * mi.global_transform) * mi.get_aabb()
		if first:
			result = a
			first = false
		else:
			result = result.merge(a)
	return result


func _make_box_car() -> Node3D:
	var n := Node3D.new()
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color(0.8, 0.1, 0.1)
	var body := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = Vector3(1.8, 0.6, 4.0)
	body.mesh = bm
	body.material_override = mat
	body.position.y = 0.6
	n.add_child(body)
	var cabin := MeshInstance3D.new()
	var cm := BoxMesh.new()
	cm.size = Vector3(1.5, 0.5, 2.0)
	cabin.mesh = cm
	cabin.material_override = mat
	cabin.position = Vector3(0, 1.15, 0.2)
	n.add_child(cabin)
	return n


func _next_car() -> void:
	if car_files.size() > 1:
		car_index = (car_index + 1) % car_files.size()
	var t := Transform3D(Basis(Vector3.UP, car.global_rotation.y), car.global_position + Vector3.UP * 1.0)
	_spawn_car(t)


func _reset_car() -> void:
	_goto_map(map_index)


func _next_map() -> void:
	_goto_map(map_index + 1)


func _goto_map(i: int) -> void:
	if maps.is_empty():
		_spawn_car(Transform3D(Basis(), SPAWN_POS))
		return
	map_index = posmod(i, maps.size())
	var a: AABB = maps[map_index]["aabb"]
	var c := a.get_center()
	var best := Vector3(c.x, a.end.y + 3.0, c.z)
	var space := get_world_3d().direct_space_state
	# دنبال نقطه‌ای در سطح زمین (جاده/خیابان) نزدیک وسط مپ بگرد
	for k in 400:
		var rad := 10.0 * sqrt(float(k))
		var x := c.x + cos(k * 0.8) * rad
		var z := c.z + sin(k * 0.8) * rad
		if x < a.position.x or x > a.end.x or z < a.position.z or z > a.end.z:
			continue
		var q := PhysicsRayQueryParameters3D.create(Vector3(x, a.end.y + 20.0, z), Vector3(x, a.position.y - 20.0, z))
		var hit := space.intersect_ray(q)
		if not hit.is_empty() and hit.position.y <= a.position.y + 2.0:
			best = hit.position + Vector3(0, 1.5, 0)
			break
	_spawn_car(Transform3D(Basis(), best))


# ---------------------------------------------------------------- فیزیک
func _physics_process(delta: float) -> void:
	if car == null:
		return
	var thr := _held("gas") or Input.is_key_pressed(KEY_UP) or Input.is_key_pressed(KEY_W)
	var brk := _held("brake") or Input.is_key_pressed(KEY_DOWN) or Input.is_key_pressed(KEY_S)
	var st := 0.0
	if _held("left") or Input.is_key_pressed(KEY_LEFT) or Input.is_key_pressed(KEY_A):
		st += 1.0
	if _held("right") or Input.is_key_pressed(KEY_RIGHT) or Input.is_key_pressed(KEY_D):
		st -= 1.0

	var fwd := -car.global_transform.basis.z
	var spd := car.linear_velocity.dot(fwd)
	var kmh := absf(spd) * 3.6

	car.engine_force = 0.0
	car.brake = 0.0
	if thr:
		car.engine_force = ENGINE_POWER
	if brk:
		if spd > 1.0:
			car.brake = 25.0
		else:
			car.engine_force = -ENGINE_POWER * 0.6
	if not thr and not brk:
		car.brake = 1.5

	var max_s := MAX_STEER / (1.0 + kmh / 60.0)
	steer_angle = move_toward(steer_angle, st * max_s, delta * 2.0)
	car.steering = steer_angle

	# دوربین
	var back := car.global_transform.basis.z
	back.y = 0.0
	back = back.normalized()
	var target := car.global_position + back * cam_dist + Vector3.UP * 3.0
	cam.global_position = cam.global_position.lerp(target, 1.0 - exp(-6.0 * delta))
	cam.look_at(car.global_position + Vector3.UP * 1.0, Vector3.UP)

	if car.global_position.y < -100.0:
		_reset_car()

	speed_label.text = "%d km/h" % int(kmh)


# ---------------------------------------------------------------- رابط کاربری و لمس
func _build_ui() -> void:
	var layer := CanvasLayer.new()
	add_child(layer)
	var root := Control.new()
	root.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	layer.add_child(root)

	speed_label = Label.new()
	speed_label.position = Vector2(30, 20)
	speed_label.add_theme_font_size_override("font_size", 44)
	root.add_child(speed_label)

	_add_btn(root, "left", "<", Vector2(0, 1), Vector2(40, -240), Vector2(200, 200))
	_add_btn(root, "right", ">", Vector2(0, 1), Vector2(260, -240), Vector2(200, 200))
	_add_btn(root, "brake", "BRAKE", Vector2(1, 1), Vector2(-500, -240), Vector2(220, 200))
	_add_btn(root, "gas", "GAS", Vector2(1, 1), Vector2(-260, -300), Vector2(220, 260))
	_add_btn(root, "map", "MAP", Vector2(1, 0), Vector2(-670, 20), Vector2(200, 90))
	_add_btn(root, "car", "CAR", Vector2(1, 0), Vector2(-450, 20), Vector2(200, 90))
	_add_btn(root, "reset", "RESET", Vector2(1, 0), Vector2(-230, 20), Vector2(200, 90))


func _add_btn(parent: Control, id: String, text: String, anchor: Vector2, offset: Vector2, size: Vector2) -> void:
	var p := Panel.new()
	p.mouse_filter = Control.MOUSE_FILTER_IGNORE
	p.anchor_left = anchor.x
	p.anchor_right = anchor.x
	p.anchor_top = anchor.y
	p.anchor_bottom = anchor.y
	p.offset_left = offset.x
	p.offset_top = offset.y
	p.offset_right = offset.x + size.x
	p.offset_bottom = offset.y + size.y
	var l := Label.new()
	l.text = text
	l.set_anchors_preset(Control.PRESET_FULL_RECT)
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	l.add_theme_font_size_override("font_size", 36)
	p.add_child(l)
	p.modulate = Color(1, 1, 1, 0.5)
	parent.add_child(p)
	btns[id] = p


func _held(id: String) -> bool:
	if not btns.has(id):
		return false
	var rect: Rect2 = (btns[id] as Control).get_global_rect()
	for pos in fingers.values():
		if rect.has_point(pos):
			return true
	return false


func _process(_delta: float) -> void:
	for id in ["gas", "brake", "left", "right"]:
		if btns.has(id):
			(btns[id] as Control).modulate.a = 0.9 if _held(id) else 0.5


func _input(e: InputEvent) -> void:
	var t := e as InputEventScreenTouch
	if t != null:
		if t.pressed:
			fingers[t.index] = t.position
			_tap(t.position)
		else:
			fingers.erase(t.index)
		return
	var d := e as InputEventScreenDrag
	if d != null:
		fingers[d.index] = d.position
		return
	var k := e as InputEventKey
	if k != null and k.pressed and not k.echo:
		if k.keycode == KEY_C:
			_next_car()
		elif k.keycode == KEY_R:
			_reset_car()
		elif k.keycode == KEY_M:
			_next_map()


func _tap(pos: Vector2) -> void:
	if btns.has("car") and (btns["car"] as Control).get_global_rect().has_point(pos):
		_next_car()
	elif btns.has("map") and (btns["map"] as Control).get_global_rect().has_point(pos):
		_next_map()
	elif btns.has("reset") and (btns["reset"] as Control).get_global_rect().has_point(pos):
		_reset_car()
