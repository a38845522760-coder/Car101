from __future__ import annotations

from pathlib import Path
import re
import sys
import json

ROOT = Path(__file__).resolve().parents[1]
REQUIRED_FILES = (
    "project.godot",
    "scenes/menus/main_menu.tscn",
    "scenes/core/game_world_root.tscn",
    "scenes/worlds/phase2_test_world.tscn",
    "scenes/worlds/city_world.tscn",
    "scenes/vehicles/player_car.tscn",
    "scripts/ui/main_menu.gd",
    "scripts/ui/driving_hud.gd",
    "scripts/vehicles/car_controller.gd",
    "scripts/camera/camera_follow.gd",
    "scripts/camera/foot_camera_follow.gd",
    "scripts/characters/player_character.gd",
    "scenes/characters/player_character.tscn",
    "scripts/vehicles/vehicle_interaction_manager.gd",
    "scripts/worlds/phase2_test_world.gd",
    "scripts/worlds/city_world.gd",
    "scripts/traffic/traffic_signal_manager.gd",
    "scripts/traffic/traffic_manager.gd",
    "scripts/traffic/traffic_vehicle.gd",
    "scripts/pedestrians/pedestrian_agent.gd",
    "scripts/police/police_manager.gd",
    "scripts/police/police_vehicle_ai.gd",
    "scripts/autoload/save_manager.gd",
    "scripts/autoload/settings_manager.gd",
    "scripts/autoload/game_state.gd",
    "README_FA.md",
    "data/worlds/city_map.json",
    "data/worlds/city_asset_catalog.json",
    "data/worlds/traffic_config.json",
    "data/worlds/law_config.json",
    "data/vehicles/parked_vehicles.json",
    "docs/PHASE7_TESTS_FA.md",
    "docs/PHASE5_TESTS_FA.md",
    "docs/ASSET_CREDITS_FA.md",
    "docs/ARCHITECTURE_FA.md",
    "docs/HONDA_IMPORT_FA.md",
)
REQUIRED_FOLDERS = (
    "assets/models/vehicles",
    "assets/models/environment",
    "assets/models/characters",
    "assets/audio/music",
    "assets/audio/sfx",
    "scenes/vehicles",
    "scenes/characters",
    "scenes/worlds",
    "scripts/autoload",
    "scripts/vehicles",
    "scripts/characters",
    "scripts/camera",
    "scripts/worlds",
    "scripts/navigation",
    "scripts/police",
    "scripts/traffic",
    "scripts/pedestrians",
    "data/vehicles",
    "data/worlds",
    "tests",
)


class Validation:
    def __init__(self) -> None:
        self.errors: list[str] = []
        self.checked_references = 0

    def require_file(self, relative: str) -> None:
        if not (ROOT / relative).is_file():
            self.errors.append(f"Missing required file: {relative}")

    def require_folder(self, relative: str) -> None:
        if not (ROOT / relative).is_dir():
            self.errors.append(f"Missing required folder: {relative}")

    def check_res_reference(self, relative: str, source: str) -> None:
        target = ROOT / relative
        self.checked_references += 1
        if not target.is_file():
            self.errors.append(f"Broken res:// reference in {source}: {relative}")

    def validate_city_assets(self) -> None:
        catalog_path = ROOT / "data/worlds/city_asset_catalog.json"
        map_path = ROOT / "data/worlds/city_map.json"
        if not catalog_path.is_file() or not map_path.is_file():
            return
        try:
            catalog = json.loads(catalog_path.read_text(encoding="utf-8"))
            city_map = json.loads(map_path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError) as exc:
            self.errors.append(f"Invalid phase 3 JSON data: {exc}")
            return

        models = catalog.get("models", {})
        if not isinstance(models, dict) or len(models) < 50:
            self.errors.append("City asset catalog should contain at least 50 model records.")
        else:
            expected_models = (
                [f"kenney_commercial/building-{letter}.glb" for letter in "abcdefghijklmn"]
                + [f"kenney_commercial/low-detail-building-{letter}.glb" for letter in "abcdefghijklmn"]
                + [f"kenney_commercial/building-skyscraper-{letter}.glb" for letter in "abcde"]
                + [f"kenney_industrial/building-{letter}.glb" for letter in "abcdefghijklmnopqrst"]
                + [
                    "kenney_industrial/shipping-container-a.glb",
                    "kenney_industrial/shipping-container-b.glb",
                    "kenney_industrial/shipping-container-c.glb",
                    "kenney_industrial/detail-tank-large.glb",
                    "kenney_industrial/water-tower.glb",
                    "kenney_industrial/chimney-large.glb",
                    "kenney_industrial/chimney-medium.glb",
                ]
            )
            for model_key in expected_models:
                if model_key not in models:
                    self.errors.append(f"City generation references a missing model catalog entry: {model_key}")
            for key, item in models.items():
                if not isinstance(item, dict):
                    self.errors.append(f"Invalid city model entry: {key}")
                    continue
                resource_path = str(item.get("path", ""))
                if not resource_path.startswith("res://"):
                    self.errors.append(f"Invalid model resource path: {key}")
                    continue
                target = ROOT / resource_path.removeprefix("res://")
                if not target.is_file():
                    self.errors.append(f"Missing city model GLB: {resource_path}")
                vectors: dict[str, list[float]] = {}
                for vector_name in ("min", "max", "size"):
                    values = item.get(vector_name)
                    if not isinstance(values, list) or len(values) != 3:
                        self.errors.append(f"Missing {vector_name} bounds for city model: {key}")
                        break
                    try:
                        vectors[vector_name] = [float(value) for value in values]
                    except (TypeError, ValueError):
                        self.errors.append(f"Invalid {vector_name} bounds for city model: {key}")
                        break
                if len(vectors) == 3:
                    for axis in range(3):
                        if vectors["max"][axis] < vectors["min"][axis]:
                            self.errors.append(f"Inverted model bounds for city model: {key}")
                            break
                        measured = vectors["max"][axis] - vectors["min"][axis]
                        if abs(measured - vectors["size"][axis]) > 1e-4:
                            self.errors.append(f"Inconsistent model size metadata: {key}")
                            break
                if item.get("bounds_include_gltf_node_transforms") is not True:
                    self.errors.append(f"GLB node transforms were not included in model bounds: {key}")

        glb_files = list((ROOT / "assets/models/environment").rglob("*.glb"))
        if len(glb_files) != 78:
            self.errors.append(f"Expected 78 imported city GLB models, found {len(glb_files)}.")
        for folder in ("kenney_commercial", "kenney_industrial"):
            asset_root = ROOT / "assets/models/environment" / folder
            if not asset_root.is_dir():
                self.errors.append(f"Missing imported city asset folder: {folder}")
            if not (asset_root / "Textures/colormap.png").is_file():
                self.errors.append(f"Missing GLB color map texture for: {folder}")
            if not (asset_root / "LICENSE.txt").is_file():
                self.errors.append(f"Missing original license file for: {folder}")
            if not (asset_root / "Textures/colormap.png").is_file():
                self.errors.append(f"Missing original colormap texture for: {folder}")

        districts = city_map.get("districts", [])
        district_ids = {str(x.get("id")) for x in districts if isinstance(x, dict)}
        for required_id in ("residential", "downtown", "industrial"):
            if required_id not in district_ids:
                self.errors.append(f"City map is missing the {required_id} district.")
        if len(city_map.get("road_grid", [])) != 7:
            self.errors.append("City map road grid should contain seven street axes per direction.")

        world_script = (ROOT / "scripts/worlds/city_world.gd").read_text(encoding="utf-8")
        for marker in (
            "func _build_road_network()",
            "func _build_city_blocks()",
            "func _build_industrial_yard(",
            "func _build_park(",
            "func _create_district_area(",
            "PLAYER_CAR_SCENE",
        ):
            if marker not in world_script:
                self.errors.append(f"Phase 3 city world is missing: {marker}")
        for marker in (
            "PLAYER_CHARACTER_SCENE",
            "FOOT_CAMERA_SCRIPT",
            "VEHICLE_INTERACTION_SCRIPT",
            "VehicleInteractionManager",
        ):
            if marker not in world_script:
                self.errors.append(f"Phase 4 world integration is missing: {marker}")

        for marker in (
            "TRAFFIC_SIGNAL_MANAGER_SCRIPT",
            "TRAFFIC_MANAGER_SCRIPT",
            "POLICE_MANAGER_SCRIPT",
            '"configure", player, character, interaction_manager, _traffic_signal_manager',
            '"traffic_manager", traffic_manager',
            '"police_manager", police_manager',
        ):
            if marker not in world_script:
                self.errors.append(f"Phase 5 CityWorld integration is missing: {marker}")

        traffic_config_path = ROOT / "data/worlds/traffic_config.json"
        law_config_path = ROOT / "data/worlds/law_config.json"
        try:
            traffic_config = json.loads(traffic_config_path.read_text(encoding="utf-8"))
            law_config = json.loads(law_config_path.read_text(encoding="utf-8"))
            if not 0 <= int(traffic_config.get("vehicle_count", -1)) <= 18:
                self.errors.append("Traffic vehicle count must be between 0 and 18.")
            if not 0 <= int(traffic_config.get("pedestrian_count", -1)) <= 20:
                self.errors.append("Pedestrian count must be between 0 and 20.")
            speed_values = traffic_config.get("traffic_speed_mps", {})
            if not isinstance(speed_values, dict):
                self.errors.append("Traffic speed settings must be a JSON object.")
            else:
                speed_min = float(speed_values.get("minimum", 0))
                speed_max = float(speed_values.get("maximum", 0))
                if not (3.0 <= speed_min <= speed_max <= 18.0):
                    self.errors.append("Traffic speed range must be ordered and within safe gameplay bounds.")
            if not {"residential", "downtown", "industrial", "urban"}.issubset(set(law_config.get("speed_limits_kmh", {}).keys())):
                self.errors.append("Law config must provide speed limits for all city districts.")
            restricted = law_config.get("restricted_zones", [])
            if not restricted or not isinstance(restricted[0], dict):
                self.errors.append("At least one restricted zone must be configured.")
        except (json.JSONDecodeError, OSError, TypeError, ValueError) as exc:
            self.errors.append(f"Phase 5 configuration JSON is invalid: {exc}")

        phase5_scripts = {
            "scripts/traffic/traffic_signal_manager.gd": (
                "func is_green_for(", "func should_stop_for_red(", "HORIZONTAL_GREEN_SECONDS", "VERTICAL_GREEN_SECONDS", "active_index = 0"
            ),
            "scripts/traffic/traffic_vehicle.gd": (
                "extends CharacterBody3D", "func _physics_process(", "should_stop_for_red", "_get_obstacle_distance", "if to_target.length() < 2.2:"
            ),
            "scripts/traffic/traffic_manager.gd": (
                "func _spawn_traffic_vehicles()", "func _spawn_pedestrians()", "TRAFFIC_VEHICLE_SCRIPT", "PEDESTRIAN_SCRIPT", "_minimum_speed_mps", "vehicles_on_route"
            ),
            "scripts/pedestrians/pedestrian_agent.gd": (
                "func _process(", "_left_leg.rotation.x", "_right_leg.rotation.x"
            ),
            "scripts/police/police_manager.gd": (
                "func _register_violation(", "func _resolve_fine(", "func get_speed_limit_kmh(", "unpaid_fines", "var total_due := existing_debt + fine", "_get_restricted_zone_fine_base"
            ),
            "scripts/police/police_vehicle_ai.gd": (
                "func _replan_route(", "func _update_siren(", "set_target(target_node"
            ),
        }
        for relative, markers in phase5_scripts.items():
            source = (ROOT / relative).read_text(encoding="utf-8")
            for marker in markers:
                if marker not in source:
                    self.errors.append(f"Phase 5 script {relative} is missing: {marker}")

        # Phase 7: data-driven public parking and safe switching between cars.
        try:
            parking_config = json.loads((ROOT / "data/vehicles/parked_vehicles.json").read_text(encoding="utf-8"))
            lots = parking_config.get("parking_lots", [])
            if not isinstance(lots, list) or not lots:
                self.errors.append("Phase 7 must configure at least one public parking lot.")
            vehicle_ids: set[str] = set()
            vehicle_total = 0
            parking_ids: set[str] = set()
            for lot in lots if isinstance(lots, list) else []:
                if not isinstance(lot, dict) or not isinstance(lot.get("center_xz"), list) or len(lot["center_xz"]) != 2:
                    self.errors.append("Phase 7 parking lot has invalid center_xz coordinates.")
                    continue
                parking_ids.add(str(lot.get("id", "")))
                size_xz = lot.get("size_xz", [])
                if not isinstance(size_xz, list) or len(size_xz) != 2 or any(float(value) <= 0.0 for value in size_xz):
                    self.errors.append("Phase 7 parking lot dimensions must be two positive values.")
                vehicles = lot.get("vehicles", [])
                if not isinstance(vehicles, list):
                    self.errors.append("Phase 7 parking lot vehicles must be an array.")
                    continue
                for vehicle in vehicles:
                    vehicle_total += 1
                    if not isinstance(vehicle, dict):
                        self.errors.append("Phase 7 vehicle entry must be an object.")
                        continue
                    vehicle_id = str(vehicle.get("id", "")).strip()
                    if not vehicle_id or vehicle_id in vehicle_ids:
                        self.errors.append(f"Phase 7 vehicle id is missing or duplicated: {vehicle_id}")
                    vehicle_ids.add(vehicle_id)
                    for field in ("display_name_fa", "offset_xz", "paint", "mass", "engine_force", "maximum_speed_kmh", "steering_angle", "body_style"):
                        if field not in vehicle:
                            self.errors.append(f"Phase 7 vehicle {vehicle_id} is missing {field}.")
                    offset = vehicle.get("offset_xz")
                    if not isinstance(offset, list) or len(offset) != 2:
                        self.errors.append(f"Phase 7 vehicle {vehicle_id} has invalid offset_xz.")
                    elif isinstance(size_xz, list) and len(size_xz) == 2:
                        if abs(float(offset[0])) >= float(size_xz[0]) * 0.5 or abs(float(offset[1])) >= float(size_xz[1]) * 0.5:
                            self.errors.append(f"Phase 7 vehicle {vehicle_id} is outside its parking lot bounds.")
            if vehicle_total < 3:
                self.errors.append("Phase 7 should include at least three drivable parked vehicles.")
            city_map_path = ROOT / "data/worlds/city_map.json"
            city_map = json.loads(city_map_path.read_text(encoding="utf-8"))
            poi_ids = {str(item.get("id")) for item in city_map.get("points_of_interest", []) if isinstance(item, dict)}
            if "downtown_public_parking" not in parking_ids or "downtown_public_parking" not in poi_ids:
                self.errors.append("Phase 7 public parking must be present in both vehicle data and city POIs.")
        except (json.JSONDecodeError, OSError, TypeError, ValueError) as exc:
            self.errors.append(f"Phase 7 parked vehicle configuration is invalid: {exc}")

        vehicle_manager_text = (ROOT / "scripts/vehicles/vehicle_interaction_manager.gd").read_text(encoding="utf-8")
        for marker in ("signal active_vehicle_changed", "func register_vehicle(", "func _find_nearest_available_vehicle(", "INTERACTION_DISTANCE", "set_target", "active_vehicle_changed.emit"):
            if marker not in vehicle_manager_text:
                self.errors.append(f"Phase 7 vehicle interaction manager is missing: {marker}")
        for relative, markers in {
            "scripts/vehicles/car_controller.gd": ("vehicle_id", "vehicle_display_name", "vehicle_body_style", "func configure_vehicle_variant(", "func _apply_body_style()", "func get_display_name()"),
            "scripts/camera/camera_follow.gd": ("func set_target(", "target = new_target"),
            "scripts/police/police_manager.gd": ("func set_active_vehicle(",),
            "scripts/ui/driving_hud.gd": ("func set_active_vehicle(",),
            "scripts/worlds/city_world.gd": ("_load_parked_vehicle_config()", "_build_public_parking(", "_spawn_parked_vehicles(", "register_vehicle(vehicle, true)"),
        }.items():
            source = (ROOT / relative).read_text(encoding="utf-8")
            for marker in markers:
                if marker not in source:
                    self.errors.append(f"Phase 7 file {relative} is missing: {marker}")

        interaction_script = (ROOT / "scripts/vehicles/vehicle_interaction_manager.gd").read_text(encoding="utf-8")
        for marker in ("func _exit_vehicle()", "func _enter_vehicle()", "EXIT_SPEED_LIMIT_KMH", "INTERACTION_DISTANCE", "set_camera_active"):
            if marker not in interaction_script:
                self.errors.append(f"Vehicle interaction system is missing: {marker}")

        character_script = (ROOT / "scripts/characters/player_character.gd").read_text(encoding="utf-8")
        for marker in ("extends CharacterBody3D", "walk_speed", "run_speed", "move_and_slide()", "walk_forward", "walk_sprint"):
            if marker not in character_script:
                self.errors.append(f"On-foot character controller is missing: {marker}")

        vehicle_script = (ROOT / "scripts/vehicles/car_controller.gd").read_text(encoding="utf-8")
        if "collision_mask |= 8 | 16" not in vehicle_script:
            self.errors.append("Player vehicle must include traffic and police collision layers.")
        if "func set_driving_enabled(" not in vehicle_script or "if not _driving_enabled" not in vehicle_script:
            self.errors.append("CarController does not support safe park/drive mode switching.")
        if "func clear_touch_controls()" not in vehicle_script:
            self.errors.append("CarController does not provide a touch-input reset method.")

        hud_script = (ROOT / "scripts/ui/driving_hud.gd").read_text(encoding="utf-8")
        for marker in ("interaction_manager", "walk_forward", "_on_interact_pressed", "_update_touch_visibility", "func _pause_game()", "func _resume_game()", "func _return_to_menu()", "_economy_label", "unpaid_fines"):
            if marker not in hud_script:
                self.errors.append(f"Driving HUD mode switch/economy status is missing: {marker}")

        honda_source = ROOT / "assets/models/vehicles/honda_legend/source/legend-SF.blend"
        if not honda_source.is_file():
            self.errors.append("Honda Legend Blender source asset is missing.")
        character_scene = (ROOT / "scenes/characters/player_character.tscn").read_text(encoding="utf-8")
        if 'disabled = true' not in character_scene:
            self.errors.append("Player character collider must start disabled while seated in the car.")
        if "func clear_touch_controls()" not in character_script:
            self.errors.append("On-foot character does not provide a touch-input reset method.")
        if "_left_leg.add_child(left_shoe)" not in character_script or "_right_leg.add_child(right_shoe)" not in character_script:
            self.errors.append("Character shoes must follow the procedural leg animation pivots.")
        if "func clear_touch_controls()" not in interaction_script:
            self.errors.append("Vehicle interaction manager does not clear touch state before pause.")
        for texture_name in ("licenseplate.png", "car_lamp_texture.png", "carbon.jpeg", "texture-tire-treads.png", "car-bottom.jpeg"):
            if not (ROOT / "assets/models/vehicles/honda_legend/textures" / texture_name).is_file():
                self.errors.append(f"Honda Legend source texture is missing: {texture_name}")

    def run(self) -> int:
        for relative in REQUIRED_FILES:
            self.require_file(relative)
        for relative in REQUIRED_FOLDERS:
            self.require_folder(relative)
        self.validate_city_assets()

        project_path = ROOT / "project.godot"
        project_text = project_path.read_text(encoding="utf-8")
        required_project_settings = (
            'run/main_scene="res://scenes/menus/main_menu.tscn"',
            'SaveManager="*res://scripts/autoload/save_manager.gd"',
            'SettingsManager="*res://scripts/autoload/settings_manager.gd"',
            'GameState="*res://scripts/autoload/game_state.gd"',
            'renderer/rendering_method="gl_compatibility"',
            'window/handheld/orientation=1',
            'window/stretch/aspect="expand"',
        )
        for setting in required_project_settings:
            if setting not in project_text:
                self.errors.append(f"Missing project setting: {setting}")
        if project_text.count("[application]") != 1:
            self.errors.append("project.godot must contain exactly one [application] section")

        # Verify external resource paths in every scene, not just the main menu.
        for scene_path in ROOT.rglob("*.tscn"):
            scene_text = scene_path.read_text(encoding="utf-8")
            for match in re.finditer(r'path="res://([^\"]+)"', scene_text):
                self.check_res_reference(match.group(1), str(scene_path.relative_to(ROOT)))

        # Verify literal preload/load references in scripts.
        for script_path in ROOT.rglob("*.gd"):
            script_text = script_path.read_text(encoding="utf-8")
            for match in re.finditer(r'(?:preload|load)\("res://([^\"]+)"\)', script_text):
                self.check_res_reference(match.group(1), str(script_path.relative_to(ROOT)))

        menu_text = (ROOT / "scripts/ui/main_menu.gd").read_text(encoding="utf-8")
        if '"start": "شروع بازی"' not in menu_text or "func _on_start_pressed()" not in menu_text:
            self.errors.append("The main menu start action is not wired")
        if 'change_scene_to_file("res://scenes/worlds/city_world.tscn")' not in menu_text:
            self.errors.append("The main menu does not launch the city world.")
        if "فاز ۷" not in menu_text and "PHASE 7" not in menu_text:
            self.errors.append("The main-menu version label does not reflect Phase 7.")
        if 'disabled = true' in menu_text:
            self.errors.append("The main menu start button is still disabled")

        controller_text = (ROOT / "scripts/vehicles/car_controller.gd").read_text(encoding="utf-8")
        for required_control in ("drive_accelerate", "drive_brake", "drive_reverse", "drive_left", "drive_right", "drive_handbrake"):
            if required_control not in controller_text:
                self.errors.append(f"Missing driving input action: {required_control}")
        if 'linear_velocity.dot(global_basis.z)' not in controller_text:
            self.errors.append("Forward-speed calculation does not use VehicleBody3D MODEL_FRONT (+Z)")

        car_scene = (ROOT / "scenes/vehicles/player_car.tscn").read_text(encoding="utf-8")
        for wheel_name in ("FrontLeft", "FrontRight", "RearLeft", "RearRight"):
            if f'[node name="{wheel_name}" type="VehicleWheel3D"' not in car_scene:
                self.errors.append(f"Missing vehicle wheel node: {wheel_name}")
        if car_scene.count("use_as_steering = true") != 2:
            self.errors.append("Exactly two front wheels must be configured for steering")
        if car_scene.count("use_as_traction = true") != 2:
            self.errors.append("Exactly two rear wheels must be configured for traction")

        world_script = (ROOT / "scripts/worlds/phase2_test_world.gd").read_text(encoding="utf-8")
        if 'Vector3(43.0, 0.92, -22.0)' not in world_script:
            self.errors.append("Player spawn is not positioned on the test road")
        if '"player_path", NodePath("../PlayerCar")' not in world_script:
            self.errors.append("Driving HUD player reference is missing")

        if self.errors:
            print("VALIDATION FAILED")
            for error in self.errors:
                print(f"- {error}")
            return 1

        print("VALIDATION PASSED")
        print(f"Project root: {ROOT}")
        print(f"Checked {len(REQUIRED_FILES)} files, {len(REQUIRED_FOLDERS)} folders and {self.checked_references} resource references.")
        print("Phases 1-5 core city, driving, on-foot, traffic and law systems are present; Phase 7 multi-vehicle parking and switching references are present.")
        return 0


def main() -> int:
    return Validation().run()


if __name__ == "__main__":
    sys.exit(main())
