extends Control

## Lightweight vector artwork for the main menu. It is drawn at runtime so the
## menu does not depend on an additional large texture or 3D preview scene.

func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	queue_redraw()


func _notification(what: int) -> void:
	if what == NOTIFICATION_RESIZED:
		queue_redraw()


func _draw() -> void:
	var width := size.x
	var height := size.y
	if width <= 1.0 or height <= 1.0:
		return

	# Distant skyline.
	var skyline_colors: Array[Color] = [
		Color("#142b40"), Color("#17354a"), Color("#1a3044")
	]
	for building_index in range(15):
		var building_width := width * 0.045
		var x := width * 0.025 + float(building_index) * width * 0.066
		var building_height := height * (0.12 + float((building_index * 7) % 9) * 0.018)
		var building_y := height * 0.45 - building_height
		draw_rect(
			Rect2(Vector2(x, building_y), Vector2(building_width, building_height)),
			skyline_colors[building_index % skyline_colors.size()]
		)
		for window_index in range(3):
			var window_position := Vector2(x + building_width * 0.22, building_y + height * (0.025 + float(window_index) * 0.045))
			draw_rect(Rect2(window_position, Vector2(building_width * 0.15, height * 0.012)), Color(0.34, 0.82, 0.78, 0.32))

	# Soft horizon and distant guide lines.
	draw_rect(Rect2(Vector2(0.0, height * 0.44), Vector2(width, height * 0.56)), Color(0.035, 0.10, 0.17, 0.42))
	for line_index in range(7):
		var y := height * (0.51 + float(line_index) * 0.055)
		draw_line(Vector2(width * 0.04, y), Vector2(width * 0.96, y), Color(0.27, 0.72, 0.74, 0.10), 1.0)

	# Perspective road.
	var road := PackedVector2Array([
		Vector2(width * 0.28, height),
		Vector2(width * 0.43, height * 0.47),
		Vector2(width * 0.59, height * 0.47),
		Vector2(width * 0.91, height)
	])
	draw_colored_polygon(road, Color("#142534"))
	draw_line(Vector2(width * 0.28, height), Vector2(width * 0.43, height * 0.47), Color(0.20, 0.74, 0.72, 0.48), 2.0)
	draw_line(Vector2(width * 0.91, height), Vector2(width * 0.59, height * 0.47), Color(0.20, 0.74, 0.72, 0.48), 2.0)
	for dash_index in range(5):
		var amount := 0.54 + float(dash_index) * 0.095
		var y := lerpf(height * 0.50, height * 0.96, amount)
		var dash_width := lerpf(width * 0.008, width * 0.027, amount)
		draw_line(Vector2(width * 0.51, y), Vector2(width * 0.51 + dash_width, y), Color(0.44, 0.91, 0.83, 0.65), 2.0 + amount * 2.0)

	# Roadside lights and small navigation points.
	for point_index in range(8):
		var y := height * (0.54 + float(point_index) * 0.055)
		var spread := width * (0.12 + float(point_index) * 0.035)
		draw_circle(Vector2(width * 0.51 - spread, y), 2.2 + float(point_index) * 0.35, Color(0.24, 0.85, 0.79, 0.55))
		draw_circle(Vector2(width * 0.51 + spread, y), 2.2 + float(point_index) * 0.35, Color(1.0, 0.56, 0.29, 0.52))

	# Stylized overhead sports sedan.
	var car_center := Vector2(width * 0.51, height * 0.70)
	var car_scale := minf(width / 900.0, height / 520.0)
	var half_length := 78.0 * car_scale
	var half_width := 39.0 * car_scale
	draw_circle(car_center + Vector2(0.0, 4.0 * car_scale), 100.0 * car_scale, Color(0.10, 0.75, 0.71, 0.10))
	draw_arc(car_center, 103.0 * car_scale, 0.0, TAU, 64, Color(0.26, 0.86, 0.80, 0.35), 2.0)
	var car_body := PackedVector2Array([
		car_center + Vector2(-half_length * 0.74, -half_width),
		car_center + Vector2(half_length * 0.52, -half_width * 0.88),
		car_center + Vector2(half_length, -half_width * 0.42),
		car_center + Vector2(half_length, half_width * 0.42),
		car_center + Vector2(half_length * 0.52, half_width * 0.88),
		car_center + Vector2(-half_length * 0.74, half_width),
		car_center + Vector2(-half_length, half_width * 0.55),
		car_center + Vector2(-half_length, -half_width * 0.55)
	])
	draw_colored_polygon(car_body, Color("#28c9bd"))
	draw_polyline(PackedVector2Array([
		car_center + Vector2(-half_length * 0.74, -half_width),
		car_center + Vector2(half_length * 0.52, -half_width * 0.88),
		car_center + Vector2(half_length, -half_width * 0.42),
		car_center + Vector2(half_length, half_width * 0.42),
		car_center + Vector2(half_length * 0.52, half_width * 0.88),
		car_center + Vector2(-half_length * 0.74, half_width),
		car_center + Vector2(-half_length, half_width * 0.55),
		car_center + Vector2(-half_length, -half_width * 0.55),
		car_center + Vector2(-half_length * 0.74, -half_width)
	]), Color("#baf8ed"), 2.0)

	var windshield := PackedVector2Array([
		car_center + Vector2(-half_length * 0.42, -half_width * 0.72),
		car_center + Vector2(half_length * 0.32, -half_width * 0.62),
		car_center + Vector2(half_length * 0.52, -half_width * 0.28),
		car_center + Vector2(half_length * 0.52, half_width * 0.28),
		car_center + Vector2(half_length * 0.32, half_width * 0.62),
		car_center + Vector2(-half_length * 0.42, half_width * 0.72),
		car_center + Vector2(-half_length * 0.57, half_width * 0.42),
		car_center + Vector2(-half_length * 0.57, -half_width * 0.42)
	])
	draw_colored_polygon(windshield, Color("#14364b"))
	draw_line(car_center + Vector2(-half_length * 0.06, -half_width * 0.68), car_center + Vector2(-half_length * 0.06, half_width * 0.68), Color(0.57, 0.89, 0.88, 0.8), 1.5)
	for side in [-1.0, 1.0]:
		var side_value: float = float(side)
		var wheel_y: float = car_center.y + side_value * half_width * 0.72
		draw_rect(Rect2(Vector2(car_center.x - half_length * 0.53, wheel_y - 6.0 * car_scale), Vector2(25.0 * car_scale, 12.0 * car_scale)), Color("#081521"))
		draw_rect(Rect2(Vector2(car_center.x + half_length * 0.34, wheel_y - 6.0 * car_scale), Vector2(25.0 * car_scale, 12.0 * car_scale)), Color("#081521"))
	for side in [-1.0, 1.0]:
		draw_circle(car_center + Vector2(half_length * 0.88, side * half_width * 0.29), 3.4 * car_scale, Color("#ffe0a8"))

	# Motion streaks in the foreground.
	for streak_index in range(4):
		var streak_y := height * (0.88 + float(streak_index) * 0.025)
		draw_line(Vector2(width * 0.08, streak_y), Vector2(width * (0.18 + float(streak_index) * 0.035), streak_y), Color(0.26, 0.78, 0.75, 0.16), 2.0)
