extends CanvasLayer
class_name DrivingHUD

@export var player_path: NodePath = NodePath("../PlayerCar")

var player: CarController
var interaction_manager: Node
var police_manager: Node
var traffic_manager: Node
var _law_label: Label
var _wanted_label: Label
var _notice_label: Label
var _traffic_label: Label
var _economy_label: Label
var _speed_label: Label
var _gear_label: Label
var _state_label: Label
var _interact_button: Button
var _pause_overlay: Control
var _touch_controls: Control
var _steering_panel: Control
var _pedal_panel: Control
var _foot_panel: Control
var _sprint_panel: Control
var _is_paused: bool = false


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	player = get_node_or_null(player_path) as CarController
	if player == null:
		push_error("DrivingHUD: player was not found at %s." % player_path)
		return
	_build_hud()
	_build_touch_controls()
	_build_pause_overlay()
	_update_interaction_visibility()
	_update_touch_visibility()


func set_active_vehicle(vehicle: CarController) -> void:
	if vehicle != null and is_instance_valid(vehicle):
		player = vehicle


func _process(_delta: float) -> void:
	if player == null:
		return
	_speed_label.text = "%03d" % int(round(player.get_speed_kmh()))
	_gear_label.text = "دنده %s" % player.get_gear_label() if str(SettingsManager.get_setting("language", "fa")) == "fa" else "GEAR %s" % player.get_gear_label()
	_update_interaction_visibility()
	if interaction_manager != null and is_instance_valid(interaction_manager):
		_state_label.text = str(interaction_manager.call("get_mode_label"))
		_interact_button.text = str(interaction_manager.call("get_interaction_prompt"))
		_interact_button.disabled = not bool(interaction_manager.call("can_interact"))
		_update_touch_visibility()
	_update_law_status()


func _update_law_status() -> void:
	if police_manager != null and is_instance_valid(police_manager):
		var speed_limit := int(police_manager.call("get_current_speed_limit_kmh"))
		_law_label.text = "حد مجاز: %d KM/H" % speed_limit
		var wanted := clampi(int(police_manager.call("get_wanted_level")), 0, 3)
		var star_text := ""
		for index in range(3):
			star_text += "★" if index < wanted else "☆"
		_wanted_label.text = "تعقیب: " + star_text
		var notice := str(police_manager.call("get_notice_message"))
		_notice_label.text = notice
		_notice_label.visible = not notice.is_empty()
	if traffic_manager != null and is_instance_valid(traffic_manager):
		var vehicle_count := int(traffic_manager.call("get_vehicle_count"))
		var pedestrian_count := int(traffic_manager.call("get_pedestrian_count"))
		_traffic_label.text = "ترافیک: %d خودرو  •  %d عابر" % [vehicle_count, pedestrian_count]
		_traffic_label.visible = true
	var unpaid_fines := maxi(0, int(GameState.get_progress("unpaid_fines", 0)))
	_economy_label.text = "سکه: %d  •  بدهی: %d" % [GameState.money, unpaid_fines]


func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("ui_cancel"):
		if _is_paused:
			_resume_game()
		else:
			_pause_game()
		get_viewport().set_input_as_handled()


func _build_hud() -> void:
	var root := Control.new()
	root.name = "HUDRoot"
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(root)

	var speed_panel := PanelContainer.new()
	speed_panel.position = Vector2(16.0, 16.0)
	speed_panel.custom_minimum_size = Vector2(156.0, 88.0)
	speed_panel.add_theme_stylebox_override("panel", _panel_style(Color("#172333"), Color("#49627b")))
	root.add_child(speed_panel)

	var content := VBoxContainer.new()
	content.alignment = BoxContainer.ALIGNMENT_CENTER
	content.add_theme_constant_override("separation", 0)
	speed_panel.add_child(content)

	_speed_label = Label.new()
	_speed_label.text = "000"
	_speed_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_speed_label.add_theme_font_size_override("font_size", 34)
	_speed_label.add_theme_color_override("font_color", Color("#f5f8fc"))
	content.add_child(_speed_label)

	var lower_row := HBoxContainer.new()
	lower_row.alignment = BoxContainer.ALIGNMENT_CENTER
	lower_row.add_theme_constant_override("separation", 9)
	content.add_child(lower_row)

	var unit_label := Label.new()
	unit_label.text = "KM/H"
	unit_label.add_theme_font_size_override("font_size", 11)
	unit_label.add_theme_color_override("font_color", Color("#a9bdd0"))
	lower_row.add_child(unit_label)

	_gear_label = Label.new()
	_gear_label.text = "دنده D"
	_gear_label.add_theme_font_size_override("font_size", 11)
	_gear_label.add_theme_color_override("font_color", Color("#84d9b5"))
	lower_row.add_child(_gear_label)

	var pause_button := Button.new()
	pause_button.text = "Ⅱ"
	pause_button.position = Vector2(186.0, 16.0)
	pause_button.custom_minimum_size = Vector2(54.0, 54.0)
	pause_button.add_theme_font_size_override("font_size", 23)
	pause_button.add_theme_stylebox_override("normal", _button_style(Color("#26394e")))
	pause_button.add_theme_stylebox_override("hover", _button_style(Color("#385875")))
	pause_button.pressed.connect(_pause_game)
	pause_button.mouse_filter = Control.MOUSE_FILTER_STOP
	root.add_child(pause_button)

	var help := Label.new()
	help.position = Vector2(16.0, 112.0)
	help.text = "WASD / ↑↓←→  حرکت   |   R عقب   |   Space ترمز دستی   |   Backspace بازنشانی"
	help.add_theme_font_size_override("font_size", 11)
	help.add_theme_color_override("font_color", Color("#b8c8d8"))
	root.add_child(help)

	var state_panel := PanelContainer.new()
	state_panel.anchor_left = 1.0
	state_panel.anchor_right = 1.0
	state_panel.anchor_top = 0.0
	state_panel.anchor_bottom = 0.0
	state_panel.offset_left = -218.0
	state_panel.offset_right = -16.0
	state_panel.offset_top = 154.0
	state_panel.offset_bottom = 194.0
	state_panel.add_theme_stylebox_override("panel", _panel_style(Color("#172333", 0.88), Color("#49627b", 0.72)))
	root.add_child(state_panel)
	_state_label = Label.new()
	_state_label.text = "حالت رانندگی"
	_state_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_state_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	_state_label.add_theme_font_size_override("font_size", 13)
	_state_label.add_theme_color_override("font_color", Color("#c7d5e0"))
	state_panel.add_child(_state_label)

	var law_panel := PanelContainer.new()
	law_panel.anchor_left = 1.0
	law_panel.anchor_right = 1.0
	law_panel.anchor_top = 0.0
	law_panel.anchor_bottom = 0.0
	law_panel.offset_left = -250.0
	law_panel.offset_right = -16.0
	law_panel.offset_top = 16.0
	law_panel.offset_bottom = 142.0
	law_panel.add_theme_stylebox_override("panel", _panel_style(Color("#172333", 0.9), Color("#9b7547", 0.72)))
	root.add_child(law_panel)
	var law_column := VBoxContainer.new()
	law_column.add_theme_constant_override("separation", 1)
	law_panel.add_child(law_column)
	_law_label = Label.new()
	_law_label.text = "حد مجاز: 60 KM/H"
	_law_label.add_theme_font_size_override("font_size", 12)
	_law_label.add_theme_color_override("font_color", Color("#dce8f0"))
	law_column.add_child(_law_label)
	_wanted_label = Label.new()
	_wanted_label.text = "تعقیب: ☆☆☆"
	_wanted_label.add_theme_font_size_override("font_size", 13)
	_wanted_label.add_theme_color_override("font_color", Color("#f3c66b"))
	law_column.add_child(_wanted_label)
	_notice_label = Label.new()
	_notice_label.text = ""
	_notice_label.add_theme_font_size_override("font_size", 11)
	_notice_label.add_theme_color_override("font_color", Color("#ffb2a8"))
	_notice_label.visible = false
	law_column.add_child(_notice_label)
	_traffic_label = Label.new()
	_traffic_label.text = ""
	_traffic_label.add_theme_font_size_override("font_size", 10)
	_traffic_label.add_theme_color_override("font_color", Color("#a8bfd0"))
	_traffic_label.visible = false
	law_column.add_child(_traffic_label)
	_economy_label = Label.new()
	_economy_label.text = "سکه: 0  •  بدهی: 0"
	_economy_label.add_theme_font_size_override("font_size", 10)
	_economy_label.add_theme_color_override("font_color", Color("#c3d7c7"))
	law_column.add_child(_economy_label)

	_interact_button = Button.new()
	_interact_button.anchor_left = 0.5
	_interact_button.anchor_right = 0.5
	_interact_button.anchor_top = 1.0
	_interact_button.anchor_bottom = 1.0
	_interact_button.offset_left = -150.0
	_interact_button.offset_right = 150.0
	_interact_button.offset_top = -76.0
	_interact_button.offset_bottom = -18.0
	_interact_button.text = "F  •  پیاده‌شدن"
	_interact_button.add_theme_font_size_override("font_size", 15)
	_interact_button.add_theme_stylebox_override("normal", _button_style(Color("#245e78")))
	_interact_button.add_theme_stylebox_override("hover", _button_style(Color("#347d9b")))
	_interact_button.add_theme_stylebox_override("disabled", _button_style(Color("#3b4650")))
	_interact_button.pressed.connect(_on_interact_pressed)
	_interact_button.mouse_filter = Control.MOUSE_FILTER_STOP
	root.add_child(_interact_button)


func _build_touch_controls() -> void:
	_touch_controls = Control.new()
	_touch_controls.name = "TouchControls"
	_touch_controls.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_touch_controls.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(_touch_controls)

	_steering_panel = PanelContainer.new()
	_steering_panel.anchor_left = 0.0
	_steering_panel.anchor_right = 0.0
	_steering_panel.anchor_top = 1.0
	_steering_panel.anchor_bottom = 1.0
	_steering_panel.offset_left = 14.0
	_steering_panel.offset_right = 206.0
	_steering_panel.offset_top = -104.0
	_steering_panel.offset_bottom = -14.0
	_steering_panel.add_theme_stylebox_override("panel", _panel_style(Color("#182536", 0.82), Color("#71869c", 0.4)))
	_touch_controls.add_child(_steering_panel)

	var steering_row := HBoxContainer.new()
	steering_row.alignment = BoxContainer.ALIGNMENT_CENTER
	steering_row.add_theme_constant_override("separation", 8)
	_steering_panel.add_child(steering_row)
	steering_row.add_child(_make_hold_button("◀", "steer_left", Color("#304960"), Vector2(78.0, 66.0)))
	steering_row.add_child(_make_hold_button("▶", "steer_right", Color("#304960"), Vector2(78.0, 66.0)))

	_pedal_panel = PanelContainer.new()
	_pedal_panel.anchor_left = 1.0
	_pedal_panel.anchor_right = 1.0
	_pedal_panel.anchor_top = 1.0
	_pedal_panel.anchor_bottom = 1.0
	_pedal_panel.offset_left = -220.0
	_pedal_panel.offset_right = -14.0
	_pedal_panel.offset_top = -174.0
	_pedal_panel.offset_bottom = -14.0
	_pedal_panel.add_theme_stylebox_override("panel", _panel_style(Color("#182536", 0.82), Color("#71869c", 0.4)))
	_touch_controls.add_child(_pedal_panel)

	var pedal_column := VBoxContainer.new()
	pedal_column.alignment = BoxContainer.ALIGNMENT_CENTER
	pedal_column.add_theme_constant_override("separation", 7)
	_pedal_panel.add_child(pedal_column)
	var pedal_row := HBoxContainer.new()
	pedal_row.alignment = BoxContainer.ALIGNMENT_CENTER
	pedal_row.add_theme_constant_override("separation", 7)
	pedal_column.add_child(pedal_row)
	pedal_row.add_child(_make_hold_button("گاز", "accelerate", Color("#247b62"), Vector2(88.0, 62.0)))
	pedal_row.add_child(_make_hold_button("ترمز", "brake", Color("#8b4a4a"), Vector2(88.0, 62.0)))
	var gear_row := HBoxContainer.new()
	gear_row.alignment = BoxContainer.ALIGNMENT_CENTER
	gear_row.add_theme_constant_override("separation", 7)
	pedal_column.add_child(gear_row)
	gear_row.add_child(_make_hold_button("عقب", "reverse", Color("#465c75"), Vector2(88.0, 54.0)))
	gear_row.add_child(_make_hold_button("ترمز دستی", "handbrake", Color("#8a7041"), Vector2(88.0, 54.0)))

	_foot_panel = PanelContainer.new()
	_foot_panel.anchor_left = 0.0
	_foot_panel.anchor_right = 0.0
	_foot_panel.anchor_top = 1.0
	_foot_panel.anchor_bottom = 1.0
	_foot_panel.offset_left = 14.0
	_foot_panel.offset_right = 206.0
	_foot_panel.offset_top = -174.0
	_foot_panel.offset_bottom = -14.0
	_foot_panel.add_theme_stylebox_override("panel", _panel_style(Color("#182536", 0.82), Color("#71869c", 0.4)))
	_touch_controls.add_child(_foot_panel)
	var foot_column := VBoxContainer.new()
	foot_column.alignment = BoxContainer.ALIGNMENT_CENTER
	foot_column.add_theme_constant_override("separation", 4)
	_foot_panel.add_child(foot_column)
	foot_column.add_child(_make_hold_button("▲", "walk_forward", Color("#304960"), Vector2(164.0, 43.0)))
	var foot_middle := HBoxContainer.new()
	foot_middle.alignment = BoxContainer.ALIGNMENT_CENTER
	foot_middle.add_theme_constant_override("separation", 6)
	foot_column.add_child(foot_middle)
	foot_middle.add_child(_make_hold_button("◀", "walk_left", Color("#304960"), Vector2(75.0, 43.0)))
	foot_middle.add_child(_make_hold_button("▶", "walk_right", Color("#304960"), Vector2(75.0, 43.0)))
	foot_column.add_child(_make_hold_button("▼", "walk_backward", Color("#304960"), Vector2(164.0, 43.0)))

	_sprint_panel = PanelContainer.new()
	_sprint_panel.anchor_left = 1.0
	_sprint_panel.anchor_right = 1.0
	_sprint_panel.anchor_top = 1.0
	_sprint_panel.anchor_bottom = 1.0
	_sprint_panel.offset_left = -144.0
	_sprint_panel.offset_right = -14.0
	_sprint_panel.offset_top = -82.0
	_sprint_panel.offset_bottom = -14.0
	_sprint_panel.add_theme_stylebox_override("panel", _panel_style(Color("#182536", 0.82), Color("#71869c", 0.4)))
	_touch_controls.add_child(_sprint_panel)
	var sprint_column := VBoxContainer.new()
	sprint_column.alignment = BoxContainer.ALIGNMENT_CENTER
	_sprint_panel.add_child(sprint_column)
	sprint_column.add_child(_make_hold_button("دویدن", "sprint", Color("#8b7041"), Vector2(108.0, 54.0)))


func _build_pause_overlay() -> void:
	_pause_overlay = Control.new()
	_pause_overlay.name = "PauseOverlay"
	_pause_overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_pause_overlay.visible = false
	_pause_overlay.process_mode = Node.PROCESS_MODE_ALWAYS
	_pause_overlay.mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(_pause_overlay)

	var dim := ColorRect.new()
	dim.color = Color(0.02, 0.04, 0.07, 0.78)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_pause_overlay.add_child(dim)

	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_pause_overlay.add_child(center)

	var panel := PanelContainer.new()
	panel.custom_minimum_size = Vector2(300.0, 0.0)
	panel.add_theme_stylebox_override("panel", _panel_style(Color("#1a2939"), Color("#526b84")))
	center.add_child(panel)

	var column := VBoxContainer.new()
	column.add_theme_constant_override("separation", 12)
	panel.add_child(column)

	var title := Label.new()
	title.text = "بازی متوقف شد"
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_font_size_override("font_size", 23)
	column.add_child(title)

	var resume_button := _make_menu_button("ادامه بازی", Color("#26765e"))
	resume_button.pressed.connect(_resume_game)
	column.add_child(resume_button)

	var menu_button := _make_menu_button("بازگشت به منوی اصلی", Color("#30465c"))
	menu_button.pressed.connect(_return_to_menu)
	column.add_child(menu_button)


func _make_hold_button(label_text: String, action_name: String, color: Color, button_size: Vector2) -> Button:
	var button := Button.new()
	button.text = label_text
	button.custom_minimum_size = button_size
	button.focus_mode = Control.FOCUS_NONE
	button.mouse_filter = Control.MOUSE_FILTER_STOP
	button.add_theme_font_size_override("font_size", 19 if label_text in ["◀", "▶", "▲", "▼"] else 15)
	button.add_theme_stylebox_override("normal", _button_style(color))
	button.add_theme_stylebox_override("hover", _button_style(color.lightened(0.12)))
	button.add_theme_stylebox_override("pressed", _button_style(color.darkened(0.18)))
	button.button_down.connect(func() -> void:
		if action_name.begins_with("walk_") or action_name == "sprint":
			if interaction_manager != null:
				interaction_manager.call("set_character_touch", action_name, true)
		elif player != null:
			player.set_touch_control(action_name, true)
	)
	button.button_up.connect(func() -> void:
		if action_name.begins_with("walk_") or action_name == "sprint":
			if interaction_manager != null:
				interaction_manager.call("set_character_touch", action_name, false)
		elif player != null:
			player.set_touch_control(action_name, false)
	)
	return button


func _make_menu_button(label_text: String, color: Color) -> Button:
	var button := Button.new()
	button.text = label_text
	button.custom_minimum_size = Vector2(0.0, 48.0)
	button.add_theme_stylebox_override("normal", _button_style(color))
	button.add_theme_stylebox_override("hover", _button_style(color.lightened(0.12)))
	button.add_theme_stylebox_override("pressed", _button_style(color.darkened(0.16)))
	return button


func _panel_style(background_color: Color, border_color: Color) -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color = background_color
	style.border_color = border_color
	style.set_border_width_all(1)
	style.set_corner_radius_all(13)
	style.content_margin_left = 10.0
	style.content_margin_right = 10.0
	style.content_margin_top = 7.0
	style.content_margin_bottom = 7.0
	return style


func _button_style(background_color: Color) -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color = background_color
	style.set_corner_radius_all(11)
	style.content_margin_left = 8.0
	style.content_margin_right = 8.0
	style.content_margin_top = 5.0
	style.content_margin_bottom = 5.0
	return style


func _update_interaction_visibility() -> void:
	var enabled := interaction_manager != null and is_instance_valid(interaction_manager)
	if _interact_button != null:
		_interact_button.visible = enabled
	if _state_label != null:
		var state_panel := _state_label.get_parent() as Control
		if state_panel != null:
			state_panel.visible = enabled


func _update_touch_visibility() -> void:
	var scheme := str(SettingsManager.get_setting("control_scheme", "auto"))
	var show_touch := scheme == "touch" or (scheme == "auto" and OS.has_feature("mobile"))
	var is_driving := true
	if interaction_manager != null and is_instance_valid(interaction_manager):
		is_driving = bool(interaction_manager.get("is_driving"))
	if _steering_panel != null:
		_steering_panel.visible = show_touch and is_driving
	if _pedal_panel != null:
		_pedal_panel.visible = show_touch and is_driving
	if _foot_panel != null:
		_foot_panel.visible = show_touch and not is_driving
	if _sprint_panel != null:
		_sprint_panel.visible = show_touch and not is_driving


func _on_interact_pressed() -> void:
	if interaction_manager != null and is_instance_valid(interaction_manager):
		interaction_manager.call("toggle_vehicle")

func _pause_game() -> void:
	if _is_paused:
		return
	_is_paused = true
	if interaction_manager != null and is_instance_valid(interaction_manager):
		interaction_manager.call("clear_touch_controls")
	elif player != null:
		player.clear_touch_controls()
	_pause_overlay.visible = true
	get_tree().paused = true


func _resume_game() -> void:
	if not _is_paused:
		return
	_pause_overlay.visible = false
	get_tree().paused = false
	_is_paused = false


func _return_to_menu() -> void:
	get_tree().paused = false
	_is_paused = false
	get_tree().change_scene_to_file("res://scenes/menus/main_menu.tscn")

