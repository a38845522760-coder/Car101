extends Node

## Persistent loading scene. It reports the engine's threaded resource progress,
## then the city generator's own staged progress before activating the world.

const CITY_SCENE_PATH: String = "res://scenes/worlds/city_world.tscn"

var _canvas_layer: CanvasLayer
var _world_host: Node3D
var _progress_bar: ProgressBar
var _percentage_label: Label
var _stage_label: Label
var _error_label: Label
var _back_button: Button
var _loading_scene_resource: bool = false
var _world_node: Node3D
var _world_started: bool = false
var _finished: bool = false


func _ready() -> void:
	_build_interface()
	_start_resource_loading()


func _process(_delta: float) -> void:
	if not _loading_scene_resource or _world_started or _finished:
		return

	var progress: Array = []
	var status := ResourceLoader.load_threaded_get_status(CITY_SCENE_PATH, progress)
	if not progress.is_empty():
		var resource_ratio := clampf(float(progress[0]), 0.0, 1.0)
		_set_progress(resource_ratio * 0.30, "در حال بارگذاری فایل‌ها و منابع شهر…")

	if status == ResourceLoader.THREAD_LOAD_LOADED:
		_loading_scene_resource = false
		var packed_scene := ResourceLoader.load_threaded_get(CITY_SCENE_PATH) as PackedScene
		if packed_scene == null:
			_show_error("فایل صحنهٔ شهر بارگذاری شد، اما قابل اجرا نیست.")
			return
		_start_world_generation(packed_scene)
	elif status == ResourceLoader.THREAD_LOAD_FAILED or status == ResourceLoader.THREAD_LOAD_INVALID_RESOURCE:
		_loading_scene_resource = false
		_show_error("بارگذاری صحنهٔ شهر ناموفق بود. فایل‌های پروژه یا منابع واردشده را بررسی کن.")


func _build_interface() -> void:
	_canvas_layer = CanvasLayer.new()
	_canvas_layer.layer = 100
	add_child(_canvas_layer)

	var root := Control.new()
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_canvas_layer.add_child(root)

	var background := ColorRect.new()
	background.color = Color("#071725")
	background.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root.add_child(background)

	var glow := Panel.new()
	glow.position = Vector2(520.0, -180.0)
	glow.size = Vector2(650.0, 400.0)
	glow.rotation = -0.18
	var glow_style := StyleBoxFlat.new()
	glow_style.bg_color = Color(0.04, 0.62, 0.57, 0.12)
	glow_style.set_corner_radius_all(190)
	glow.add_theme_stylebox_override("panel", glow_style)
	root.add_child(glow)

	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root.add_child(center)

	var panel := PanelContainer.new()
	panel.custom_minimum_size = Vector2(690.0, 350.0)
	var panel_style := StyleBoxFlat.new()
	panel_style.bg_color = Color("#132d43")
	panel_style.border_color = Color("#2d6478")
	panel_style.set_border_width_all(1)
	panel_style.set_corner_radius_all(24)
	panel.add_theme_stylebox_override("panel", panel_style)
	center.add_child(panel)

	var margin := MarginContainer.new()
	margin.add_theme_constant_override("margin_left", 34)
	margin.add_theme_constant_override("margin_right", 34)
	margin.add_theme_constant_override("margin_top", 30)
	margin.add_theme_constant_override("margin_bottom", 28)
	panel.add_child(margin)

	var column := VBoxContainer.new()
	column.add_theme_constant_override("separation", 12)
	margin.add_child(column)

	var brand := Label.new()
	brand.text = "CAR101  /  CITY DRIVE"
	brand.add_theme_font_size_override("font_size", 15)
	brand.add_theme_color_override("font_color", Color("#5ce2d2"))
	column.add_child(brand)

	var title := Label.new()
	title.text = "در حال آماده‌سازی شهر…"
	title.add_theme_font_size_override("font_size", 29)
	title.add_theme_color_override("font_color", Color("#f3f8fa"))
	column.add_child(title)

	var description := Label.new()
	description.text = "منابع بازی بارگذاری می‌شوند و بخش‌های شهر به‌ترتیب ساخته می‌شوند."
	description.add_theme_font_size_override("font_size", 13)
	description.add_theme_color_override("font_color", Color("#a9c1cf"))
	description.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	column.add_child(description)

	var spacer := Control.new()
	spacer.custom_minimum_size.y = 24.0
	column.add_child(spacer)

	var progress_row := HBoxContainer.new()
	progress_row.add_theme_constant_override("separation", 12)
	column.add_child(progress_row)
	_stage_label = Label.new()
	_stage_label.text = "در حال شروع…"
	_stage_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_stage_label.add_theme_font_size_override("font_size", 13)
	_stage_label.add_theme_color_override("font_color", Color("#c4d8e1"))
	progress_row.add_child(_stage_label)
	_percentage_label = Label.new()
	_percentage_label.text = "۰٪"
	_percentage_label.custom_minimum_size = Vector2(72.0, 0.0)
	_percentage_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	_percentage_label.add_theme_font_size_override("font_size", 20)
	_percentage_label.add_theme_color_override("font_color", Color("#67e6d5"))
	progress_row.add_child(_percentage_label)

	_progress_bar = ProgressBar.new()
	_progress_bar.min_value = 0.0
	_progress_bar.max_value = 100.0
	_progress_bar.value = 0.0
	_progress_bar.show_percentage = false
	_progress_bar.custom_minimum_size = Vector2(0.0, 18.0)
	var bar_background := StyleBoxFlat.new()
	bar_background.bg_color = Color("#0a1d2c")
	bar_background.set_corner_radius_all(9)
	var bar_fill := StyleBoxFlat.new()
	bar_fill.bg_color = Color("#43d4c4")
	bar_fill.set_corner_radius_all(9)
	_progress_bar.add_theme_stylebox_override("background", bar_background)
	_progress_bar.add_theme_stylebox_override("fill", bar_fill)
	column.add_child(_progress_bar)

	_error_label = Label.new()
	_error_label.visible = false
	_error_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_error_label.add_theme_font_size_override("font_size", 12)
	_error_label.add_theme_color_override("font_color", Color("#ffb18f"))
	column.add_child(_error_label)

	_back_button = Button.new()
	_back_button.text = "بازگشت به منو"
	_back_button.custom_minimum_size = Vector2(0.0, 42.0)
	_back_button.visible = false
	_back_button.pressed.connect(_return_to_menu)
	column.add_child(_back_button)

	var footer := Label.new()
	footer.text = "لطفاً بازی را هنگام بارگذاری نبند."
	footer.add_theme_font_size_override("font_size", 11)
	footer.add_theme_color_override("font_color", Color("#7895a8"))
	column.add_child(footer)

	_world_host = Node3D.new()
	_world_host.name = "WorldHost"
	add_child(_world_host)


func _start_resource_loading() -> void:
	_set_progress(0.0, "در حال آماده‌سازی منابع…")
	var error := ResourceLoader.load_threaded_request(CITY_SCENE_PATH, "PackedScene", true)
	if error != OK:
		_show_error("شروع بارگذاری شهر ممکن نشد (کد خطا: %d)." % error)
		return
	_loading_scene_resource = true


func _start_world_generation(packed_scene: PackedScene) -> void:
	_world_started = true
	_set_progress(30.0, "منابع آماده شدند؛ ساخت شهر آغاز می‌شود…")
	var instance := packed_scene.instantiate()
	if not (instance is Node3D):
		instance.queue_free()
		_show_error("ساختار صحنهٔ شهر معتبر نیست.")
		return
	_world_node = instance as Node3D
	if not _world_node.has_signal("generation_progress") or not _world_node.has_signal("generation_completed"):
		_show_error("نسخهٔ صحنهٔ شهر با سیستم بارگذاری مرحله‌ای هماهنگ نیست.")
		return
	_world_node.connect("generation_progress", Callable(self, "_on_world_progress"))
	_world_node.connect("generation_completed", Callable(self, "_on_world_completed"))
	_world_host.add_child(_world_node)


func _on_world_progress(world_ratio: float, stage: String) -> void:
	var total_ratio := 30.0 + clampf(world_ratio, 0.0, 1.0) * 69.0
	_set_progress(total_ratio, stage)


func _on_world_completed() -> void:
	if _finished:
		return
	_finished = true
	_set_progress(100.0, "شهر آماده است؛ ورود به بازی…")
	call_deferred("_activate_world")


func _activate_world() -> void:
	if not is_instance_valid(_world_node):
		_show_error("شهر ساخته شد، اما صحنهٔ بازی در دسترس نیست.")
		return
	var scene_tree := get_tree()
	_world_host.remove_child(_world_node)
	var error := scene_tree.change_scene_to_node(_world_node)
	if error != OK:
		_world_host.add_child(_world_node)
		_show_error("ورود به شهر انجام نشد (کد خطا: %d)." % error)


func _set_progress(value: float, stage: String) -> void:
	if not is_instance_valid(_progress_bar):
		return
	var clamped_value := clampf(value, 0.0, 100.0)
	_progress_bar.value = clamped_value
	_percentage_label.text = "%d%%" % roundi(clamped_value)
	_stage_label.text = stage


func _show_error(message: String) -> void:
	_loading_scene_resource = false
	_world_started = true
	_error_label.text = message
	_error_label.visible = true
	_back_button.visible = true
	_stage_label.text = "بارگذاری متوقف شد"
	_stage_label.add_theme_color_override("font_color", Color("#ffb18f"))


func _return_to_menu() -> void:
	var error := get_tree().change_scene_to_file("res://scenes/menus/main_menu.tscn")
	if error != OK:
		push_error("LoadingScreen: could not return to the main menu (error %s)." % str(error))
