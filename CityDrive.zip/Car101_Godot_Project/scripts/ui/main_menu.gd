extends Control

const TEXTS: Dictionary = {
	"fa": {
		"title": "CAR101",
		"subtitle": "جهان‌باز رانندگی",
		"phase_tag": "فاز ۸ | مالکیت خودرو و ارتقای گاراژ",
		"start": "شروع بازی",
		"start_hint": "گشت‌وگذار در شهر، بلوارها، پارک‌ها و منطقه صنعتی.",
		"settings": "تنظیمات",
		"quit": "خروج",
		"version": "نمونه جهان‌باز 0.8.0 | Godot 4.7.2",
		"settings_title": "تنظیمات بازی",
		"language": "زبان",
		"quality": "کیفیت گرافیک",
		"controls": "روش کنترل",
		"master_volume": "صدای کلی",
		"music_volume": "موسیقی",
		"sfx_volume": "صداهای بازی",
		"fullscreen": "تمام‌صفحه (PC)",
		"back": "بازگشت",
		"language_fa": "فارسی",
		"language_en": "English",
		"quality_low": "سبک",
		"quality_balanced": "متعادل",
		"quality_high": "بالا",
		"controls_auto": "خودکار",
		"controls_touch": "لمسی",
		"controls_keyboard": "کیبورد و ماوس",
		"settings_note": "زبان، صدا و روش کنترل ذخیره می‌شوند. کنترل لمسی در حالت خودکار روی موبایل فعال است؛ کیفیت گرافیکی در فاز بهینه‌سازی تکمیل می‌شود.",
		"quit_mobile": "برای خروج از بازی از دکمه بازگشت دستگاه استفاده کن.",
		"quit_desktop": "بستن بازی"
	},
	"en": {
		"title": "CAR101",
		"subtitle": "Open-world driving",
		"phase_tag": "PHASE 8 | VEHICLE OWNERSHIP AND GARAGE UPGRADES",
		"start": "Start game",
		"start_hint": "Explore the city, boulevards, parks and industrial district.",
		"settings": "Settings",
		"quit": "Quit",
		"version": "Open-world Prototype 0.8.0 | Godot 4.7.2",
		"settings_title": "Game settings",
		"language": "Language",
		"quality": "Graphics quality",
		"controls": "Control scheme",
		"master_volume": "Master volume",
		"music_volume": "Music",
		"sfx_volume": "Game sounds",
		"fullscreen": "Fullscreen (PC)",
		"back": "Back",
		"language_fa": "فارسی",
		"language_en": "English",
		"quality_low": "Low",
		"quality_balanced": "Balanced",
		"quality_high": "High",
		"controls_auto": "Automatic",
		"controls_touch": "Touch",
		"controls_keyboard": "Keyboard and mouse",
		"settings_note": "Language, audio and control scheme are saved. Touch controls activate automatically on mobile; graphics presets will be completed in the optimization phase.",
		"quit_mobile": "Use your device back button to leave the game.",
		"quit_desktop": "Close the game"
	}
}

var _view: String = "home"
var _card_body: VBoxContainer
var _background: ColorRect


func _ready() -> void:
	_build_shell()
	_show_home()


func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("ui_cancel") and _view == "settings":
		_show_home()
		get_viewport().set_input_as_handled()


func _build_shell() -> void:
	_background = ColorRect.new()
	_background.color = Color("#101722")
	_background.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(_background)

	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(center)

	var panel := PanelContainer.new()
	panel.custom_minimum_size = Vector2(500.0, 0.0)
	var panel_style := StyleBoxFlat.new()
	panel_style.bg_color = Color("#1a2635")
	panel_style.border_color = Color("#34465c")
	panel_style.set_border_width_all(1)
	panel_style.set_corner_radius_all(20)
	panel.add_theme_stylebox_override("panel", panel_style)
	center.add_child(panel)

	var margin := MarginContainer.new()
	margin.add_theme_constant_override("margin_left", 28)
	margin.add_theme_constant_override("margin_right", 28)
	margin.add_theme_constant_override("margin_top", 26)
	margin.add_theme_constant_override("margin_bottom", 26)
	panel.add_child(margin)

	_card_body = VBoxContainer.new()
	_card_body.add_theme_constant_override("separation", 12)
	margin.add_child(_card_body)


func _show_home() -> void:
	_view = "home"
	_update_layout_direction()
	_clear_body()
	_add_label(_t("title"), 38, true, Color("#f1f6fb"))
	_add_label(_t("subtitle"), 18, true, Color("#9eb4ca"))
	_add_spacer(8)
	_add_label(_t("phase_tag"), 13, true, Color("#76d6b0"))
	_add_spacer(8)

	var start_button := _make_button(_t("start"), _on_start_pressed)
	_card_body.add_child(start_button)
	_add_label(_t("start_hint"), 12, true, Color("#aebdca"))

	_add_spacer(4)
	_card_body.add_child(_make_button(_t("settings"), _show_settings))
	_card_body.add_child(_make_button(_t("quit"), _on_quit_pressed, false, true))
	_add_spacer(8)
	_add_label(_t("version"), 11, true, Color("#8194a8"))


func _show_settings() -> void:
	_view = "settings"
	_update_layout_direction()
	_clear_body()
	_add_label(_t("settings_title"), 27, true, Color("#f1f6fb"))
	_add_spacer(6)

	_add_option_row("language", _t("language"), [
		{"label": _t("language_fa"), "value": "fa"},
		{"label": _t("language_en"), "value": "en"}
	])
	_add_option_row("quality", _t("quality"), [
		{"label": _t("quality_low"), "value": "low"},
		{"label": _t("quality_balanced"), "value": "balanced"},
		{"label": _t("quality_high"), "value": "high"}
	])
	_add_option_row("control_scheme", _t("controls"), [
		{"label": _t("controls_auto"), "value": "auto"},
		{"label": _t("controls_touch"), "value": "touch"},
		{"label": _t("controls_keyboard"), "value": "keyboard"}
	])

	_add_volume_row("master_volume", _t("master_volume"))
	_add_volume_row("music_volume", _t("music_volume"))
	_add_volume_row("sfx_volume", _t("sfx_volume"))

	var fullscreen := CheckButton.new()
	fullscreen.text = _t("fullscreen")
	fullscreen.button_pressed = bool(SettingsManager.get_setting("fullscreen", false))
	fullscreen.toggled.connect(func(enabled: bool) -> void:
		SettingsManager.set_setting("fullscreen", enabled)
	)
	_card_body.add_child(fullscreen)

	_add_label(_t("settings_note"), 11, false, Color("#9eb0c1"))
	_add_spacer(4)
	_card_body.add_child(_make_button(_t("back"), _show_home, false, true))


func _add_option_row(key: String, title: String, choices: Array[Dictionary]) -> void:
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 12)
	var label := Label.new()
	label.text = title
	label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	row.add_child(label)

	var option := OptionButton.new()
	option.custom_minimum_size = Vector2(180.0, 42.0)
	for choice in choices:
		option.add_item(str(choice["label"]))
		option.set_item_metadata(option.item_count - 1, choice["value"])
	var selected_value: Variant = SettingsManager.get_setting(key)
	for index in range(option.item_count):
		if option.get_item_metadata(index) == selected_value:
			option.select(index)
			break
	option.item_selected.connect(func(index: int) -> void:
		var new_value: Variant = option.get_item_metadata(index)
		SettingsManager.set_setting(key, new_value)
		if key == "language":
			call_deferred("_show_settings")
	)
	row.add_child(option)
	_card_body.add_child(row)


func _add_volume_row(key: String, title: String) -> void:
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 10)
	var label := Label.new()
	label.text = title
	label.custom_minimum_size = Vector2(118.0, 0.0)
	label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	row.add_child(label)

	var slider := HSlider.new()
	slider.min_value = 0.0
	slider.max_value = 1.0
	slider.step = 0.05
	slider.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	slider.value = float(SettingsManager.get_setting(key, 0.8))
	var value_label := Label.new()
	value_label.custom_minimum_size = Vector2(42.0, 0.0)
	value_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_END
	value_label.text = "%d%%" % int(slider.value * 100.0)
	slider.value_changed.connect(func(value: float) -> void:
		value_label.text = "%d%%" % int(value * 100.0)
		SettingsManager.set_setting(key, value)
	)
	row.add_child(slider)
	row.add_child(value_label)
	_card_body.add_child(row)


func _make_button(text_value: String, callback: Callable, disabled: bool = false, secondary: bool = false) -> Button:
	var button := Button.new()
	button.text = text_value
	button.custom_minimum_size = Vector2(0.0, 48.0)
	button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	button.disabled = disabled
	button.focus_mode = Control.FOCUS_ALL
	var normal := StyleBoxFlat.new()
	normal.bg_color = Color("#314b65") if not secondary else Color("#26394e")
	normal.set_corner_radius_all(11)
	normal.content_margin_left = 12.0
	normal.content_margin_right = 12.0
	var hover := normal.duplicate() as StyleBoxFlat
	hover.bg_color = Color("#3d6081") if not secondary else Color("#314a63")
	var pressed := normal.duplicate() as StyleBoxFlat
	pressed.bg_color = Color("#25394e")
	button.add_theme_stylebox_override("normal", normal)
	button.add_theme_stylebox_override("hover", hover)
	button.add_theme_stylebox_override("pressed", pressed)
	if callback.is_valid() and not disabled:
		button.pressed.connect(callback)
	return button


func _add_label(text_value: String, font_size: int, centered: bool, color: Color) -> Label:
	var label := Label.new()
	label.text = text_value
	label.add_theme_font_size_override("font_size", font_size)
	label.add_theme_color_override("font_color", color)
	label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER if centered else HORIZONTAL_ALIGNMENT_LEFT
	label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_card_body.add_child(label)
	return label


func _add_spacer(height: float) -> void:
	var spacer := Control.new()
	spacer.custom_minimum_size.y = height
	_card_body.add_child(spacer)


func _clear_body() -> void:
	for child in _card_body.get_children():
		_card_body.remove_child(child)
		child.queue_free()


func _on_start_pressed() -> void:
	var error := get_tree().change_scene_to_file("res://scenes/worlds/city_world.tscn")
	if error != OK:
		push_error("MainMenu: could not open the driving test world (error %s)." % str(error))


func _on_quit_pressed() -> void:
	if OS.has_feature("mobile"):
		_add_label(_t("quit_mobile"), 12, true, Color("#f0c987"))
	else:
		get_tree().quit()


func _t(key: String) -> String:
	var locale := str(SettingsManager.get_setting("language", "fa"))
	var selected_texts: Dictionary = TEXTS.get(locale, TEXTS["fa"])
	return str(selected_texts.get(key, key))


func _update_layout_direction() -> void:
	var locale := str(SettingsManager.get_setting("language", "fa"))
	layout_direction = Control.LAYOUT_DIRECTION_RTL if locale == "fa" else Control.LAYOUT_DIRECTION_LTR
