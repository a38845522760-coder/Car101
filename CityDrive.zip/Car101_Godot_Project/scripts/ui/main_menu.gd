extends Control

const MENU_ART_SCRIPT: Script = preload("res://scripts/ui/menu_illustration.gd")
const LOADING_SCENE_PATH: String = "res://scenes/ui/loading_screen.tscn"

const TEXTS: Dictionary = {
	"fa": {
		"title": "فرمان را بگیر، شهر مال توست",
		"subtitle": "در خیابان‌های یک شهر زنده رانندگی کن؛ آزادانه بگرد، ماشینت را ارتقا بده و مسیر خودت را بساز.",
		"phase_tag": "جهان‌باز رانندگی  •  نسخهٔ آزمایشی ۰٫۸",
		"start": "شروع رانندگی",
		"start_hint": "ورود به شهر و آغاز رانندگی آزاد",
		"settings": "تنظیمات بازی",
		"quit": "خروج",
		"version": "CAR101  |  CITY DRIVE EXPERIENCE",
		"settings_title": "تنظیمات بازی",
		"language": "زبان",
		"quality": "کیفیت گرافیک",
		"controls": "روش کنترل",
		"master_volume": "صدای کلی",
		"music_volume": "موسیقی",
		"sfx_volume": "صداهای بازی",
		"fullscreen": "تمام‌صفحه (رایانه)",
		"back": "بازگشت به منو",
		"language_fa": "فارسی",
		"language_en": "English",
		"quality_low": "سبک",
		"quality_balanced": "متعادل",
		"quality_high": "بالا",
		"controls_auto": "خودکار",
		"controls_touch": "لمسی",
		"controls_keyboard": "کیبورد و ماوس",
		"settings_note": "تنظیمات زبان و صدا ذخیره می‌شوند. کنترل لمسی در گوشی فعال است.",
		"quit_mobile": "برای خروج، از دکمهٔ بازگشت دستگاه استفاده کن.",
		"quit_desktop": "بستن بازی"
	},
	"en": {
		"title": "TAKE THE WHEEL. OWN THE CITY.",
		"subtitle": "Cruise through a living city, explore freely, upgrade your ride and make every route yours.",
		"phase_tag": "OPEN-WORLD DRIVING  •  PREVIEW 0.8",
		"start": "START DRIVING",
		"start_hint": "Enter the city and begin your free drive",
		"settings": "GAME SETTINGS",
		"quit": "QUIT",
		"version": "CAR101  |  CITY DRIVE EXPERIENCE",
		"settings_title": "GAME SETTINGS",
		"language": "Language",
		"quality": "Graphics quality",
		"controls": "Control scheme",
		"master_volume": "Master volume",
		"music_volume": "Music",
		"sfx_volume": "Game sounds",
		"fullscreen": "Fullscreen (PC)",
		"back": "Back to menu",
		"language_fa": "فارسی",
		"language_en": "English",
		"quality_low": "Low",
		"quality_balanced": "Balanced",
		"quality_high": "High",
		"controls_auto": "Automatic",
		"controls_touch": "Touch",
		"controls_keyboard": "Keyboard and mouse",
		"settings_note": "Language and audio preferences are saved. Touch controls are enabled on phones.",
		"quit_mobile": "Use your device back button to leave the game.",
		"quit_desktop": "Close the game"
	}
}

var _view: String = "home"
var _card_body: VBoxContainer
var _left_panel: PanelContainer
var _showcase: Control


func _ready() -> void:
	_build_shell()
	_show_home()


func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("ui_cancel") and _view == "settings":
		_show_home()
		get_viewport().set_input_as_handled()


func _build_shell() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_build_background()
	_build_header()

	var content := HBoxContainer.new()
	content.name = "MainContent"
	content.anchor_left = 0.045
	content.anchor_top = 0.19
	content.anchor_right = 0.955
	content.anchor_bottom = 0.925
	content.add_theme_constant_override("separation", 20)
	add_child(content)

	_left_panel = PanelContainer.new()
	_left_panel.name = "MenuPanel"
	_left_panel.custom_minimum_size = Vector2(390.0, 0.0)
	_left_panel.size_flags_horizontal = Control.SIZE_FILL
	_left_panel.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_left_panel.add_theme_stylebox_override("panel", _make_panel_style(Color("#142b40"), Color("#24516a"), 24))
	content.add_child(_left_panel)

	var margin := MarginContainer.new()
	margin.add_theme_constant_override("margin_left", 25)
	margin.add_theme_constant_override("margin_right", 25)
	margin.add_theme_constant_override("margin_top", 22)
	margin.add_theme_constant_override("margin_bottom", 20)
	_left_panel.add_child(margin)

	var scroll := ScrollContainer.new()
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	margin.add_child(scroll)

	_card_body = VBoxContainer.new()
	_card_body.add_theme_constant_override("separation", 11)
	_card_body.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.add_child(_card_body)

	_build_showcase(content)


func _build_background() -> void:
	var background := ColorRect.new()
	background.color = Color("#071726")
	background.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	background.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(background)

	var glow_top := Panel.new()
	glow_top.position = Vector2(650.0, -230.0)
	glow_top.size = Vector2(650.0, 430.0)
	glow_top.rotation = -0.16
	var glow_style := StyleBoxFlat.new()
	glow_style.bg_color = Color(0.04, 0.58, 0.56, 0.13)
	glow_style.set_corner_radius_all(220)
	glow_top.add_theme_stylebox_override("panel", glow_style)
	glow_top.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(glow_top)

	var glow_bottom := Panel.new()
	glow_bottom.position = Vector2(-260.0, 520.0)
	glow_bottom.size = Vector2(700.0, 300.0)
	glow_bottom.rotation = -0.12
	var glow_bottom_style := StyleBoxFlat.new()
	glow_bottom_style.bg_color = Color(0.93, 0.36, 0.16, 0.07)
	glow_bottom_style.set_corner_radius_all(150)
	glow_bottom.add_theme_stylebox_override("panel", glow_bottom_style)
	glow_bottom.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(glow_bottom)


func _build_header() -> void:
	var header := HBoxContainer.new()
	header.anchor_left = 0.045
	header.anchor_top = 0.035
	header.anchor_right = 0.955
	header.anchor_bottom = 0.145
	header.add_theme_constant_override("separation", 14)
	add_child(header)

	var brand := Label.new()
	brand.text = "CAR101"
	brand.add_theme_font_size_override("font_size", 30)
	brand.add_theme_color_override("font_color", Color("#54e0d0"))
	brand.add_theme_color_override("font_outline_color", Color(0.02, 0.10, 0.16, 0.8))
	brand.add_theme_constant_override("outline_size", 2)
	brand.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	header.add_child(brand)

	var divider := ColorRect.new()
	divider.custom_minimum_size = Vector2(2.0, 28.0)
	divider.color = Color("#31566a")
	divider.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	header.add_child(divider)

	var descriptor := Label.new()
	descriptor.text = "CITY DRIVE  /  OPEN WORLD"
	descriptor.add_theme_font_size_override("font_size", 12)
	descriptor.add_theme_color_override("font_color", Color("#91afc2"))
	descriptor.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	descriptor.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	header.add_child(descriptor)

	var build_badge := Label.new()
	build_badge.text = "  PREVIEW 0.8  "
	build_badge.add_theme_font_size_override("font_size", 12)
	build_badge.add_theme_color_override("font_color", Color("#ffd29a"))
	build_badge.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	build_badge.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	var badge_style := StyleBoxFlat.new()
	badge_style.bg_color = Color(0.86, 0.37, 0.17, 0.16)
	badge_style.border_color = Color(0.92, 0.52, 0.28, 0.48)
	badge_style.set_border_width_all(1)
	badge_style.set_corner_radius_all(14)
	build_badge.add_theme_stylebox_override("normal", badge_style)
	header.add_child(build_badge)


func _build_showcase(parent: Control) -> void:
	_showcase = Control.new()
	_showcase.name = "CityShowcase"
	_showcase.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_showcase.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_showcase.clip_contents = true
	parent.add_child(_showcase)

	var card := Panel.new()
	card.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	card.add_theme_stylebox_override("panel", _make_panel_style(Color("#10263b"), Color("#28556b"), 24))
	_showcase.add_child(card)

	var art := Control.new()
	art.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	art.set_script(MENU_ART_SCRIPT)
	card.add_child(art)

	var overlay := MarginContainer.new()
	overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	overlay.add_theme_constant_override("margin_left", 25)
	overlay.add_theme_constant_override("margin_right", 25)
	overlay.add_theme_constant_override("margin_top", 22)
	overlay.add_theme_constant_override("margin_bottom", 20)
	card.add_child(overlay)

	var column := VBoxContainer.new()
	column.add_theme_constant_override("separation", 8)
	overlay.add_child(column)

	var top_line := HBoxContainer.new()
	column.add_child(top_line)
	var tag := Label.new()
	tag.text = "  LIVE CITY  "
	tag.add_theme_font_size_override("font_size", 12)
	tag.add_theme_color_override("font_color", Color("#83f1d9"))
	tag.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	top_line.add_child(tag)
	var top_spacer := Control.new()
	top_spacer.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	top_line.add_child(top_spacer)
	var online := Label.new()
	online.text = "●  FREE DRIVE"
	online.add_theme_font_size_override("font_size", 12)
	online.add_theme_color_override("font_color", Color("#ffd09c"))
	online.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	top_line.add_child(online)

	var hero_space := Control.new()
	hero_space.size_flags_vertical = Control.SIZE_EXPAND_FILL
	column.add_child(hero_space)

	var hero_title := Label.new()
	hero_title.text = "EXPLORE\nEVERY STREET"
	hero_title.add_theme_font_size_override("font_size", 34)
	hero_title.add_theme_color_override("font_color", Color(0.90, 0.96, 0.98, 0.88))
	hero_title.add_theme_color_override("font_outline_color", Color(0.03, 0.10, 0.17, 0.72))
	hero_title.add_theme_constant_override("outline_size", 2)
	hero_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	hero_title.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	column.add_child(hero_title)

	var stats_space := Control.new()
	stats_space.size_flags_vertical = Control.SIZE_EXPAND_FILL
	column.add_child(stats_space)

	var stats := HBoxContainer.new()
	stats.add_theme_constant_override("separation", 10)
	column.add_child(stats)
	_add_stat(stats, "CITY", "۳ منطقهٔ شهری", "3 CITY DISTRICTS")
	_add_stat(stats, "TRAFFIC", "رفت‌وآمد هوشمند", "SMART TRAFFIC")
	_add_stat(stats, "GARAGE", "مالکیت و ارتقا", "CAR UPGRADES")


func _add_stat(parent: HBoxContainer, heading: String, fa_value: String, en_value: String) -> void:
	var card := PanelContainer.new()
	card.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var style := StyleBoxFlat.new()
	style.bg_color = Color(0.035, 0.11, 0.17, 0.82)
	style.border_color = Color(0.24, 0.57, 0.62, 0.50)
	style.set_border_width_all(1)
	style.set_corner_radius_all(12)
	card.add_theme_stylebox_override("panel", style)
	parent.add_child(card)

	var margin := MarginContainer.new()
	margin.add_theme_constant_override("margin_left", 10)
	margin.add_theme_constant_override("margin_right", 10)
	margin.add_theme_constant_override("margin_top", 8)
	margin.add_theme_constant_override("margin_bottom", 8)
	card.add_child(margin)
	var content := VBoxContainer.new()
	content.add_theme_constant_override("separation", 3)
	margin.add_child(content)
	var title := Label.new()
	title.text = heading
	title.add_theme_font_size_override("font_size", 10)
	title.add_theme_color_override("font_color", Color("#55d9ca"))
	content.add_child(title)
	var value := Label.new()
	value.text = fa_value if str(SettingsManager.get_setting("language", "fa")) == "fa" else en_value
	value.add_theme_font_size_override("font_size", 12)
	value.add_theme_color_override("font_color", Color("#e2edf2"))
	value.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	content.add_child(value)


func _show_home() -> void:
	_view = "home"
	_update_layout_direction()
	_clear_body()
	_add_label(_t("phase_tag"), 11, false, Color("#59dcca"), true)
	_add_spacer(9)
	_add_label(_t("title"), 30, false, Color("#f3f8fa"), true)
	_add_label(_t("subtitle"), 14, false, Color("#a9c0ce"), false)
	_add_spacer(13)

	var start_button := _make_button(_t("start"), _on_start_pressed, true)
	_card_body.add_child(start_button)
	var settings_button := _make_button(_t("settings"), _show_settings, false)
	_card_body.add_child(settings_button)
	var quit_button := _make_button(_t("quit"), _on_quit_pressed, false, true)
	_card_body.add_child(quit_button)

	_add_spacer(5)
	_add_label(_t("start_hint"), 12, true, Color("#f1be86"), false)
	_add_spacer(4)
	_add_label(_t("version"), 10, true, Color("#718fa3"), false)


func _show_settings() -> void:
	_view = "settings"
	_update_layout_direction()
	_clear_body()
	_add_label(_t("settings_title"), 26, true, Color("#f3f8fa"), true)
	_add_spacer(3)
	_add_option_row("language", _t("language"), [
		{"label": _t("language_fa"), "value": "fa"},
		{"label": _t("language_en"), "value": "en"}
	])
	_add_option_row("quality", _t("quality"), [
		{"label": _t("quality_low"), "value": "low"},
		{"label": _t("quality_balanced"), "value": "balanced"},
		{"label": _t("quality_high"), "value": "high"}
	])
	_add_option_row("control_scheme", _t("controls"), [
		{"label": _t("controls_auto"), "value": "auto"},
		{"label": _t("controls_touch"), "value": "touch"},
		{"label": _t("controls_keyboard"), "value": "keyboard"}
	])
	_add_volume_row("master_volume", _t("master_volume"))
	_add_volume_row("music_volume", _t("music_volume"))
	_add_volume_row("sfx_volume", _t("sfx_volume"))

	var fullscreen := CheckButton.new()
	fullscreen.text = _t("fullscreen")
	fullscreen.button_pressed = bool(SettingsManager.get_setting("fullscreen", false))
	fullscreen.toggled.connect(func(enabled: bool) -> void:
		SettingsManager.set_setting("fullscreen", enabled)
	)
	_card_body.add_child(fullscreen)
	_add_label(_t("settings_note"), 11, false, Color("#9eb7c6"), false)
	_card_body.add_child(_make_button(_t("back"), _show_home, false, true))


func _add_option_row(key: String, title: String, choices: Array[Dictionary]) -> void:
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 8)
	var label := Label.new()
	label.text = title
	label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	label.add_theme_font_size_override("font_size", 13)
	label.add_theme_color_override("font_color", Color("#d9e7ee"))
	row.add_child(label)

	var option := OptionButton.new()
	option.custom_minimum_size = Vector2(145.0, 38.0)
	for choice in choices:
		option.add_item(str(choice["label"]))
		option.set_item_metadata(option.item_count - 1, choice["value"])
	var selected_value: Variant = SettingsManager.get_setting(key)
	for index in range(option.item_count):
		if option.get_item_metadata(index) == selected_value:
			option.select(index)
			break
	option.item_selected.connect(func(index: int) -> void:
		var new_value: Variant = option.get_item_metadata(index)
		SettingsManager.set_setting(key, new_value)
		if key == "language":
			call_deferred("_show_settings")
	)
	row.add_child(option)
	_card_body.add_child(row)


func _add_volume_row(key: String, title: String) -> void:
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 8)
	var label := Label.new()
	label.text = title
	label.custom_minimum_size = Vector2(94.0, 0.0)
	label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	label.add_theme_font_size_override("font_size", 12)
	label.add_theme_color_override("font_color", Color("#d9e7ee"))
	row.add_child(label)

	var slider := HSlider.new()
	slider.min_value = 0.0
	slider.max_value = 1.0
	slider.step = 0.05
	slider.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	slider.value = float(SettingsManager.get_setting(key, 0.8))
	var value_label := Label.new()
	value_label.custom_minimum_size = Vector2(40.0, 0.0)
	value_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	value_label.add_theme_color_override("font_color", Color("#71e2d1"))
	value_label.text = "%d%%" % int(slider.value * 100.0)
	slider.value_changed.connect(func(value: float) -> void:
		value_label.text = "%d%%" % int(value * 100.0)
		SettingsManager.set_setting(key, value)
	)
	row.add_child(slider)
	row.add_child(value_label)
	_card_body.add_child(row)


func _make_button(text_value: String, callback: Callable, primary: bool = false, subtle: bool = false) -> Button:
	var button := Button.new()
	button.text = text_value
	button.custom_minimum_size = Vector2(0.0, 48.0 if not primary else 56.0)
	button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	button.focus_mode = Control.FOCUS_ALL
	button.add_theme_font_size_override("font_size", 16 if primary else 13)
	button.add_theme_color_override("font_color", Color("#082430") if primary else Color("#e6f1f5"))
	button.add_theme_color_override("font_hover_color", Color("#061e2a") if primary else Color("#ffffff"))
	button.add_theme_color_override("font_pressed_color", Color("#082430") if primary else Color("#ffffff"))
	var normal := StyleBoxFlat.new()
	if primary:
		normal.bg_color = Color("#4bd8c8")
	elif subtle:
		normal.bg_color = Color(0.10, 0.22, 0.32, 0.55)
	else:
		normal.bg_color = Color("#1b4055")
	normal.border_color = Color("#74f0db") if primary else Color("#3b6b7e")
	normal.set_border_width_all(1)
	normal.set_corner_radius_all(13)
	normal.content_margin_left = 14.0
	normal.content_margin_right = 14.0
	var hover := normal.duplicate() as StyleBoxFlat
	hover.bg_color = Color("#78eadb") if primary else Color("#28546b")
	var pressed := normal.duplicate() as StyleBoxFlat
	pressed.bg_color = Color("#29b6aa") if primary else Color("#153449")
	button.add_theme_stylebox_override("normal", normal)
	button.add_theme_stylebox_override("hover", hover)
	button.add_theme_stylebox_override("pressed", pressed)
	button.add_theme_stylebox_override("focus", hover)
	if callback.is_valid():
		button.pressed.connect(callback)
	return button


func _add_label(text_value: String, font_size: int, centered: bool, color: Color, strong: bool) -> Label:
	var label := Label.new()
	label.text = text_value
	label.add_theme_font_size_override("font_size", font_size)
	label.add_theme_color_override("font_color", color)
	if strong:
		label.add_theme_color_override("font_outline_color", Color(0.02, 0.08, 0.13, 0.35))
		label.add_theme_constant_override("outline_size", 1)
	label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER if centered else HORIZONTAL_ALIGNMENT_LEFT
	label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_card_body.add_child(label)
	return label


func _add_spacer(height: float) -> void:
	var spacer := Control.new()
	spacer.custom_minimum_size.y = height
	_card_body.add_child(spacer)


func _clear_body() -> void:
	for child in _card_body.get_children():
		_card_body.remove_child(child)
		child.queue_free()


func _on_start_pressed() -> void:
	var error := get_tree().change_scene_to_file(LOADING_SCENE_PATH)
	if error != OK:
		push_error("MainMenu: could not open the loading screen (error %s)." % str(error))


func _on_quit_pressed() -> void:
	if OS.has_feature("mobile"):
		_add_label(_t("quit_mobile"), 12, true, Color("#ffd09c"), false)
	else:
		get_tree().quit()


func _make_panel_style(background: Color, border: Color, radius: int) -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color = background
	style.border_color = border
	style.set_border_width_all(1)
	style.set_corner_radius_all(radius)
	return style


func _t(key: String) -> String:
	var locale := str(SettingsManager.get_setting("language", "fa"))
	var selected_texts: Dictionary = TEXTS.get(locale, TEXTS["fa"])
	return str(selected_texts.get(key, key))


func _update_layout_direction() -> void:
	var locale := str(SettingsManager.get_setting("language", "fa"))
	var direction := Control.LAYOUT_DIRECTION_RTL if locale == "fa" else Control.LAYOUT_DIRECTION_LTR
	layout_direction = direction
	_left_panel.layout_direction = direction
	_card_body.layout_direction = direction
