extends VehicleBody3D
class_name CarController

## Arcade driving controller built on Godot's VehicleBody3D suspension model.
## Forward throttle, service brake, and reverse are intentionally separate inputs.

@export_range(10.0, 150.0, 1.0) var maximum_engine_force: float = 55.0
@export_range(5.0, 60.0, 1.0) var service_brake_force: float = 28.0
@export_range(5.0, 70.0, 1.0) var handbrake_force: float = 38.0
@export_range(0.1, 0.8, 0.01) var maximum_steering_angle: float = 0.44
@export_range(1.0, 12.0, 0.1) var steering_response: float = 5.0
@export_range(10.0, 70.0, 1.0) var forward_speed_limit_kmh: float = 155.0
@export_range(5.0, 40.0, 1.0) var reverse_speed_limit_kmh: float = 28.0
@export var vehicle_id: String = "starter_sedan"
@export var vehicle_display_name: String = "سدان شهری"
@export var vehicle_body_style: String = "sedan"

@onready var rear_left_wheel: VehicleWheel3D = $RearLeft
@onready var rear_right_wheel: VehicleWheel3D = $RearRight

var _touch_inputs: Dictionary = {
	"accelerate": false,
	"brake": false,
	"reverse": false,
	"steer_left": false,
	"steer_right": false,
	"handbrake": false
}
var _gear_label: String = "D"
var _last_speed_kmh: float = 0.0
var _driving_enabled: bool = true


func _ready() -> void:
	add_to_group("drivable_vehicles")
	_install_input_map()
	# Include the dedicated civilian-traffic and police layers so collisions are
	# symmetric with the AI vehicles' masks rather than merely visual overlaps.
	collision_mask |= 8 | 16
	can_sleep = false
	continuous_cd = true
	contact_monitor = true
	max_contacts_reported = 8


func _physics_process(delta: float) -> void:
	if not _driving_enabled:
		engine_force = 0.0
		brake = service_brake_force
		steering = 0.0
		rear_left_wheel.brake = handbrake_force
		rear_right_wheel.brake = handbrake_force
		_gear_label = "P"
		return

	var accelerate_input := maxf(
		Input.get_action_strength("drive_accelerate"),
		1.0 if bool(_touch_inputs["accelerate"]) else 0.0
	)
	var brake_input := maxf(
		Input.get_action_strength("drive_brake"),
		1.0 if bool(_touch_inputs["brake"]) else 0.0
	)
	var reverse_input := maxf(
		Input.get_action_strength("drive_reverse"),
		1.0 if bool(_touch_inputs["reverse"]) else 0.0
	)
	var handbrake_input := maxf(
		Input.get_action_strength("drive_handbrake"),
		1.0 if bool(_touch_inputs["handbrake"]) else 0.0
	)
	var steer_left := maxf(
		Input.get_action_strength("drive_left"),
		1.0 if bool(_touch_inputs["steer_left"]) else 0.0
	)
	var steer_right := maxf(
		Input.get_action_strength("drive_right"),
		1.0 if bool(_touch_inputs["steer_right"]) else 0.0
	)
	var steer_input := clampf(steer_right - steer_left, -1.0, 1.0)

	_last_speed_kmh = linear_velocity.length() * 3.6
	var forward_speed_kmh := linear_velocity.dot(global_basis.z) * 3.6
	var speed_steer_factor := lerpf(1.0, 0.62, clampf(_last_speed_kmh / 150.0, 0.0, 1.0))
	var steering_target := steer_input * maximum_steering_angle * speed_steer_factor
	steering = move_toward(steering, steering_target, steering_response * delta)

	# The brake pedal never changes direction. Reverse is selected explicitly.
	if brake_input > 0.05:
		engine_force = 0.0
		brake = service_brake_force * brake_input
		_gear_label = "D" if forward_speed_kmh >= -1.0 else "R"
	elif reverse_input > 0.05:
		_gear_label = "R"
		if forward_speed_kmh > 2.0:
			engine_force = 0.0
			brake = service_brake_force
		elif forward_speed_kmh > -reverse_speed_limit_kmh:
			brake = 0.0
			engine_force = -maximum_engine_force * reverse_input
		else:
			brake = 0.0
			engine_force = 0.0
	elif accelerate_input > 0.05:
		_gear_label = "D"
		if forward_speed_kmh < -2.0:
			engine_force = 0.0
			brake = service_brake_force * 0.8
		elif forward_speed_kmh < forward_speed_limit_kmh:
			brake = 0.0
			engine_force = maximum_engine_force * accelerate_input
		else:
			brake = 0.0
			engine_force = 0.0
	else:
		engine_force = 0.0
		brake = 0.0
		_gear_label = "D" if forward_speed_kmh >= -1.0 else "R"

	rear_left_wheel.brake = handbrake_force * handbrake_input
	rear_right_wheel.brake = handbrake_force * handbrake_input

	if Input.is_action_just_pressed("vehicle_reset"):
		reset_vehicle()


func configure_vehicle_variant(
	new_vehicle_id: String,
	display_name: String,
	paint_color: Color,
	vehicle_mass: float,
	engine_force: float,
	maximum_speed_kmh: float,
	steering_angle: float,
	body_style: String = "sedan"
) -> void:
	vehicle_id = new_vehicle_id.strip_edges()
	vehicle_display_name = display_name.strip_edges()
	mass = maxf(vehicle_mass, 500.0)
	maximum_engine_force = maxf(engine_force, 10.0)
	forward_speed_limit_kmh = maxf(maximum_speed_kmh, 40.0)
	maximum_steering_angle = clampf(steering_angle, 0.1, 0.8)
	vehicle_body_style = body_style.strip_edges().to_lower()
	var paint := StandardMaterial3D.new()
	paint.albedo_color = paint_color
	paint.metallic = 0.42
	paint.roughness = 0.3
	for node_name in ["Body", "FrontBumper", "RearBumper"]:
		var mesh_node := get_node_or_null(NodePath(node_name)) as MeshInstance3D
		if mesh_node != null:
			mesh_node.material_override = paint
	_apply_body_style()


func _apply_body_style() -> void:
	var cabin := get_node_or_null("Cabin") as MeshInstance3D
	var body := get_node_or_null("Body") as MeshInstance3D
	if cabin == null:
		return
	match vehicle_body_style:
		"coupe":
			cabin.position.y = 0.94
			cabin.scale = Vector3(1.0, 0.74, 0.88)
		"suv":
			cabin.position.y = 1.09
			cabin.scale = Vector3(1.06, 1.18, 1.06)
			if body != null:
				body.scale = Vector3(1.04, 1.05, 1.03)
			_add_suv_roof_rails()
		_:
			cabin.position.y = 1.02
			cabin.scale = Vector3.ONE


func _add_suv_roof_rails() -> void:
	var rail_material := StandardMaterial3D.new()
	rail_material.albedo_color = Color("#202a31")
	rail_material.metallic = 0.55
	rail_material.roughness = 0.48
	for side in [-1.0, 1.0]:
		var rail := MeshInstance3D.new()
		rail.name = "RoofRail_%s" % str(side)
		var rail_mesh := BoxMesh.new()
		rail_mesh.size = Vector3(0.075, 0.07, 1.32)
		rail.mesh = rail_mesh
		rail.position = Vector3(float(side) * 0.57, 1.51, 0.24)
		rail.material_override = rail_material
		add_child(rail)


func get_display_name() -> String:
	return vehicle_display_name if not vehicle_display_name.is_empty() else "خودرو"


func set_driving_enabled(enabled: bool) -> void:
	_driving_enabled = enabled
	if not enabled:
		for action_name in _touch_inputs.keys():
			_touch_inputs[action_name] = false
		engine_force = 0.0
		brake = service_brake_force
		steering = 0.0
		rear_left_wheel.brake = handbrake_force
		rear_right_wheel.brake = handbrake_force
	else:
		brake = 0.0
		rear_left_wheel.brake = 0.0
		rear_right_wheel.brake = 0.0
	_gear_label = "D" if enabled else "P"


func is_driving_enabled() -> bool:
	return _driving_enabled


func set_touch_control(action_name: String, pressed: bool) -> void:
	if _touch_inputs.has(action_name):
		_touch_inputs[action_name] = pressed


func clear_touch_controls() -> void:
	for action_name in _touch_inputs.keys():
		_touch_inputs[action_name] = false


func get_speed_kmh() -> float:
	return linear_velocity.length() * 3.6


func get_forward_speed_kmh() -> float:
	return linear_velocity.dot(global_basis.z) * 3.6


func get_gear_label() -> String:
	return _gear_label


func reset_vehicle() -> void:
	global_position += Vector3.UP * 1.25
	global_rotation = Vector3(0.0, global_rotation.y, 0.0)
	linear_velocity = Vector3.ZERO
	angular_velocity = Vector3.ZERO
	steering = 0.0
	engine_force = 0.0
	brake = 0.0


func _install_input_map() -> void:
	_add_action_keys("drive_accelerate", [KEY_W, KEY_UP])
	_add_action_keys("drive_brake", [KEY_S, KEY_DOWN])
	_add_action_keys("drive_reverse", [KEY_R])
	_add_action_keys("drive_left", [KEY_A, KEY_LEFT])
	_add_action_keys("drive_right", [KEY_D, KEY_RIGHT])
	_add_action_keys("drive_handbrake", [KEY_SPACE])
	_add_action_keys("vehicle_reset", [KEY_BACKSPACE])


func _add_action_keys(action_name: String, key_codes: Array) -> void:
	if not InputMap.has_action(action_name):
		InputMap.add_action(action_name)
	for raw_key_code in key_codes:
		var key_code := int(raw_key_code)
		var already_bound := false
		for existing_event in InputMap.action_get_events(action_name):
			if existing_event is InputEventKey and existing_event.physical_keycode == key_code:
				already_bound = true
				break
		if already_bound:
			continue
		var key_event := InputEventKey.new()
		key_event.physical_keycode = key_code
		key_event.keycode = key_code
		InputMap.action_add_event(action_name, key_event)
