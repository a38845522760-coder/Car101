extends Node3D
class_name VehicleInteractionManager

## Coordinates walking, vehicle entry/exit, and switching between parked cars.
signal active_vehicle_changed(vehicle: CarController)

const EXIT_SPEED_LIMIT_KMH: float = 8.0
const INTERACTION_DISTANCE: float = 5.5
const GARAGE_CENTER: Vector3 = Vector3(36.0, 0.0, -180.0)
const GARAGE_RADIUS: float = 38.0

var player_car: CarController
var character: PlayerCharacter
var car_camera: Node3D
var foot_camera: Node3D
var is_driving: bool = true
var available_vehicles: Array[CarController] = []
var _message: String = ""
var _message_timer: float = 0.0


func _ready() -> void:
	_install_input_map()


func configure(
	car: CarController,
	player_character: PlayerCharacter,
	vehicle_camera: Node3D,
	walking_camera: Node3D
) -> void:
	player_car = car
	character = player_character
	car_camera = vehicle_camera
	foot_camera = walking_camera
	available_vehicles.clear()
	register_vehicle(car, false)
	if character != null:
		character.set_camera_rig(foot_camera)
		character.visible = false
		character.set_character_active(false)
	if car_camera != null:
		if car_camera.has_method("set_target"):
			car_camera.call("set_target", player_car)
		car_camera.call("set_camera_active", true)
	if foot_camera != null:
		foot_camera.call("set_camera_active", false)
	is_driving = true


func register_vehicle(vehicle: CarController, start_parked: bool = true) -> void:
	if vehicle == null or not is_instance_valid(vehicle):
		return
	if not available_vehicles.has(vehicle):
		available_vehicles.append(vehicle)
	vehicle.add_to_group("drivable_vehicles")
	if VehicleEconomy.is_vehicle_owned(vehicle.vehicle_id):
		VehicleEconomy.apply_upgrades(vehicle)
	if start_parked and vehicle != player_car:
		vehicle.set_driving_enabled(false)


func get_registered_vehicle_count() -> int:
	var count := 0
	for vehicle in available_vehicles:
		if is_instance_valid(vehicle) and not vehicle.is_queued_for_deletion():
			count += 1
	return count


func _process(delta: float) -> void:
	_message_timer = maxf(0.0, _message_timer - delta)
	if _message_timer <= 0.0:
		_message = ""


func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("vehicle_interact"):
		toggle_vehicle()
		get_viewport().set_input_as_handled()


func toggle_vehicle() -> void:
	if character == null or not is_instance_valid(character):
		return
	if is_driving:
		_exit_vehicle()
	else:
		_enter_vehicle()


func get_interaction_prompt() -> String:
	if _message_timer > 0.0:
		return _message
	if is_driving:
		if player_car != null and player_car.get_speed_kmh() > EXIT_SPEED_LIMIT_KMH:
			return "برای پیاده‌شدن، خودرو را متوقف کن"
		return "F  •  پیاده‌شدن"
	var nearby_vehicle := _find_nearest_available_vehicle()
	if nearby_vehicle != null:
		if not VehicleEconomy.is_vehicle_owned(nearby_vehicle.vehicle_id):
			var price := int(nearby_vehicle.get_meta("purchase_price", 0))
			if GameState.money < price:
				return "سکه کافی نیست | %s سکه لازم است" % str(price)
			return "E  •  خرید %s | %s سکه" % [nearby_vehicle.get_display_name(), str(price)]
		return "E  •  سوارشدن به %s" % nearby_vehicle.get_display_name()
	return "برای سوارشدن به خودرو نزدیک شو"


func can_interact() -> bool:
	if player_car == null or not is_instance_valid(player_car):
		return false
	if is_driving:
		return player_car.get_speed_kmh() <= EXIT_SPEED_LIMIT_KMH
	var nearby_vehicle := _find_nearest_available_vehicle()
	if nearby_vehicle == null:
		return false
	if not VehicleEconomy.is_vehicle_owned(nearby_vehicle.vehicle_id):
		return GameState.money >= int(nearby_vehicle.get_meta("purchase_price", 0))
	return true


func get_mode_label() -> String:
	if not is_driving:
		return "حالت پیاده"
	var vehicle_name := player_car.get_display_name() if player_car != null and is_instance_valid(player_car) else "خودرو"
	return "رانندگی: %s" % vehicle_name


func get_garage_target_vehicle() -> CarController:
	if is_driving:
		if player_car == null or not is_instance_valid(player_car):
			return null
		if player_car.get_speed_kmh() > 1.0 or _distance_to_garage(player_car.global_position) > GARAGE_RADIUS:
			return null
		return player_car
	if character == null or not is_instance_valid(character):
		return null
	if _distance_to_garage(character.global_position) > GARAGE_RADIUS:
		return null
	return _find_nearest_owned_vehicle(7.0)


func can_open_garage() -> bool:
	return get_garage_target_vehicle() != null


func _distance_to_garage(position: Vector3) -> float:
	return Vector2(position.x - GARAGE_CENTER.x, position.z - GARAGE_CENTER.z).length()


func _find_nearest_owned_vehicle(max_distance: float) -> CarController:
	if character == null or not is_instance_valid(character):
		return null
	var nearest_vehicle: CarController = null
	var nearest_distance := max_distance
	for vehicle in available_vehicles:
		if vehicle == null or not is_instance_valid(vehicle) or vehicle.is_queued_for_deletion():
			continue
		if not VehicleEconomy.is_vehicle_owned(vehicle.vehicle_id):
			continue
		var distance := character.global_position.distance_to(vehicle.global_position)
		if distance <= nearest_distance:
			nearest_distance = distance
			nearest_vehicle = vehicle
	return nearest_vehicle


func set_character_touch(action_name: String, pressed: bool) -> void:
	if character != null and is_instance_valid(character):
		character.set_touch_control(action_name, pressed)


func clear_touch_controls() -> void:
	for vehicle in available_vehicles:
		if is_instance_valid(vehicle):
			vehicle.clear_touch_controls()
	if character != null and is_instance_valid(character):
		character.clear_touch_controls()


func _exit_vehicle() -> void:
	if player_car == null or not is_instance_valid(player_car):
		_set_message("خودروی فعلی در دسترس نیست")
		return
	if player_car.get_speed_kmh() > EXIT_SPEED_LIMIT_KMH:
		_set_message("ابتدا خودرو را تقریباً متوقف کن")
		return

	var side_direction := player_car.global_basis.x.normalized()
	var exit_position := player_car.global_position + side_direction * 2.35 + (-player_car.global_basis.z.normalized() * 0.35)
	exit_position.y = 0.22
	character.global_position = exit_position
	character.global_rotation.y = player_car.global_rotation.y
	character.velocity = Vector3.ZERO
	character.visible = true
	character.set_character_active(true)

	player_car.linear_velocity = Vector3.ZERO
	player_car.angular_velocity = Vector3.ZERO
	player_car.set_driving_enabled(false)
	is_driving = false
	if car_camera != null:
		car_camera.call("set_camera_active", false)
	if foot_camera != null:
		foot_camera.call("set_camera_active", true)
	_set_message("از %s پیاده شدی" % player_car.get_display_name())


func _enter_vehicle() -> void:
	var selected_vehicle := _find_nearest_available_vehicle()
	if selected_vehicle == null:
		_set_message("خودروی قابل‌استفاده‌ای در محدوده نیست")
		return
	if selected_vehicle.get_speed_kmh() > EXIT_SPEED_LIMIT_KMH:
		_set_message("ابتدا صبر کن خودرو متوقف شود")
		return
	var purchase_completed := false
	if not VehicleEconomy.is_vehicle_owned(selected_vehicle.vehicle_id):
		var purchase_price := int(selected_vehicle.get_meta("purchase_price", 0))
		if not VehicleEconomy.purchase_vehicle(selected_vehicle.vehicle_id, purchase_price):
			_set_message("سکه کافی نیست؛ برای خرید %s سکه لازم است" % str(purchase_price))
			return
		VehicleEconomy.apply_upgrades(selected_vehicle)
		purchase_completed = true

	var vehicle_changed := selected_vehicle != player_car
	for vehicle in available_vehicles:
		if is_instance_valid(vehicle) and vehicle != selected_vehicle:
			vehicle.set_driving_enabled(false)

	player_car = selected_vehicle
	player_car.linear_velocity = Vector3.ZERO
	player_car.angular_velocity = Vector3.ZERO
	character.velocity = Vector3.ZERO
	character.set_character_active(false)
	character.visible = false
	player_car.set_driving_enabled(true)
	is_driving = true
	if car_camera != null:
		if car_camera.has_method("set_target"):
			car_camera.call("set_target", player_car)
		car_camera.call("set_camera_active", true)
	if foot_camera != null:
		foot_camera.call("set_camera_active", false)
	if vehicle_changed:
		active_vehicle_changed.emit(player_car)
	if purchase_completed:
		_set_message("%s خریداری شد؛ اکنون سوارش هستی" % player_car.get_display_name())
	else:
		_set_message("سوار %s شدی" % player_car.get_display_name())


func _find_nearest_available_vehicle() -> CarController:
	if character == null or not is_instance_valid(character):
		return null
	var nearest_vehicle: CarController = null
	var nearest_distance := INTERACTION_DISTANCE
	for vehicle in available_vehicles:
		if vehicle == null or not is_instance_valid(vehicle) or vehicle.is_queued_for_deletion():
			continue
		if vehicle.is_driving_enabled() or vehicle.get_speed_kmh() > EXIT_SPEED_LIMIT_KMH:
			continue
		var distance := character.global_position.distance_to(vehicle.global_position)
		if distance <= nearest_distance:
			nearest_distance = distance
			nearest_vehicle = vehicle
	return nearest_vehicle


func _set_message(message: String) -> void:
	_message = message
	_message_timer = 2.5


func _install_input_map() -> void:
	if not InputMap.has_action("vehicle_interact"):
		InputMap.add_action("vehicle_interact")
	for key_code in [KEY_F, KEY_E]:
		var exists := false
		for event in InputMap.action_get_events("vehicle_interact"):
			if event is InputEventKey and event.physical_keycode == key_code:
				exists = true
				break
		if not exists:
			var key_event := InputEventKey.new()
			key_event.physical_keycode = key_code
			key_event.keycode = key_code
			InputMap.action_add_event("vehicle_interact", key_event)
