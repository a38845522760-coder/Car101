extends Node3D

const PLAYER_CAR_SCENE: PackedScene = preload("res://scenes/vehicles/player_car.tscn")
const CAMERA_FOLLOW_SCRIPT: Script = preload("res://scripts/camera/camera_follow.gd")
const DRIVING_HUD_SCRIPT: Script = preload("res://scripts/ui/driving_hud.gd")

var _road_material: StandardMaterial3D
var _ground_material: StandardMaterial3D


func _ready() -> void:
	_build_environment()
	_create_materials()
	_build_ground()
	_build_track()
	_build_test_buildings()
	_spawn_player_and_ui()


func _build_environment() -> void:
	var world_environment := WorldEnvironment.new()
	world_environment.name = "WorldEnvironment"
	var environment := Environment.new()
	environment.background_mode = Environment.BG_SKY
	environment.sky = Sky.new()
	var sky_material := ProceduralSkyMaterial.new()
	sky_material.sky_top_color = Color("#4b78a1")
	sky_material.sky_horizon_color = Color("#b8c8d2")
	sky_material.ground_bottom_color = Color("#27333b")
	sky_material.ground_horizon_color = Color("#87979a")
	environment.sky.sky_material = sky_material
	environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	environment.ambient_light_color = Color("#9eafbd")
	environment.ambient_light_energy = 0.55
	world_environment.environment = environment
	add_child(world_environment)

	var sun := DirectionalLight3D.new()
	sun.name = "Sun"
	sun.rotation_degrees = Vector3(-48.0, -28.0, 0.0)
	sun.light_energy = 1.1
	sun.shadow_enabled = true
	add_child(sun)


func _create_materials() -> void:
	_ground_material = _make_material(Color("#50634f"), 1.0)
	_road_material = _make_material(Color("#303943"), 0.95)


func _build_ground() -> void:
	_add_static_box(
		"Ground",
		Vector3(0.0, -0.55, 0.0),
		Vector3(240.0, 1.0, 240.0),
		_ground_material,
		true
	)


func _build_track() -> void:
	# A temporary rectangular test circuit; Phase 3 replaces it with the selected city map.
	_add_static_box("Road_North", Vector3(0.0, 0.075, -35.0), Vector3(100.0, 0.15, 14.0), _road_material, true)
	_add_static_box("Road_South", Vector3(0.0, 0.075, 35.0), Vector3(100.0, 0.15, 14.0), _road_material, true)
	_add_static_box("Road_East", Vector3(43.0, 0.075, 0.0), Vector3(14.0, 0.15, 70.0), _road_material, true)
	_add_static_box("Road_West", Vector3(-43.0, 0.075, 0.0), Vector3(14.0, 0.15, 70.0), _road_material, true)

	var yellow_line := _make_material(Color("#e9d47a"), 0.8)
	_add_visual_box("Marking_North", Vector3(0.0, 0.158, -35.0), Vector3(99.0, 0.025, 0.18), yellow_line)
	_add_visual_box("Marking_South", Vector3(0.0, 0.158, 35.0), Vector3(99.0, 0.025, 0.18), yellow_line)
	_add_visual_box("Marking_East", Vector3(43.0, 0.158, 0.0), Vector3(0.18, 0.025, 69.0), yellow_line)
	_add_visual_box("Marking_West", Vector3(-43.0, 0.158, 0.0), Vector3(0.18, 0.025, 69.0), yellow_line)

	var edge_material := _make_material(Color("#9aa4a9"), 0.7)
	for index in range(8):
		var x_position := -42.0 + float(index) * 12.0
		_add_visual_box("North_Dash_%02d" % index, Vector3(x_position, 0.17, -29.6), Vector3(4.5, 0.025, 0.12), edge_material)
		_add_visual_box("South_Dash_%02d" % index, Vector3(x_position, 0.17, 29.6), Vector3(4.5, 0.025, 0.12), edge_material)


func _build_test_buildings() -> void:
	var building_colors: Array[Color] = [
		Color("#66717a"), Color("#7a7770"), Color("#667c80"), Color("#80776c")
	]
	var buildings: Array[Dictionary] = [
		{"position": Vector3(-18.0, 0.0, -59.0), "size": Vector3(22.0, 15.0, 20.0)},
		{"position": Vector3(20.0, 0.0, -60.0), "size": Vector3(25.0, 19.0, 18.0)},
		{"position": Vector3(-18.0, 0.0, 60.0), "size": Vector3(25.0, 18.0, 18.0)},
		{"position": Vector3(20.0, 0.0, 60.0), "size": Vector3(20.0, 13.0, 21.0)},
		{"position": Vector3(-65.0, 0.0, -18.0), "size": Vector3(20.0, 12.0, 22.0)},
		{"position": Vector3(-65.0, 0.0, 22.0), "size": Vector3(18.0, 16.0, 24.0)},
		{"position": Vector3(65.0, 0.0, -18.0), "size": Vector3(22.0, 17.0, 20.0)},
		{"position": Vector3(65.0, 0.0, 22.0), "size": Vector3(20.0, 14.0, 22.0)}
	]
	for index in range(buildings.size()):
		var building: Dictionary = buildings[index]
		var building_size: Vector3 = building.get("size", Vector3(12.0, 12.0, 12.0))
		var building_position: Vector3 = building.get("position", Vector3.ZERO)
		var building_material := _make_material(building_colors[index % building_colors.size()], 0.9)
		_add_static_box(
			"TestBuilding_%02d" % index,
			building_position + Vector3.UP * (building_size.y * 0.5),
			building_size,
			building_material,
			true
		)

	var barrier_material := _make_material(Color("#d7a64f"), 0.8)
	for barrier_index in range(6):
		var z_position := -18.0 + float(barrier_index) * 7.0
		_add_static_box(
			"ParkingBarrier_%02d" % barrier_index,
			Vector3(28.0, 0.5, z_position),
			Vector3(0.45, 1.0, 3.2),
			barrier_material,
			true
		)


func _spawn_player_and_ui() -> void:
	var player := PLAYER_CAR_SCENE.instantiate() as CarController
	player.name = "PlayerCar"
	player.position = Vector3(43.0, 0.92, -22.0)
	add_child(player)

	var camera_rig := Node3D.new()
	camera_rig.name = "CameraRig"
	camera_rig.set_script(CAMERA_FOLLOW_SCRIPT)
	camera_rig.set("target_path", NodePath("../PlayerCar"))
	add_child(camera_rig)

	var hud := CanvasLayer.new()
	hud.name = "DrivingHUD"
	hud.set_script(DRIVING_HUD_SCRIPT)
	hud.set("player_path", NodePath("../PlayerCar"))
	add_child(hud)


func _add_static_box(
	node_name: String,
	world_position: Vector3,
	box_size: Vector3,
	material: Material,
	with_collision: bool
) -> StaticBody3D:
	var body := StaticBody3D.new()
	body.name = node_name
	body.position = world_position
	body.collision_layer = 1
	body.collision_mask = 1
	add_child(body)

	var mesh_instance := MeshInstance3D.new()
	mesh_instance.name = "Mesh"
	var box_mesh := BoxMesh.new()
	box_mesh.size = box_size
	box_mesh.material = material
	mesh_instance.mesh = box_mesh
	body.add_child(mesh_instance)

	if with_collision:
		var collision := CollisionShape3D.new()
		collision.name = "CollisionShape3D"
		var box_shape := BoxShape3D.new()
		box_shape.size = box_size
		collision.shape = box_shape
		body.add_child(collision)
	return body


func _add_visual_box(node_name: String, world_position: Vector3, box_size: Vector3, material: Material) -> void:
	var mesh_instance := MeshInstance3D.new()
	mesh_instance.name = node_name
	mesh_instance.position = world_position
	var box_mesh := BoxMesh.new()
	box_mesh.size = box_size
	box_mesh.material = material
	mesh_instance.mesh = box_mesh
	add_child(mesh_instance)


func _make_material(albedo: Color, roughness_value: float) -> StandardMaterial3D:
	var material := StandardMaterial3D.new()
	material.albedo_color = albedo
	material.roughness = roughness_value
	return material
