extends Node3D
class_name CityWorld

## Procedurally assembled city map using the included Kenney CC0 GLB building kits.
## The road network and collision geometry are created once; model resources are cached.

const PLAYER_CAR_SCENE: PackedScene = preload("res://scenes/vehicles/player_car.tscn")
const PLAYER_CHARACTER_SCENE: PackedScene = preload("res://scenes/characters/player_character.tscn")
const CAMERA_FOLLOW_SCRIPT: Script = preload("res://scripts/camera/camera_follow.gd")
const DRIVING_HUD_SCRIPT: Script = preload("res://scripts/ui/driving_hud.gd")
const FOOT_CAMERA_SCRIPT: Script = preload("res://scripts/camera/foot_camera_follow.gd")
const VEHICLE_INTERACTION_SCRIPT: Script = preload("res://scripts/vehicles/vehicle_interaction_manager.gd")
const TRAFFIC_SIGNAL_MANAGER_SCRIPT: Script = preload("res://scripts/traffic/traffic_signal_manager.gd")
const TRAFFIC_MANAGER_SCRIPT: Script = preload("res://scripts/traffic/traffic_manager.gd")
const POLICE_MANAGER_SCRIPT: Script = preload("res://scripts/police/police_manager.gd")
const ASSET_CATALOG_PATH: String = "res://data/worlds/city_asset_catalog.json"
const PARKED_VEHICLES_CONFIG_PATH: String = "res://data/vehicles/parked_vehicles.json"

const GRID_COORDS: Array[float] = [-216.0, -144.0, -72.0, 0.0, 72.0, 144.0, 216.0]
const WORLD_HALF_EXTENT: float = 286.0
const ROAD_SPAN: float = 572.0
const MODEL_LETTERS: Array[String] = ["a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t"]
const ROAD_WIDTH: float = 13.0
const SIDEWALK_OFFSET: float = 8.1
const SIDEWALK_WIDTH: float = 2.5

var _rng := RandomNumberGenerator.new()
var _asset_catalog: Dictionary = {}
var _packed_scene_cache: Dictionary = {}
var _materials: Dictionary = {}
var _spawned_building_count: int = 0
var _spawned_prop_count: int = 0
var _model_instance_counter: int = 0
var _traffic_signal_manager: Node3D
var _parking_lots: Array = []


func _ready() -> void:
	_rng.seed = 101
	_load_asset_catalog()
	_load_parked_vehicle_config()
	_create_materials()
	_build_environment()
	_build_ground()
	_build_road_network()
	_build_city_blocks()
	_build_street_furniture()
	_build_district_markers()
	_traffic_signal_manager = TRAFFIC_SIGNAL_MANAGER_SCRIPT.new() as Node3D
	_traffic_signal_manager.name = "TrafficSignalManager"
	add_child(_traffic_signal_manager)
	_spawn_player_and_ui()
	print("Car101 City World ready: %d buildings, %d props, %d cached model scenes." % [
		_spawned_building_count, _spawned_prop_count, _packed_scene_cache.size()
	])


func _load_asset_catalog() -> void:
	if not FileAccess.file_exists(ASSET_CATALOG_PATH):
		push_warning("CityWorld: asset catalog is missing; placeholder buildings will be used.")
		return
	var file := FileAccess.open(ASSET_CATALOG_PATH, FileAccess.READ)
	if file == null:
		push_warning("CityWorld: could not read the asset catalog.")
		return
	var parsed: Variant = JSON.parse_string(file.get_as_text())
	if parsed is Dictionary:
		var root: Dictionary = parsed
		var models: Variant = root.get("models", {})
		if models is Dictionary:
			_asset_catalog = models


func _create_materials() -> void:
	_materials["ground"] = _make_material(Color("#65735a"), 1.0)
	_materials["road"] = _make_material(Color("#252d35"), 0.98)
	_materials["sidewalk"] = _make_material(Color("#969a98"), 0.9)
	_materials["curb"] = _make_material(Color("#c1c1b8"), 0.9)
	_materials["yellow_line"] = _make_material(Color("#e7c45e"), 0.72)
	_materials["white_line"] = _make_material(Color("#e9ece8"), 0.78)
	_materials["park"] = _make_material(Color("#526d4d"), 1.0)
	_materials["tree_trunk"] = _make_material(Color("#584437"), 1.0)
	_materials["tree_canopy"] = _make_material(Color("#416348"), 1.0)
	_materials["lamp_pole"] = _make_material(Color("#303940"), 0.68, 0.45)
	_materials["lamp_glow"] = _make_material(Color("#ffe6ad"), 0.45, 0.0, Color("#ffe0a0"), 1.1)
	_materials["traffic_dark"] = _make_material(Color("#27313a"), 0.72, 0.3)
	_materials["traffic_red"] = _make_material(Color("#b8423d"), 0.38, 0.0, Color("#e33e36"), 0.8)
	_materials["traffic_yellow"] = _make_material(Color("#b78b37"), 0.38, 0.0, Color("#e6b746"), 0.8)
	_materials["traffic_green"] = _make_material(Color("#3b8a5c"), 0.38, 0.0, Color("#4bc878"), 0.8)
	_materials["fence"] = _make_material(Color("#565f65"), 0.82, 0.5)
	_materials["bench"] = _make_material(Color("#725b43"), 0.92)


func _build_environment() -> void:
	var world_environment := WorldEnvironment.new()
	world_environment.name = "WorldEnvironment"
	var environment := Environment.new()
	environment.background_mode = Environment.BG_SKY
	environment.sky = Sky.new()
	var sky_material := ProceduralSkyMaterial.new()
	sky_material.sky_top_color = Color("#3f6f9a")
	sky_material.sky_horizon_color = Color("#c6d2d8")
	sky_material.ground_bottom_color = Color("#303b37")
	sky_material.ground_horizon_color = Color("#8c9a91")
	environment.sky.sky_material = sky_material
	environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	environment.ambient_light_color = Color("#a7b8c6")
	environment.ambient_light_energy = 0.62
	environment.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	world_environment.environment = environment
	add_child(world_environment)

	var sun := DirectionalLight3D.new()
	sun.name = "Sun"
	sun.rotation_degrees = Vector3(-48.0, -28.0, 0.0)
	sun.light_energy = 1.05
	var graphics_quality := str(SettingsManager.get_setting("quality", "balanced"))
	sun.shadow_enabled = graphics_quality != "low"
	sun.directional_shadow_max_distance = 180.0
	add_child(sun)


func _build_ground() -> void:
	_add_static_box(
		"CityGround",
		Vector3(0.0, -0.42, 0.0),
		Vector3(WORLD_HALF_EXTENT * 2.0 + 16.0, 0.8, WORLD_HALF_EXTENT * 2.0 + 16.0),
		_material("ground"),
		true
	)

	# A broad, low boundary curb keeps the vehicle inside the playable city while
	# leaving enough space for a future outer highway and streaming sectors.
	var boundary_material := _material("curb")
	_add_static_box("Boundary_North", Vector3(0.0, 0.42, -WORLD_HALF_EXTENT), Vector3(ROAD_SPAN + 22.0, 0.8, 1.2), boundary_material, true)
	_add_static_box("Boundary_South", Vector3(0.0, 0.42, WORLD_HALF_EXTENT), Vector3(ROAD_SPAN + 22.0, 0.8, 1.2), boundary_material, true)
	_add_static_box("Boundary_West", Vector3(-WORLD_HALF_EXTENT, 0.42, 0.0), Vector3(1.2, 0.8, ROAD_SPAN + 22.0), boundary_material, true)
	_add_static_box("Boundary_East", Vector3(WORLD_HALF_EXTENT, 0.42, 0.0), Vector3(1.2, 0.8, ROAD_SPAN + 22.0), boundary_material, true)


func _build_road_network() -> void:
	var road_material := _material("road")
	var sidewalk_material := _material("sidewalk")
	var curb_material := _material("curb")
	var yellow_material := _material("yellow_line")
	var white_material := _material("white_line")

	for road_index in range(GRID_COORDS.size()):
		var coordinate: float = GRID_COORDS[road_index]
		var width := ROAD_WIDTH + (3.0 if is_zero_approx(coordinate) else 0.0)
		_add_static_box(
			"Road_H_%02d" % road_index,
			Vector3(0.0, 0.035, coordinate),
			Vector3(ROAD_SPAN, 0.17, width),
			road_material,
			true
		)
		_add_static_box(
			"Road_V_%02d" % road_index,
			Vector3(coordinate, 0.035, 0.0),
			Vector3(width, 0.17, ROAD_SPAN),
			road_material,
			true
		)

		# Double yellow center lines on every street. The lines are split at
		# intersections so the crossing geometry remains visually clear.
		_add_visual_box(
			"Road_H_Center_%02d_A" % road_index,
			Vector3(0.0, 0.13, coordinate - 0.22),
			Vector3(ROAD_SPAN, 0.018, 0.10),
			yellow_material
		)
		_add_visual_box(
			"Road_H_Center_%02d_B" % road_index,
			Vector3(0.0, 0.13, coordinate + 0.22),
			Vector3(ROAD_SPAN, 0.018, 0.10),
			yellow_material
		)
		_add_visual_box(
			"Road_V_Center_%02d_A" % road_index,
			Vector3(coordinate - 0.22, 0.13, 0.0),
			Vector3(0.10, 0.018, ROAD_SPAN),
			yellow_material
		)
		_add_visual_box(
			"Road_V_Center_%02d_B" % road_index,
			Vector3(coordinate + 0.22, 0.13, 0.0),
			Vector3(0.10, 0.018, ROAD_SPAN),
			yellow_material
		)

		# Sidewalks and low curbs on both sides of every road.
		for side in [-1.0, 1.0]:
			var offset := side * SIDEWALK_OFFSET
			_add_static_box(
				"Sidewalk_H_%02d_%s" % [road_index, str(side)],
				Vector3(0.0, 0.12, coordinate + offset),
				Vector3(ROAD_SPAN, 0.2, SIDEWALK_WIDTH),
				sidewalk_material,
				true
			)
			_add_static_box(
				"Sidewalk_V_%02d_%s" % [road_index, str(side)],
				Vector3(coordinate + offset, 0.12, 0.0),
				Vector3(SIDEWALK_WIDTH, 0.2, ROAD_SPAN),
				sidewalk_material,
				true
			)
			_add_visual_box(
				"Curb_H_%02d_%s" % [road_index, str(side)],
				Vector3(0.0, 0.205, coordinate + side * 6.55),
				Vector3(ROAD_SPAN, 0.08, 0.18),
				curb_material
			)
			_add_visual_box(
				"Curb_V_%02d_%s" % [road_index, str(side)],
				Vector3(coordinate + side * 6.55, 0.205, 0.0),
				Vector3(0.18, 0.08, ROAD_SPAN),
				curb_material
			)

	_build_crosswalks(white_material)
	_build_road_arrows(white_material)


func _build_crosswalks(material: Material) -> void:
	# Zebra crossings are placed on both approaches of the main horizontal and
	# vertical streets at selected intersections.
	var main_crossings: Array[float] = [-144.0, 0.0, 144.0]
	for x_value in main_crossings:
		for z_value in main_crossings:
			for stripe in range(5):
				var stripe_offset := -2.4 + float(stripe) * 1.2
				for side in [-1.0, 1.0]:
					_add_visual_box(
						"Crosswalk_H_%s_%s_%02d_%s" % [str(x_value), str(z_value), stripe, str(side)],
						Vector3(x_value + side * 8.0 + stripe_offset, 0.145, z_value),
						Vector3(0.68, 0.025, 11.5),
						material
					)
					_add_visual_box(
						"Crosswalk_V_%s_%s_%02d_%s" % [str(x_value), str(z_value), stripe, str(side)],
						Vector3(x_value, 0.145, z_value + side * 8.0 + stripe_offset),
						Vector3(11.5, 0.025, 0.68),
						material
					)


func _build_road_arrows(material: Material) -> void:
	# Directional lane markers placed only on the central boulevard.
	for marker_index in range(7):
		var z_position := -180.0 + float(marker_index) * 60.0
		_add_visual_box(
			"Boulevard_LaneMarker_%02d" % marker_index,
			Vector3(-4.0, 0.145, z_position),
			Vector3(2.8, 0.02, 0.13),
			material
		)
		_add_visual_box(
			"Boulevard_LaneMarker_R_%02d" % marker_index,
			Vector3(4.0, 0.145, z_position),
			Vector3(2.8, 0.02, 0.13),
			material
		)


func _build_city_blocks() -> void:
	for z_index in range(GRID_COORDS.size() - 1):
		for x_index in range(GRID_COORDS.size() - 1):
			var center_x := (GRID_COORDS[x_index] + GRID_COORDS[x_index + 1]) * 0.5
			var center_z := (GRID_COORDS[z_index] + GRID_COORDS[z_index + 1]) * 0.5
			if _is_park_block(center_x, center_z):
				_build_park(Vector3(center_x, 0.0, center_z))
			elif _is_industrial_yard_block(center_x, center_z):
				_build_industrial_yard(Vector3(center_x, 0.0, center_z))
			elif _is_vehicle_parking_block(center_x, center_z):
				_build_public_parking(Vector3(center_x, 0.0, center_z))
			else:
				_build_block_buildings(center_x, center_z)


func _is_park_block(center_x: float, center_z: float) -> bool:
	return (is_equal_approx(center_x, -108.0) and is_equal_approx(center_z, 108.0)) \
		or (is_equal_approx(center_x, 36.0) and is_equal_approx(center_z, 36.0)) \
		or (is_equal_approx(center_x, -180.0) and is_equal_approx(center_z, -36.0))


func _is_industrial_yard_block(center_x: float, center_z: float) -> bool:
	return is_equal_approx(center_x, 180.0) and is_equal_approx(center_z, 180.0)


func _load_parked_vehicle_config() -> void:
	if not FileAccess.file_exists(PARKED_VEHICLES_CONFIG_PATH):
		push_warning("CityWorld: parked vehicle configuration is missing.")
		return
	var file := FileAccess.open(PARKED_VEHICLES_CONFIG_PATH, FileAccess.READ)
	if file == null:
		push_warning("CityWorld: could not read parked vehicle configuration.")
		return
	var parsed: Variant = JSON.parse_string(file.get_as_text())
	if parsed is Dictionary:
		var lots: Variant = parsed.get("parking_lots", [])
		if lots is Array:
			_parking_lots = lots


func _is_vehicle_parking_block(center_x: float, center_z: float) -> bool:
	for lot_variant in _parking_lots:
		if not lot_variant is Dictionary:
			continue
		var lot: Dictionary = lot_variant
		var center_data: Variant = lot.get("center_xz", [])
		if center_data is Array and center_data.size() >= 2:
			if is_equal_approx(center_x, float(center_data[0])) and is_equal_approx(center_z, float(center_data[1])):
				return true
	return false


func _build_public_parking(center: Vector3) -> void:
	var lot := _find_parking_lot(center)
	var size_xz: Array = lot.get("size_xz", [51.0, 49.0])
	var lot_size := Vector3(float(size_xz[0]), 0.12, float(size_xz[1]))
	_add_static_box(
		"PublicParking_%d_%d" % [int(center.x), int(center.z)],
		center + Vector3(0.0, 0.035, 0.0),
		lot_size,
		_material("road"),
		true
	)
	var parking_line_material := _material("white_line")
	for offset_x in [-8.5, 8.5]:
		_add_visual_box(
			"ParkingBayLine_%d_%d_%s" % [int(center.x), int(center.z), str(offset_x)],
			center + Vector3(float(offset_x), 0.145, 0.0),
			Vector3(0.11, 0.025, 18.0),
			parking_line_material
		)
	for offset_z in [-9.0, 9.0]:
		_add_visual_box(
			"ParkingEndLine_%d_%d_%s" % [int(center.x), int(center.z), str(offset_z)],
			center + Vector3(0.0, 0.145, float(offset_z)),
			Vector3(18.0, 0.025, 0.11),
			parking_line_material
		)
	var sign := Label3D.new()
	sign.name = "PublicParkingSign"
	sign.text = "GARAGE  |  نمایشگاه و پارکینگ خودرو"
	sign.font_size = 42
	sign.pixel_size = 0.012
	sign.modulate = Color("#f4f7fb")
	sign.position = center + Vector3(0.0, 2.2, -21.0)
	add_child(sign)


func _find_parking_lot(center: Vector3) -> Dictionary:
	for lot_variant in _parking_lots:
		if not lot_variant is Dictionary:
			continue
		var lot: Dictionary = lot_variant
		var center_data: Variant = lot.get("center_xz", [])
		if center_data is Array and center_data.size() >= 2:
			if is_equal_approx(center.x, float(center_data[0])) and is_equal_approx(center.z, float(center_data[1])):
				return lot
	return {}


func _spawn_parked_vehicles(interaction_manager: VehicleInteractionManager) -> void:
	for lot_variant in _parking_lots:
		if not lot_variant is Dictionary:
			continue
		var lot: Dictionary = lot_variant
		var center_data: Array = lot.get("center_xz", [0.0, 0.0])
		if center_data.size() < 2:
			continue
		var lot_center := Vector3(float(center_data[0]), 0.0, float(center_data[1]))
		var vehicle_entries: Variant = lot.get("vehicles", [])
		if not vehicle_entries is Array:
			continue
		for vehicle_index in range(vehicle_entries.size()):
			var vehicle_data_variant: Variant = vehicle_entries[vehicle_index]
			if not vehicle_data_variant is Dictionary:
				continue
			var vehicle_data: Dictionary = vehicle_data_variant
			var vehicle := PLAYER_CAR_SCENE.instantiate() as CarController
			if vehicle == null:
				continue
			var offset_data: Array = vehicle_data.get("offset_xz", [0.0, 0.0])
			if offset_data.size() < 2:
				continue
			var vehicle_id := str(vehicle_data.get("id", "parked_vehicle_%02d" % vehicle_index))
			vehicle.name = "Parked_%s" % vehicle_id
			vehicle.position = lot_center + Vector3(float(offset_data[0]), 0.96, float(offset_data[1]))
			vehicle.rotation_degrees.y = float(vehicle_data.get("yaw_degrees", 0.0))
			vehicle.configure_vehicle_variant(
				vehicle_id,
				str(vehicle_data.get("display_name_fa", "خودرو")),
				Color.from_string(str(vehicle_data.get("paint", "#4c718d")), Color("#4c718d")),
				float(vehicle_data.get("mass", 1180.0)),
				float(vehicle_data.get("engine_force", 55.0)),
				float(vehicle_data.get("maximum_speed_kmh", 155.0)),
				float(vehicle_data.get("steering_angle", 0.44)),
				str(vehicle_data.get("body_style", "sedan"))
			)
			vehicle.set_meta("purchase_price", maxi(0, int(vehicle_data.get("purchase_price", 0))))
			add_child(vehicle)
			VehicleEconomy.apply_upgrades(vehicle)
			interaction_manager.register_vehicle(vehicle, true)


func _build_block_buildings(center_x: float, center_z: float) -> void:
	var district := _get_district_name(center_x, center_z)
	var slots: Array[Vector3] = [
		Vector3(-17.5, 0.0, -16.0),
		Vector3(17.5, 0.0, -16.0),
		Vector3(0.0, 0.0, 18.0)
	]
	for slot_index in range(slots.size()):
		var building_key := _choose_building_asset(district, center_x, center_z, slot_index)
		var scale_factor := _choose_building_scale(district, building_key)
		var location := Vector3(center_x, 0.0, center_z) + slots[slot_index]
		var yaw := float(_rng.randi_range(0, 3)) * PI * 0.5
		_spawn_asset_model(building_key, location, scale_factor, yaw, true, "Building")
		_spawned_building_count += 1


func _get_district_name(center_x: float, center_z: float) -> String:
	if center_x > 72.0:
		return "industrial"
	if center_x < -72.0:
		return "residential"
	if absf(center_x) < 85.0 and absf(center_z) < 85.0:
		return "downtown"
	return "commercial"


func _choose_building_asset(district: String, center_x: float, center_z: float, slot_index: int) -> String:
	if district == "industrial":
		var industrial_index := _rng.randi_range(0, 19)
		return "kenney_industrial/building-%s.glb" % MODEL_LETTERS[industrial_index]
	if district == "downtown" and slot_index == 0 and _rng.randf() < 0.66:
		var tower_index := _rng.randi_range(0, 4)
		return "kenney_commercial/building-skyscraper-%s.glb" % MODEL_LETTERS[tower_index]
	if district == "residential" and _rng.randf() < 0.22:
		var low_index := _rng.randi_range(0, 13)
		return "kenney_commercial/low-detail-building-%s.glb" % MODEL_LETTERS[low_index]
	var building_index := _rng.randi_range(0, 13)
	return "kenney_commercial/building-%s.glb" % MODEL_LETTERS[building_index]


func _choose_building_scale(district: String, asset_key: String) -> float:
	if asset_key.contains("skyscraper"):
		return 8.4
	if district == "industrial":
		return 8.4
	if asset_key.contains("low-detail"):
		return 15.5
	return 8.8


func _build_park(center: Vector3) -> void:
	_add_static_box(
		"ParkGround_%d_%d" % [int(center.x), int(center.z)],
		center + Vector3(0.0, 0.03, 0.0),
		Vector3(47.0, 0.12, 47.0),
		_material("park"),
		false
	)

	# Cross paths divide the park into four readable green areas.
	_add_static_box("ParkWalk_H_%d_%d" % [int(center.x), int(center.z)], center + Vector3(0.0, 0.12, 0.0), Vector3(42.0, 0.08, 2.8), _material("sidewalk"), false)
	_add_static_box("ParkWalk_V_%d_%d" % [int(center.x), int(center.z)], center + Vector3(0.0, 0.12, 0.0), Vector3(2.8, 0.08, 42.0), _material("sidewalk"), false)

	var tree_offsets: Array[Vector2] = [
		Vector2(-15.0, -14.0), Vector2(0.0, -15.0), Vector2(15.0, -14.0),
		Vector2(-15.0, 14.0), Vector2(0.0, 15.0), Vector2(15.0, 14.0)
	]
	for tree_index in range(tree_offsets.size()):
		var offset := tree_offsets[tree_index]
		_spawn_tree(center + Vector3(offset.x, 0.0, offset.y), 1.0 + float(tree_index % 3) * 0.12)

	for bench_index in range(2):
		var bench := _add_static_box(
			"ParkBench_%d_%d_%d" % [int(center.x), int(center.z), bench_index],
			center + Vector3(-7.0 + float(bench_index) * 14.0, 0.55, 0.0),
			Vector3(3.0, 0.16, 0.55),
			_material("bench"),
			true
		)
		bench.rotation.y = PI * 0.5


func _build_industrial_yard(center: Vector3) -> void:
	# The yard uses only scenery and logistics props; later systems can add
	# enterable buildings, deliveries and civilian industrial traffic here.
	_add_static_box("IndustrialYard_Paving", center + Vector3(0.0, 0.025, 0.0), Vector3(51.0, 0.1, 51.0), _material("sidewalk"), false)
	var container_keys: Array[String] = [
		"kenney_industrial/shipping-container-a.glb",
		"kenney_industrial/shipping-container-b.glb",
		"kenney_industrial/shipping-container-c.glb"
	]
	for row in range(2):
		for column in range(2):
			var container_key: String = container_keys[(row + column) % container_keys.size()]
			var position := center + Vector3(-13.0 + float(column) * 12.0, 0.0, -14.0 + float(row) * 12.0)
			_spawn_asset_model(container_key, position, 6.0, 0.0 if row == 0 else PI * 0.5, true, "Container")
			_spawned_prop_count += 1

	_spawn_asset_model("kenney_industrial/detail-tank-large.glb", center + Vector3(15.0, 0.0, -11.0), 7.0, 0.0, true, "StorageTank")
	_spawn_asset_model("kenney_industrial/water-tower.glb", center + Vector3(16.0, 0.0, 14.0), 8.0, 0.0, true, "WaterTower")
	_spawn_asset_model("kenney_industrial/chimney-large.glb", center + Vector3(-17.0, 0.0, 15.0), 9.0, 0.0, true, "Chimney")
	_spawn_asset_model("kenney_industrial/chimney-medium.glb", center + Vector3(-9.0, 0.0, 15.0), 9.0, 0.0, true, "Chimney")
	_spawned_prop_count += 4

	# Simple perimeter fence with a broad entrance facing the city street.
	var fence_material := _material("fence")
	for side in [-1.0, 1.0]:
		_add_static_box("YardFence_X_%s" % str(side), center + Vector3(side * 25.0, 1.05, 0.0), Vector3(0.22, 2.1, 51.0), fence_material, true)
	_add_static_box("YardFence_Back", center + Vector3(0.0, 1.05, 25.0), Vector3(51.0, 2.1, 0.22), fence_material, true)
	# Two front fence segments leave a clear vehicle entrance in the middle.
	_add_static_box("YardFence_FrontLeft", center + Vector3(-18.0, 1.05, -25.0), Vector3(15.0, 2.1, 0.22), fence_material, true)
	_add_static_box("YardFence_FrontRight", center + Vector3(18.0, 1.05, -25.0), Vector3(15.0, 2.1, 0.22), fence_material, true)


func _build_street_furniture() -> void:
	# Streetlights on the principal routes and signal heads at selected crossings.
	for coordinate in [-216.0, -72.0, 72.0, 216.0]:
		for longitudinal in [-180.0, -60.0, 60.0, 180.0]:
			_spawn_street_lamp(Vector3(coordinate + 10.2, 0.0, longitudinal))
			_spawn_street_lamp(Vector3(longitudinal, 0.0, coordinate + 10.2))

	for x_value in [-144.0, 0.0, 144.0]:
		for z_value in [-144.0, 0.0, 144.0]:
			_spawn_traffic_signal(Vector3(x_value + 7.0, 0.0, z_value + 7.0))


func _spawn_street_lamp(location: Vector3) -> void:
	var pole := MeshInstance3D.new()
	pole.name = "StreetLampPole"
	pole.position = location + Vector3(0.0, 3.0, 0.0)
	var pole_mesh := CylinderMesh.new()
	pole_mesh.top_radius = 0.075
	pole_mesh.bottom_radius = 0.11
	pole_mesh.height = 6.0
	pole.mesh = pole_mesh
	pole.material_override = _material("lamp_pole")
	add_child(pole)

	_add_visual_box("StreetLampArm", location + Vector3(0.65, 5.7, 0.0), Vector3(1.35, 0.10, 0.10), _material("lamp_pole"))
	_add_visual_box("StreetLampHead", location + Vector3(1.25, 5.63, 0.0), Vector3(0.58, 0.14, 0.38), _material("lamp_glow"))


func _spawn_traffic_signal(location: Vector3) -> void:
	var pole_body := _add_static_box(
		"TrafficSignalPole",
		location + Vector3(0.0, 2.15, 0.0),
		Vector3(0.16, 4.3, 0.16),
		_material("lamp_pole"),
		true
	)
	pole_body.collision_layer = 1
	# Two independently timed heads represent the horizontal and vertical streams.
	for axis_index in range(2):
		var axis_name := "horizontal" if axis_index == 0 else "vertical"
		var head_position := location + (Vector3(-0.5, 4.25, 0.0) if axis_index == 0 else Vector3(0.5, 4.25, 0.0))
		var head := _add_static_box(
			"TrafficSignalHead_%s" % axis_name,
			head_position,
			Vector3(0.5, 1.42, 0.38),
			_material("traffic_dark"),
			true
		)
		head.collision_layer = 1
		if axis_index == 1:
			head.rotation.y = PI * 0.5
		for light_index in range(3):
			var light_material_name := "traffic_red" if light_index == 0 else ("traffic_yellow" if light_index == 1 else "traffic_green")
			var light_mesh := MeshInstance3D.new()
			light_mesh.name = "SignalLight_%s_%d" % [axis_name, light_index]
			light_mesh.position = head_position + Vector3(0.0, 0.49 - float(light_index) * 0.48, 0.205)
			if axis_index == 1:
				light_mesh.position = head_position + Vector3(0.205, 0.49 - float(light_index) * 0.48, 0.0)
			var sphere := SphereMesh.new()
			sphere.radius = 0.13
			sphere.height = 0.26
			light_mesh.mesh = sphere
			light_mesh.material_override = _material(light_material_name)
			light_mesh.add_to_group("traffic_signal_lights")
			light_mesh.set_meta("intersection_x", int(round(location.x - 7.0)))
			light_mesh.set_meta("intersection_z", int(round(location.z - 7.0)))
			light_mesh.set_meta("light_index", light_index)
			light_mesh.set_meta("direction_axis", axis_name)
			add_child(light_mesh)


func _build_district_markers() -> void:
	_create_district_area("DowntownDistrict", Vector3(0.0, 3.0, 0.0), Vector3(210.0, 6.0, 210.0), "downtown")
	_create_district_area("ResidentialDistrict", Vector3(-174.0, 3.0, 0.0), Vector3(132.0, 6.0, 520.0), "residential")
	_create_district_area("IndustrialDistrict", Vector3(174.0, 3.0, 0.0), Vector3(132.0, 6.0, 520.0), "industrial")


func _create_district_area(area_name: String, location: Vector3, area_size: Vector3, district_id: String) -> void:
	var area := Area3D.new()
	area.name = area_name
	area.position = location
	area.collision_layer = 0
	area.collision_mask = 1
	area.add_to_group("city_districts")
	area.set_meta("district_id", district_id)
	var collision := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = area_size
	collision.shape = shape
	area.add_child(collision)
	add_child(area)


func _spawn_tree(location: Vector3, scale_factor: float) -> void:
	var tree := Node3D.new()
	tree.name = "CityTree"
	tree.position = location
	add_child(tree)

	var trunk := MeshInstance3D.new()
	trunk.position.y = 1.35 * scale_factor
	var trunk_mesh := CylinderMesh.new()
	trunk_mesh.top_radius = 0.18 * scale_factor
	trunk_mesh.bottom_radius = 0.25 * scale_factor
	trunk_mesh.height = 2.7 * scale_factor
	trunk.mesh = trunk_mesh
	trunk.material_override = _material("tree_trunk")
	tree.add_child(trunk)

	var crown := MeshInstance3D.new()
	crown.position.y = 3.35 * scale_factor
	var crown_mesh := SphereMesh.new()
	crown_mesh.radius = 1.45 * scale_factor
	crown_mesh.height = 2.6 * scale_factor
	crown.mesh = crown_mesh
	crown.material_override = _material("tree_canopy")
	tree.add_child(crown)

	var collision_body := StaticBody3D.new()
	collision_body.position.y = 1.4 * scale_factor
	var collision := CollisionShape3D.new()
	var shape := CylinderShape3D.new()
	shape.radius = 0.28 * scale_factor
	shape.height = 2.8 * scale_factor
	collision.shape = shape
	collision_body.add_child(collision)
	tree.add_child(collision_body)


func _spawn_asset_model(
	asset_key: String,
	location: Vector3,
	scale_factor: float,
	yaw: float,
	with_collision: bool,
	kind_prefix: String
) -> Node3D:
	var model_scene := _load_model_scene(asset_key)
	if model_scene == null:
		return _spawn_placeholder_building(asset_key, location, scale_factor, yaw, with_collision)

	var parent_node: Node3D
	if with_collision:
		var static_body := StaticBody3D.new()
		static_body.name = "%s_%03d" % [kind_prefix, _model_instance_counter]
		_model_instance_counter += 1
		static_body.position = location
		static_body.rotation.y = yaw
		static_body.collision_layer = 1
		static_body.collision_mask = 1
		add_child(static_body)
		parent_node = static_body
	else:
		var wrapper := Node3D.new()
		wrapper.name = "%s_%03d" % [kind_prefix, _model_instance_counter]
		_model_instance_counter += 1
		wrapper.position = location
		wrapper.rotation.y = yaw
		add_child(wrapper)
		parent_node = wrapper

	var model_instance := model_scene.instantiate() as Node3D
	if model_instance == null:
		parent_node.queue_free()
		return _spawn_placeholder_building(asset_key, location, scale_factor, yaw, with_collision)
	model_instance.scale = Vector3.ONE * scale_factor
	var asset_data: Dictionary = _asset_catalog.get(asset_key, {})
	var min_values: Array = asset_data.get("min", [ -0.5, 0.0, -0.5 ])
	var max_values: Array = asset_data.get("max", [ 0.5, 1.0, 0.5 ])
	var min_bound := Vector3(float(min_values[0]), float(min_values[1]), float(min_values[2]))
	var max_bound := Vector3(float(max_values[0]), float(max_values[1]), float(max_values[2]))
	var size := max_bound - min_bound
	var center := (max_bound + min_bound) * 0.5
	model_instance.position = Vector3(-center.x * scale_factor, -min_bound.y * scale_factor, -center.z * scale_factor)
	parent_node.add_child(model_instance)

	if with_collision and parent_node is StaticBody3D:
		var collision_shape := CollisionShape3D.new()
		var box_shape := BoxShape3D.new()
		box_shape.size = Vector3(
			maxf(size.x * scale_factor * 0.88, 1.2),
			maxf(size.y * scale_factor, 2.0),
			maxf(size.z * scale_factor * 0.88, 1.2)
		)
		collision_shape.shape = box_shape
		collision_shape.position.y = box_shape.size.y * 0.5
		parent_node.add_child(collision_shape)
	return parent_node


func _load_model_scene(asset_key: String) -> PackedScene:
	if _packed_scene_cache.has(asset_key):
		return _packed_scene_cache[asset_key] as PackedScene
	var asset_data: Dictionary = _asset_catalog.get(asset_key, {})
	var asset_path := str(asset_data.get("path", ""))
	if asset_path.is_empty():
		return null
	var loaded_resource: Resource = ResourceLoader.load(asset_path)
	if loaded_resource is PackedScene:
		var packed_scene := loaded_resource as PackedScene
		_packed_scene_cache[asset_key] = packed_scene
		return packed_scene
	push_warning("CityWorld: could not load model %s; a placeholder will be used." % asset_path)
	return null


func _spawn_placeholder_building(asset_key: String, location: Vector3, scale_factor: float, yaw: float, with_collision: bool) -> Node3D:
	var fallback_size := Vector3(9.0, 12.0, 9.0) * clampf(scale_factor / 8.8, 0.65, 1.5)
	var fallback_material := _make_material(Color("#68747c"), 0.92)
	var fallback: Node3D
	if with_collision:
		fallback = _add_static_box(
			"Fallback_%s" % asset_key.get_file().get_basename(),
			location + Vector3.UP * (fallback_size.y * 0.5),
			fallback_size,
			fallback_material,
			true
		)
	else:
		var mesh_instance := MeshInstance3D.new()
		var box_mesh := BoxMesh.new()
		box_mesh.size = fallback_size
		box_mesh.material = fallback_material
		mesh_instance.mesh = box_mesh
		mesh_instance.position = location + Vector3.UP * (fallback_size.y * 0.5)
		add_child(mesh_instance)
		fallback = mesh_instance
	fallback.rotation.y = yaw
	return fallback


func _spawn_player_and_ui() -> void:
	var player := PLAYER_CAR_SCENE.instantiate() as CarController
	player.name = "PlayerCar"
	player.position = Vector3(0.0, 0.96, -216.0)
	add_child(player)
	VehicleEconomy.apply_upgrades(player)

	var car_camera_rig := Node3D.new()
	car_camera_rig.name = "CarCameraRig"
	car_camera_rig.set_script(CAMERA_FOLLOW_SCRIPT)
	car_camera_rig.set("target_path", NodePath("../PlayerCar"))
	add_child(car_camera_rig)

	var character := PLAYER_CHARACTER_SCENE.instantiate() as PlayerCharacter
	character.name = "PlayerCharacter"
	character.position = Vector3(0.0, 0.22, -216.0)
	character.visible = false
	add_child(character)

	var foot_camera_rig := Node3D.new()
	foot_camera_rig.name = "FootCameraRig"
	foot_camera_rig.set_script(FOOT_CAMERA_SCRIPT)
	foot_camera_rig.set("target_path", NodePath("../PlayerCharacter"))
	add_child(foot_camera_rig)

	var interaction_manager := VEHICLE_INTERACTION_SCRIPT.new() as VehicleInteractionManager
	interaction_manager.name = "VehicleInteractionManager"
	add_child(interaction_manager)
	interaction_manager.call("configure", player, character, car_camera_rig, foot_camera_rig)
	_spawn_parked_vehicles(interaction_manager)

	var traffic_manager := TRAFFIC_MANAGER_SCRIPT.new() as Node3D
	traffic_manager.name = "TrafficManager"
	add_child(traffic_manager)
	traffic_manager.call("configure", _traffic_signal_manager, player)

	var police_manager := POLICE_MANAGER_SCRIPT.new() as Node
	police_manager.name = "PoliceManager"
	add_child(police_manager)
	police_manager.call("configure", player, character, interaction_manager, _traffic_signal_manager)

	var hud := CanvasLayer.new()
	hud.name = "DrivingHUD"
	hud.set_script(DRIVING_HUD_SCRIPT)
	hud.set("player_path", NodePath("../PlayerCar"))
	hud.set("interaction_manager", interaction_manager)
	hud.set("police_manager", police_manager)
	hud.set("traffic_manager", traffic_manager)
	add_child(hud)
	interaction_manager.active_vehicle_changed.connect(Callable(police_manager, "set_active_vehicle"))
	interaction_manager.active_vehicle_changed.connect(Callable(hud, "set_active_vehicle"))
	hud.call("set_active_vehicle", player)


func _add_static_box(
	node_name: String,
	world_position: Vector3,
	box_size: Vector3,
	material: Material,
	with_collision: bool
) -> StaticBody3D:
	var body := StaticBody3D.new()
	body.name = node_name
	body.position = world_position
	body.collision_layer = 1
	body.collision_mask = 1
	add_child(body)

	var mesh_instance := MeshInstance3D.new()
	mesh_instance.name = "Mesh"
	var box_mesh := BoxMesh.new()
	box_mesh.size = box_size
	box_mesh.material = material
	mesh_instance.mesh = box_mesh
	body.add_child(mesh_instance)

	if with_collision:
		var collision := CollisionShape3D.new()
		collision.name = "CollisionShape3D"
		var box_shape := BoxShape3D.new()
		box_shape.size = box_size
		collision.shape = box_shape
		body.add_child(collision)
	return body


func _add_visual_box(node_name: String, world_position: Vector3, box_size: Vector3, material: Material) -> void:
	var mesh_instance := MeshInstance3D.new()
	mesh_instance.name = node_name
	mesh_instance.position = world_position
	var box_mesh := BoxMesh.new()
	box_mesh.size = box_size
	box_mesh.material = material
	mesh_instance.mesh = box_mesh
	add_child(mesh_instance)


func _material(material_name: String) -> StandardMaterial3D:
	return _materials[material_name] as StandardMaterial3D


func _make_material(
	albedo: Color,
	roughness_value: float,
	metallic_value: float = 0.0,
	emission_color: Color = Color.BLACK,
	emission_energy: float = 0.0
) -> StandardMaterial3D:
	var material := StandardMaterial3D.new()
	material.albedo_color = albedo
	material.roughness = roughness_value
	material.metallic = metallic_value
	if emission_energy > 0.0:
		material.emission_enabled = true
		material.emission = emission_color
		material.emission_energy_multiplier = emission_energy
	return material
