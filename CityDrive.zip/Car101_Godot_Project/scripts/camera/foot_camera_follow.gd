extends Node3D
class_name FootCameraFollow

@export var target_path: NodePath = NodePath("../PlayerCharacter")
@export_range(2.5, 8.0, 0.1) var follow_distance: float = 4.8
@export_range(3.0, 18.0, 0.1) var follow_smoothing: float = 10.0
@export_range(0.1, 1.0, 0.05) var mouse_sensitivity: float = 0.35

var target: Node3D
var spring_arm: SpringArm3D
var _camera: Camera3D
var _camera_active: bool = false
var _yaw_offset: float = 0.0
var _pitch: float = deg_to_rad(-12.0)
var _touch_look_active: bool = false


func _ready() -> void:
	target = get_node_or_null(target_path) as Node3D
	if target == null:
		push_error("FootCameraFollow: target was not found at %s." % target_path)
		return
	global_position = target.global_position
	global_rotation = Vector3(0.0, target.global_rotation.y, 0.0)
	spring_arm = SpringArm3D.new()
	spring_arm.name = "FootCameraSpringArm"
	spring_arm.position = Vector3(0.0, 1.62, 0.0)
	spring_arm.spring_length = follow_distance
	spring_arm.margin = 0.18
	spring_arm.collision_mask = 1
	spring_arm.rotation.x = _pitch
	add_child(spring_arm)
	_camera = Camera3D.new()
	_camera.name = "FootCamera"
	_camera.current = false
	_camera.fov = 68.0
	spring_arm.add_child(_camera)
	set_process(false)


func set_camera_active(active: bool) -> void:
	_camera_active = active
	if _camera != null:
		_camera.current = active
	set_process(active)


func _process(delta: float) -> void:
	if not _camera_active or target == null or not is_instance_valid(target):
		return
	var smooth_weight := clampf(delta * follow_smoothing, 0.0, 1.0)
	global_position = global_position.lerp(target.global_position, smooth_weight)
	var target_yaw := target.global_rotation.y + _yaw_offset
	global_rotation.y = lerp_angle(global_rotation.y, target_yaw, smooth_weight)


func _unhandled_input(event: InputEvent) -> void:
	if not _camera_active or spring_arm == null:
		return
	if event is InputEventMouseMotion and Input.is_mouse_button_pressed(MOUSE_BUTTON_RIGHT):
		var motion := event as InputEventMouseMotion
		_rotate_camera(motion.relative)
		get_viewport().set_input_as_handled()
	elif event is InputEventScreenDrag:
		var drag := event as InputEventScreenDrag
		_rotate_camera(drag.relative)
		get_viewport().set_input_as_handled()
	elif event is InputEventMouseButton:
		var mouse_event := event as InputEventMouseButton
		if mouse_event.pressed and mouse_event.button_index == MOUSE_BUTTON_WHEEL_UP:
			spring_arm.spring_length = maxf(2.8, spring_arm.spring_length - 0.35)
			get_viewport().set_input_as_handled()
		elif mouse_event.pressed and mouse_event.button_index == MOUSE_BUTTON_WHEEL_DOWN:
			spring_arm.spring_length = minf(7.0, spring_arm.spring_length + 0.35)
			get_viewport().set_input_as_handled()


func _rotate_camera(relative_motion: Vector2) -> void:
	_yaw_offset -= relative_motion.x * mouse_sensitivity * 0.01
	_pitch = clampf(_pitch - relative_motion.y * mouse_sensitivity * 0.01, deg_to_rad(-28.0), deg_to_rad(5.0))
	spring_arm.rotation.x = _pitch
