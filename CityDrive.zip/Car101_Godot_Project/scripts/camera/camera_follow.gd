extends Node3D
class_name CameraFollow

@export var target_path: NodePath = NodePath("../PlayerCar")
@export_range(2.0, 14.0, 0.1) var follow_distance: float = 7.2
@export_range(1.0, 20.0, 0.1) var follow_smoothing: float = 8.0
@export_range(-35.0, 5.0, 0.5) var camera_pitch_degrees: float = -11.0
@export_range(0.1, 1.0, 0.05) var mouse_sensitivity: float = 0.35

var target: Node3D
var spring_arm: SpringArm3D
var _camera: Camera3D
var _camera_active: bool = true
var _yaw_offset: float = 0.0
var _pitch: float = -0.19


func _ready() -> void:
	target = get_node_or_null(target_path) as Node3D
	if target == null:
		push_error("CameraFollow: target was not found at %s." % target_path)
		return

	global_position = target.global_position
	global_rotation = Vector3(0.0, target.global_rotation.y, 0.0)
	_pitch = deg_to_rad(camera_pitch_degrees)

	spring_arm = SpringArm3D.new()
	spring_arm.name = "CameraSpringArm"
	spring_arm.position = Vector3(0.0, 2.35, 0.0)
	spring_arm.spring_length = follow_distance
	spring_arm.margin = 0.2
	spring_arm.collision_mask = 1
	spring_arm.rotation.x = _pitch
	add_child(spring_arm)
	if target is CollisionObject3D:
		spring_arm.add_excluded_object((target as CollisionObject3D).get_rid())

	_camera = Camera3D.new()
	_camera.name = "ChaseCamera"
	_camera.current = true
	_camera.fov = 72.0
	spring_arm.add_child(_camera)


func set_target(new_target: Node3D) -> void:
	if new_target == null or not is_instance_valid(new_target):
		return
	if target == new_target:
		return
	target = new_target
	if spring_arm != null and target is CollisionObject3D:
		spring_arm.add_excluded_object((target as CollisionObject3D).get_rid())
	global_position = target.global_position
	global_rotation.y = target.global_rotation.y + _yaw_offset


func set_camera_active(active: bool) -> void:
	_camera_active = active
	if _camera != null:
		_camera.current = active
	set_process(active)


func _process(delta: float) -> void:
	if not _camera_active or target == null or not is_instance_valid(target):
		return
	var smooth_weight := clampf(delta * follow_smoothing, 0.0, 1.0)
	global_position = global_position.lerp(target.global_position, smooth_weight)
	var target_yaw := target.global_rotation.y + _yaw_offset
	global_rotation.y = lerp_angle(global_rotation.y, target_yaw, smooth_weight)


func _unhandled_input(event: InputEvent) -> void:
	if not _camera_active or spring_arm == null:
		return
	if event is InputEventMouseMotion and Input.is_mouse_button_pressed(MOUSE_BUTTON_RIGHT):
		var motion := event as InputEventMouseMotion
		_yaw_offset -= motion.relative.x * mouse_sensitivity * 0.01
		_pitch = clampf(_pitch - motion.relative.y * mouse_sensitivity * 0.01, deg_to_rad(-32.0), deg_to_rad(2.0))
		spring_arm.rotation.x = _pitch
		get_viewport().set_input_as_handled()
	elif event is InputEventMouseButton:
		var mouse_event := event as InputEventMouseButton
		if not mouse_event.pressed:
			return
		if mouse_event.button_index == MOUSE_BUTTON_WHEEL_UP:
			spring_arm.spring_length = maxf(3.5, spring_arm.spring_length - 0.5)
			get_viewport().set_input_as_handled()
		elif mouse_event.button_index == MOUSE_BUTTON_WHEEL_DOWN:
			spring_arm.spring_length = minf(11.0, spring_arm.spring_length + 0.5)
			get_viewport().set_input_as_handled()
	elif event is InputEventKey:
		var key_event := event as InputEventKey
		if key_event.pressed and not key_event.echo and key_event.physical_keycode == KEY_C:
			_yaw_offset = 0.0
			_pitch = deg_to_rad(camera_pitch_degrees)
			spring_arm.rotation.x = _pitch
			get_viewport().set_input_as_handled()
