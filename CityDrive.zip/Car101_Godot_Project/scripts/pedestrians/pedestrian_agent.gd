extends Node3D
class_name PedestrianAgent

## Lightweight sidewalk pedestrian with procedural walk animation.

var _route_points: Array[Vector3] = []
var _target_index: int = 0
var _walk_speed: float = 1.25
var _clock: float = 0.0
var _left_leg: MeshInstance3D
var _right_leg: MeshInstance3D
var _left_arm: MeshInstance3D
var _right_arm: MeshInstance3D
var _body: MeshInstance3D
var _shirt_color: Color = Color("#47728a")


func configure(route_points: Array[Vector3], target_index: int, spawn_position: Vector3, shirt_color: Color) -> void:
	_route_points = route_points.duplicate()
	_target_index = target_index
	position = spawn_position
	_shirt_color = shirt_color


func _ready() -> void:
	name = "CityPedestrian"
	add_to_group("city_pedestrians")
	_build_visuals()


func _process(delta: float) -> void:
	if _route_points.size() < 2:
		return
	var target := _route_points[_target_index]
	var direction := target - global_position
	direction.y = 0.0
	if direction.length() < 1.2:
		_target_index = (_target_index + 1) % _route_points.size()
		target = _route_points[_target_index]
		direction = target - global_position
		direction.y = 0.0
	if direction.length_squared() < 0.01:
		return
	var normalized := direction.normalized()
	global_position += normalized * _walk_speed * delta
	rotation.y = lerp_angle(rotation.y, atan2(-normalized.x, -normalized.z), clampf(delta * 5.0, 0.0, 1.0))
	_clock += delta * 7.0
	var swing := sin(_clock) * 0.34
	_left_leg.rotation.x = swing
	_right_leg.rotation.x = -swing
	_left_arm.rotation.x = -swing * 0.72
	_right_arm.rotation.x = swing * 0.72
	_body.position.y = 1.08 + absf(sin(_clock * 2.0)) * 0.025


func _build_visuals() -> void:
	var skin := _make_material(Color("#c58d70"))
	var shirt := _make_material(_shirt_color)
	var trousers := _make_material(Color("#303e50"))
	var shoes := _make_material(Color("#22272e"))
	var hair := _make_material(Color("#2a2522"))
	_body = _make_capsule("Torso", shirt, 0.25, 0.92, Vector3(0.0, 1.08, 0.0))
	_make_capsule("Head", skin, 0.17, 0.34, Vector3(0.0, 1.84, 0.0))
	_make_capsule("Hair", hair, 0.175, 0.12, Vector3(0.0, 2.0, 0.015))
	_left_leg = _make_capsule("LeftLeg", trousers, 0.105, 0.72, Vector3(-0.125, 0.48, 0.0))
	_right_leg = _make_capsule("RightLeg", trousers, 0.105, 0.72, Vector3(0.125, 0.48, 0.0))
	_left_arm = _make_capsule("LeftArm", shirt, 0.085, 0.68, Vector3(-0.32, 1.2, 0.0))
	_right_arm = _make_capsule("RightArm", shirt, 0.085, 0.68, Vector3(0.32, 1.2, 0.0))
	_add_shoe(_left_leg, shoes)
	_add_shoe(_right_leg, shoes)


func _make_capsule(node_name: String, material: Material, radius: float, height: float, local_position: Vector3) -> MeshInstance3D:
	var mesh_instance := MeshInstance3D.new()
	mesh_instance.name = node_name
	var capsule := CapsuleMesh.new()
	capsule.radius = radius
	capsule.height = height
	mesh_instance.mesh = capsule
	mesh_instance.material_override = material
	mesh_instance.position = local_position
	add_child(mesh_instance)
	return mesh_instance


func _add_shoe(parent: Node3D, material: Material) -> void:
	var shoe := MeshInstance3D.new()
	var box := BoxMesh.new()
	box.size = Vector3(0.21, 0.12, 0.30)
	shoe.mesh = box
	shoe.material_override = material
	shoe.position = Vector3(0.0, -0.32, -0.045)
	parent.add_child(shoe)


func _make_material(color: Color) -> StandardMaterial3D:
	var material := StandardMaterial3D.new()
	material.albedo_color = color
	material.roughness = 0.83
	return material
