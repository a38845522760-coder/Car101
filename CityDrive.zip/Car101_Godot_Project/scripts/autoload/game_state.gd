extends Node

## Runtime player profile shared by independent gameplay systems.
signal economy_changed(money: int)
signal score_changed(score: int)
signal progress_changed(progress: Dictionary)

var money: int = 0
var score: int = 0
var progress: Dictionary = {}


func _ready() -> void:
	var saved_profile := SaveManager.load_profile()
	money = maxi(0, int(saved_profile.get("money", 0)))
	score = maxi(0, int(saved_profile.get("score", 0)))
	var saved_progress: Variant = saved_profile.get("progress", {})
	progress = saved_progress.duplicate(true) if saved_progress is Dictionary else {}


func add_money(amount: int) -> void:
	if amount <= 0:
		return
	money += amount
	_persist_profile()
	economy_changed.emit(money)


func spend_money(amount: int) -> bool:
	if amount <= 0 or money < amount:
		return false
	money -= amount
	_persist_profile()
	economy_changed.emit(money)
	return true


func add_score(points: int) -> void:
	if points == 0:
		return
	score = maxi(0, score + points)
	_persist_profile()
	score_changed.emit(score)


func set_progress(key: String, value: Variant) -> void:
	var clean_key := key.strip_edges()
	if clean_key.is_empty():
		return
	progress[clean_key] = value
	_persist_profile()
	progress_changed.emit(progress.duplicate(true))


func get_progress(key: String, fallback: Variant = null) -> Variant:
	return progress.get(key, fallback)


func reset_profile() -> void:
	money = 0
	score = 0
	progress.clear()
	_persist_profile()
	economy_changed.emit(money)
	score_changed.emit(score)
	progress_changed.emit(progress.duplicate(true))


func _persist_profile() -> void:
	if not SaveManager.save_profile({"money": money, "score": score, "progress": progress}):
		push_warning("GameState: player profile could not be saved.")
