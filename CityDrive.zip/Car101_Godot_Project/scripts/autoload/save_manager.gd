extends Node

## Central persistence service. Settings and game progress are stored separately.
## Writes use a temporary file and a backup so an interrupted save is recoverable.

const SETTINGS_PATH: String = "user://settings.cfg"
const PROFILE_PATH: String = "user://profile.cfg"
const SAVE_SCHEMA_VERSION: int = 1

var _settings_cache: Dictionary = {}
var _profile_cache: Dictionary = {}


func _ready() -> void:
	_settings_cache = _read_settings_from_disk()
	_profile_cache = _read_profile_from_disk()


func load_settings() -> Dictionary:
	return _settings_cache.duplicate(true)


func save_settings(settings: Dictionary) -> bool:
	var config := ConfigFile.new()
	config.set_value("meta", "schema_version", SAVE_SCHEMA_VERSION)
	config.set_value("settings", "values", settings.duplicate(true))
	if not _atomic_save(config, SETTINGS_PATH):
		return false
	_settings_cache = settings.duplicate(true)
	return true


func load_profile() -> Dictionary:
	return _profile_cache.duplicate(true)


func save_profile(profile: Dictionary) -> bool:
	var clean_profile: Dictionary = {
		"money": maxi(0, int(profile.get("money", 0))),
		"score": maxi(0, int(profile.get("score", 0))),
		"progress": profile.get("progress", {}).duplicate(true) if profile.get("progress", {}) is Dictionary else {}
	}
	var config := ConfigFile.new()
	config.set_value("meta", "schema_version", SAVE_SCHEMA_VERSION)
	config.set_value("profile", "data", clean_profile)
	if not _atomic_save(config, PROFILE_PATH):
		return false
	_profile_cache = clean_profile.duplicate(true)
	return true


func _read_settings_from_disk() -> Dictionary:
	var config := _load_config_with_backup(SETTINGS_PATH)
	var raw: Variant = config.get_value("settings", "values", {})
	if raw is Dictionary:
		return raw.duplicate(true)
	return {}


func _read_profile_from_disk() -> Dictionary:
	var config := _load_config_with_backup(PROFILE_PATH)
	var raw: Variant = config.get_value("profile", "data", {})
	if raw is Dictionary:
		return {
			"money": maxi(0, int(raw.get("money", 0))),
			"score": maxi(0, int(raw.get("score", 0))),
			"progress": raw.get("progress", {}).duplicate(true) if raw.get("progress", {}) is Dictionary else {}
		}
	return {"money": 0, "score": 0, "progress": {}}


func _load_config_with_backup(path: String) -> ConfigFile:
	var config := ConfigFile.new()
	if not FileAccess.file_exists(path):
		var backup_path := path + ".bak"
		if FileAccess.file_exists(backup_path):
			var backup_error := config.load(backup_path)
			if backup_error != OK:
				push_warning("SaveManager: backup could not be read: %s" % backup_path)
		return config

	var error := config.load(path)
	if error == OK:
		return config

	push_warning("SaveManager: save file could not be read; trying backup (%s)." % path)
	var fallback := ConfigFile.new()
	var fallback_error := fallback.load(path + ".bak")
	if fallback_error != OK:
		push_warning("SaveManager: no usable backup found for %s." % path)
	return fallback


func _atomic_save(config: ConfigFile, path: String) -> bool:
	var temporary_path := path + ".tmp"
	var backup_path := path + ".bak"
	var write_error := config.save(temporary_path)
	if write_error != OK:
		push_warning("SaveManager: temporary save failed (%s)." % str(write_error))
		return false

	var absolute_path := ProjectSettings.globalize_path(path)
	var absolute_temporary := ProjectSettings.globalize_path(temporary_path)
	var absolute_backup := ProjectSettings.globalize_path(backup_path)

	if FileAccess.file_exists(path):
		if FileAccess.file_exists(backup_path):
			DirAccess.remove_absolute(absolute_backup)
		var backup_error := DirAccess.rename_absolute(absolute_path, absolute_backup)
		if backup_error != OK:
			push_warning("SaveManager: could not rotate the previous save (%s)." % str(backup_error))
			DirAccess.remove_absolute(absolute_temporary)
			return false

	var commit_error := DirAccess.rename_absolute(absolute_temporary, absolute_path)
	if commit_error != OK:
		push_warning("SaveManager: could not commit the new save (%s)." % str(commit_error))
		if FileAccess.file_exists(backup_path):
			DirAccess.rename_absolute(absolute_backup, absolute_path)
		DirAccess.remove_absolute(absolute_temporary)
		return false

	return true
