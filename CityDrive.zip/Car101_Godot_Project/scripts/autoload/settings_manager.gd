extends Node

## Validates, persists, and applies player preferences.
signal settings_changed(settings: Dictionary)

const DEFAULT_SETTINGS: Dictionary = {
	"language": "fa",
	"quality": "balanced",
	"control_scheme": "auto",
	"master_volume": 0.85,
	"music_volume": 0.70,
	"sfx_volume": 0.85,
	"fullscreen": false
}

var _settings: Dictionary = {}


func _ready() -> void:
	_settings = DEFAULT_SETTINGS.duplicate(true)
	var saved_settings := SaveManager.load_settings()
	for key in DEFAULT_SETTINGS:
		if saved_settings.has(key):
			_settings[key] = _sanitize_value(key, saved_settings[key])
	_ensure_audio_bus("Music")
	_ensure_audio_bus("SFX")
	_apply_all()
	SaveManager.save_settings(_settings)


func get_setting(key: String, fallback: Variant = null) -> Variant:
	return _settings.get(key, fallback)


func get_all_settings() -> Dictionary:
	return _settings.duplicate(true)


func set_setting(key: String, value: Variant) -> bool:
	if not DEFAULT_SETTINGS.has(key):
		push_warning("SettingsManager: unknown setting '%s'." % key)
		return false

	var clean_value: Variant = _sanitize_value(key, value)
	_settings[key] = clean_value
	_apply_setting(key, clean_value)
	var saved := SaveManager.save_settings(_settings)
	settings_changed.emit(_settings.duplicate(true))
	return saved


func _sanitize_value(key: String, value: Variant) -> Variant:
	match key:
		"language":
			return value if value in ["fa", "en"] else DEFAULT_SETTINGS[key]
		"quality":
			return value if value in ["low", "balanced", "high"] else DEFAULT_SETTINGS[key]
		"control_scheme":
			return value if value in ["auto", "touch", "keyboard"] else DEFAULT_SETTINGS[key]
		"master_volume", "music_volume", "sfx_volume":
			if not (value is int or value is float):
				return DEFAULT_SETTINGS[key]
			return clampf(float(value), 0.0, 1.0)
		"fullscreen":
			return bool(value)
	return DEFAULT_SETTINGS.get(key)


func _apply_all() -> void:
	for key in _settings:
		_apply_setting(key, _settings[key])


func _apply_setting(key: String, value: Variant) -> void:
	match key:
		"language":
			TranslationServer.set_locale("fa" if value == "fa" else "en")
		"master_volume":
			_set_bus_volume("Master", float(value))
		"music_volume":
			_set_bus_volume("Music", float(value))
		"sfx_volume":
			_set_bus_volume("SFX", float(value))
		"fullscreen":
			_apply_fullscreen(bool(value))
		"quality", "control_scheme":
			# These preferences are consumed by the rendering and input modules
			# as those systems are introduced in the next development phases.
			pass


func _ensure_audio_bus(bus_name: String) -> int:
	var bus_index := AudioServer.get_bus_index(bus_name)
	if bus_index >= 0:
		return bus_index
	bus_index = AudioServer.bus_count
	AudioServer.add_bus(bus_index)
	AudioServer.set_bus_name(bus_index, bus_name)
	AudioServer.set_bus_send(bus_index, "Master")
	return bus_index


func _set_bus_volume(bus_name: String, linear_volume: float) -> void:
	var bus_index := AudioServer.get_bus_index(bus_name)
	if bus_index < 0:
		bus_index = _ensure_audio_bus(bus_name)
	AudioServer.set_bus_volume_linear(bus_index, clampf(linear_volume, 0.0, 1.0))


func _apply_fullscreen(enabled: bool) -> void:
	# Mobile devices already run in immersive/fullscreen mode.
	if OS.has_feature("mobile"):
		return
	var target_mode := DisplayServer.WINDOW_MODE_FULLSCREEN if enabled else DisplayServer.WINDOW_MODE_WINDOWED
	DisplayServer.window_set_mode(target_mode)
