extends Node

## Persistent vehicle ownership and upgrade economy for the city garage.
signal ownership_changed(vehicle_id: String)
signal upgrade_purchased(vehicle_id: String, upgrade_type: String, level: int)

const STARTING_CASH: int = 65000
const STARTER_VEHICLE_ID: String = "starter_sedan"
const UPGRADE_DEFINITIONS: Dictionary = {
	"engine": {
		"title": "قدرت موتور",
		"costs": [8000, 14000, 22000],
		"description": "افزایش شتاب و نیروی موتور"
	},
	"speed": {
		"title": "سرعت نهایی",
		"costs": [7000, 12000, 19000],
		"description": "افزایش حداکثر سرعت خودرو"
	},
	"handling": {
		"title": "فرمان‌پذیری",
		"costs": [5500, 9500, 15500],
		"description": "پاسخ بهتر فرمان در پیچ‌ها"
	}
}
const MAX_UPGRADE_LEVEL: int = 3


func _ready() -> void:
	_initialize_economy_profile()


func _initialize_economy_profile() -> void:
	if not bool(GameState.get_progress("vehicle_economy_initialized", false)):
		var owned: Array = [STARTER_VEHICLE_ID]
		GameState.set_progress("owned_vehicles", owned)
		GameState.set_progress("vehicle_upgrades", {})
		if GameState.money < STARTING_CASH:
			GameState.add_money(STARTING_CASH - GameState.money)
		GameState.set_progress("vehicle_economy_initialized", true)
		return

	var owned_value: Variant = GameState.get_progress("owned_vehicles", [])
	var owned_ids: Array = owned_value.duplicate(true) if owned_value is Array else []
	if not owned_ids.has(STARTER_VEHICLE_ID):
		owned_ids.append(STARTER_VEHICLE_ID)
		GameState.set_progress("owned_vehicles", owned_ids)


func is_vehicle_owned(vehicle_id: String) -> bool:
	var owned_value: Variant = GameState.get_progress("owned_vehicles", [STARTER_VEHICLE_ID])
	if not owned_value is Array:
		return vehicle_id == STARTER_VEHICLE_ID
	return owned_value.has(vehicle_id)


func purchase_vehicle(vehicle_id: String, price: int) -> bool:
	var clean_id := vehicle_id.strip_edges()
	if clean_id.is_empty() or price <= 0 or is_vehicle_owned(clean_id):
		return false
	if not GameState.spend_money(price):
		return false
	var owned_value: Variant = GameState.get_progress("owned_vehicles", [STARTER_VEHICLE_ID])
	var owned_ids: Array = owned_value.duplicate(true) if owned_value is Array else [STARTER_VEHICLE_ID]
	owned_ids.append(clean_id)
	GameState.set_progress("owned_vehicles", owned_ids)
	ownership_changed.emit(clean_id)
	return true


func get_owned_vehicle_ids() -> Array:
	var owned_value: Variant = GameState.get_progress("owned_vehicles", [STARTER_VEHICLE_ID])
	return owned_value.duplicate(true) if owned_value is Array else [STARTER_VEHICLE_ID]


func get_upgrade_level(vehicle_id: String, upgrade_type: String) -> int:
	var all_upgrades_value: Variant = GameState.get_progress("vehicle_upgrades", {})
	if not all_upgrades_value is Dictionary:
		return 0
	var vehicle_upgrades: Variant = all_upgrades_value.get(vehicle_id, {})
	if not vehicle_upgrades is Dictionary:
		return 0
	return clampi(int(vehicle_upgrades.get(upgrade_type, 0)), 0, MAX_UPGRADE_LEVEL)


func get_upgrade_cost(vehicle_id: String, upgrade_type: String) -> int:
	if not UPGRADE_DEFINITIONS.has(upgrade_type):
		return -1
	var level := get_upgrade_level(vehicle_id, upgrade_type)
	var costs: Array = UPGRADE_DEFINITIONS[upgrade_type]["costs"]
	if level >= costs.size():
		return -1
	return int(costs[level])


func get_upgrade_title(upgrade_type: String) -> String:
	if not UPGRADE_DEFINITIONS.has(upgrade_type):
		return "ارتقا"
	return str(UPGRADE_DEFINITIONS[upgrade_type]["title"])


func get_upgrade_description(upgrade_type: String) -> String:
	if not UPGRADE_DEFINITIONS.has(upgrade_type):
		return ""
	return str(UPGRADE_DEFINITIONS[upgrade_type]["description"])


func purchase_upgrade(vehicle: CarController, upgrade_type: String) -> bool:
	if vehicle == null or not is_instance_valid(vehicle):
		return false
	if not is_vehicle_owned(vehicle.vehicle_id) or not UPGRADE_DEFINITIONS.has(upgrade_type):
		return false
	var current_level := get_upgrade_level(vehicle.vehicle_id, upgrade_type)
	var price := get_upgrade_cost(vehicle.vehicle_id, upgrade_type)
	if price < 0 or not GameState.spend_money(price):
		return false

	var all_upgrades_value: Variant = GameState.get_progress("vehicle_upgrades", {})
	var all_upgrades: Dictionary = all_upgrades_value.duplicate(true) if all_upgrades_value is Dictionary else {}
	var vehicle_upgrades_value: Variant = all_upgrades.get(vehicle.vehicle_id, {})
	var vehicle_upgrades: Dictionary = vehicle_upgrades_value.duplicate(true) if vehicle_upgrades_value is Dictionary else {}
	vehicle_upgrades[upgrade_type] = current_level + 1
	all_upgrades[vehicle.vehicle_id] = vehicle_upgrades
	GameState.set_progress("vehicle_upgrades", all_upgrades)
	apply_upgrades(vehicle)
	upgrade_purchased.emit(vehicle.vehicle_id, upgrade_type, current_level + 1)
	return true


func apply_upgrades(vehicle: CarController) -> void:
	if vehicle == null or not is_instance_valid(vehicle):
		return
	var engine_level := get_upgrade_level(vehicle.vehicle_id, "engine")
	var speed_level := get_upgrade_level(vehicle.vehicle_id, "speed")
	var handling_level := get_upgrade_level(vehicle.vehicle_id, "handling")
	vehicle.apply_upgrade_levels(engine_level, speed_level, handling_level)
