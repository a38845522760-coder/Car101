extends CharacterBody3D
class_name PlayerCharacter

## Third-person civilian avatar. The mesh is procedural and lightweight so the
## on-foot feature works even before a rigged character asset is selected.

@export_range(2.0, 5.0, 0.1) var walk_speed: float = 3.2
@export_range(4.0, 8.0, 0.1) var run_speed: float = 5.4
@export_range(8.0, 28.0, 0.5) var movement_acceleration: float = 18.0

var camera_rig: Node3D
var _touch_inputs: Dictionary = {
	"walk_forward": false,
	"walk_backward": false,
	"walk_left": false,
	"walk_right": false,
	"sprint": false
}
var _animation_clock: float = 0.0
var _left_leg: MeshInstance3D
var _right_leg: MeshInstance3D
var _left_arm: MeshInstance3D
var _right_arm: MeshInstance3D
var _torso: MeshInstance3D


func _ready() -> void:
	collision_layer = 4
	collision_mask = 1
	floor_snap_length = 0.25
	floor_max_angle = deg_to_rad(48.0)
	_install_input_map()
	_build_visuals()
	set_physics_process(false)


func set_camera_rig(rig: Node3D) -> void:
	camera_rig = rig


func set_character_active(active: bool) -> void:
	set_physics_process(active)
	var collision_shape := get_node_or_null("CollisionShape3D") as CollisionShape3D
	if collision_shape != null:
		collision_shape.set_deferred("disabled", not active)
	if not active:
		velocity = Vector3.ZERO
		_clear_touch_inputs()


func set_touch_control(action_name: String, pressed: bool) -> void:
	if _touch_inputs.has(action_name):
		_touch_inputs[action_name] = pressed


func clear_touch_controls() -> void:
	_clear_touch_inputs()


func _physics_process(delta: float) -> void:
	var horizontal := Input.get_action_strength("walk_right") - Input.get_action_strength("walk_left")
	var vertical := Input.get_action_strength("walk_forward") - Input.get_action_strength("walk_backward")
	horizontal += (1.0 if bool(_touch_inputs["walk_right"]) else 0.0) - (1.0 if bool(_touch_inputs["walk_left"]) else 0.0)
	vertical += (1.0 if bool(_touch_inputs["walk_forward"]) else 0.0) - (1.0 if bool(_touch_inputs["walk_backward"]) else 0.0)
	var input_vector := Vector2(horizontal, vertical).limit_length(1.0)

	var move_direction := Vector3.ZERO
	if camera_rig != null and is_instance_valid(camera_rig):
		var camera_basis := camera_rig.global_basis
		var camera_forward := Vector3(-camera_basis.z.x, 0.0, -camera_basis.z.z).normalized()
		var camera_right := Vector3(camera_basis.x.x, 0.0, camera_basis.x.z).normalized()
		move_direction = (camera_right * input_vector.x + camera_forward * input_vector.y).normalized()
	else:
		move_direction = Vector3(input_vector.x, 0.0, input_vector.y).normalized()

	var sprinting := Input.is_action_pressed("walk_sprint") or bool(_touch_inputs["sprint"])
	var target_speed := run_speed if sprinting else walk_speed
	var desired_velocity := move_direction * target_speed
	velocity.x = move_toward(velocity.x, desired_velocity.x, movement_acceleration * delta)
	velocity.z = move_toward(velocity.z, desired_velocity.z, movement_acceleration * delta)

	if not is_on_floor():
		velocity.y -= float(ProjectSettings.get_setting("physics/3d/default_gravity", 9.8)) * delta
	else:
		velocity.y = 0.0

	move_and_slide()
	var actual_horizontal_speed := Vector2(velocity.x, velocity.z).length()
	_update_visual_animation(delta, actual_horizontal_speed > 0.12, sprinting)


func _update_visual_animation(delta: float, moving: bool, sprinting: bool) -> void:
	var animation_speed := 10.0 if sprinting else 7.4
	_animation_clock += delta * (animation_speed if moving else 2.0)
	var amplitude := 0.62 if sprinting else 0.42
	if not moving:
		amplitude = 0.025
	var swing := sin(_animation_clock) * amplitude
	_left_leg.rotation.x = swing
	_right_leg.rotation.x = -swing
	_left_arm.rotation.x = -swing * 0.72
	_right_arm.rotation.x = swing * 0.72
	_torso.position.y = 1.1 + (absf(sin(_animation_clock * 2.0)) * (0.045 if moving else 0.008))
	if moving:
		var facing := atan2(-velocity.x, -velocity.z)
		rotation.y = lerp_angle(rotation.y, facing, clampf(delta * 10.0, 0.0, 1.0))


func _build_visuals() -> void:
	var skin := _make_material(Color("#c58e70"))
	var shirt := _make_material(Color("#355f7d"))
	var trousers := _make_material(Color("#303b4d"))
	var shoes := _make_material(Color("#24282d"))
	var hair := _make_material(Color("#30261f"))

	_torso = MeshInstance3D.new()
	_torso.name = "Torso"
	var torso_mesh := CapsuleMesh.new()
	torso_mesh.radius = 0.27
	torso_mesh.height = 1.03
	_torso.mesh = torso_mesh
	_torso.position = Vector3(0.0, 1.1, 0.0)
	_torso.material_override = shirt
	add_child(_torso)

	var head := MeshInstance3D.new()
	head.name = "Head"
	var head_mesh := SphereMesh.new()
	head_mesh.radius = 0.18
	head_mesh.height = 0.36
	head.mesh = head_mesh
	head.position = Vector3(0.0, 1.86, -0.015)
	head.material_override = skin
	add_child(head)

	var hair_cap := MeshInstance3D.new()
	var hair_mesh := SphereMesh.new()
	hair_mesh.radius = 0.185
	hair_mesh.height = 0.18
	hair_cap.mesh = hair_mesh
	hair_cap.position = Vector3(0.0, 1.99, 0.015)
	hair_cap.material_override = hair
	add_child(hair_cap)

	_left_leg = _make_limb("LeftLeg", trousers, Vector3(-0.135, 0.48, 0.0), 0.78, 0.115)
	_right_leg = _make_limb("RightLeg", trousers, Vector3(0.135, 0.48, 0.0), 0.78, 0.115)
	_left_arm = _make_limb("LeftArm", shirt, Vector3(-0.34, 1.22, 0.0), 0.76, 0.095)
	_right_arm = _make_limb("RightArm", shirt, Vector3(0.34, 1.22, 0.0), 0.76, 0.095)

	# Shoes are children of their leg pivots so they follow the walk/run swing.
	var shoe_mesh := BoxMesh.new()
	shoe_mesh.size = Vector3(0.22, 0.13, 0.34)
	var left_shoe := MeshInstance3D.new()
	left_shoe.name = "LeftShoe"
	left_shoe.mesh = shoe_mesh
	left_shoe.material_override = shoes
	left_shoe.position = Vector3(0.0, -0.34, -0.055)
	_left_leg.add_child(left_shoe)
	var right_shoe := MeshInstance3D.new()
	right_shoe.name = "RightShoe"
	right_shoe.mesh = shoe_mesh
	right_shoe.material_override = shoes
	right_shoe.position = Vector3(0.0, -0.34, -0.055)
	_right_leg.add_child(right_shoe)


func _make_limb(node_name: String, material: Material, limb_position: Vector3, height: float, radius: float) -> MeshInstance3D:
	var limb := MeshInstance3D.new()
	limb.name = node_name
	var mesh := CapsuleMesh.new()
	mesh.radius = radius
	mesh.height = height
	limb.mesh = mesh
	limb.position = limb_position
	limb.material_override = material
	add_child(limb)
	return limb


func _make_material(color: Color) -> StandardMaterial3D:
	var material := StandardMaterial3D.new()
	material.albedo_color = color
	material.roughness = 0.84
	return material


func _clear_touch_inputs() -> void:
	for action_name in _touch_inputs.keys():
		_touch_inputs[action_name] = false


func _install_input_map() -> void:
	_add_action_keys("walk_forward", [KEY_W, KEY_UP])
	_add_action_keys("walk_backward", [KEY_S, KEY_DOWN])
	_add_action_keys("walk_left", [KEY_A, KEY_LEFT])
	_add_action_keys("walk_right", [KEY_D, KEY_RIGHT])
	_add_action_keys("walk_sprint", [KEY_SHIFT])


func _add_action_keys(action_name: String, key_codes: Array) -> void:
	if not InputMap.has_action(action_name):
		InputMap.add_action(action_name)
	for raw_key_code in key_codes:
		var key_code := int(raw_key_code)
		var already_bound := false
		for event in InputMap.action_get_events(action_name):
			if event is InputEventKey and event.physical_keycode == key_code:
				already_bound = true
				break
		if already_bound:
			continue
		var key_event := InputEventKey.new()
		key_event.physical_keycode = key_code
		key_event.keycode = key_code
		InputMap.action_add_event(action_name, key_event)
