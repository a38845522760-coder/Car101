extends Node3D
class_name TrafficManager

## Owns city civilian traffic and pedestrian population. Counts are deliberately
## capped for Android-class hardware and can be adjusted in traffic_config.json.

const TRAFFIC_VEHICLE_SCRIPT: Script = preload("res://scripts/traffic/traffic_vehicle.gd")
const PEDESTRIAN_SCRIPT: Script = preload("res://scripts/pedestrians/pedestrian_agent.gd")
const CONFIG_PATH: String = "res://data/worlds/traffic_config.json"

const ROUTE_INNER: Array[Vector3] = [
	Vector3(-146.5, 0.0, -141.5),
	Vector3(141.5, 0.0, -141.5),
	Vector3(141.5, 0.0, 146.5),
	Vector3(-146.5, 0.0, 146.5)
]
const ROUTE_OUTER: Array[Vector3] = [
	Vector3(-218.5, 0.0, -213.5),
	Vector3(213.5, 0.0, -213.5),
	Vector3(213.5, 0.0, 218.5),
	Vector3(-218.5, 0.0, 218.5)
]

var player_car: CarController
var signal_manager: Node
var _rng := RandomNumberGenerator.new()
var _vehicle_count: int = 12
var _pedestrian_count: int = 10
var _minimum_speed_mps: float = 8.0
var _maximum_speed_mps: float = 12.5
var _spawned_vehicles: int = 0
var _spawned_pedestrians: int = 0


func configure(traffic_signals: Node, player: CarController) -> void:
	signal_manager = traffic_signals
	player_car = player
	_load_config()
	_rng.seed = 10105
	_spawn_traffic_vehicles()
	_spawn_pedestrians()
	print("TrafficManager: %d civilian vehicles and %d pedestrians spawned." % [_spawned_vehicles, _spawned_pedestrians])


func get_vehicle_count() -> int:
	return _spawned_vehicles


func get_pedestrian_count() -> int:
	return _spawned_pedestrians


func _load_config() -> void:
	if not FileAccess.file_exists(CONFIG_PATH):
		return
	var file := FileAccess.open(CONFIG_PATH, FileAccess.READ)
	if file == null:
		return
	var parsed: Variant = JSON.parse_string(file.get_as_text())
	if parsed is Dictionary:
		_vehicle_count = clampi(int(parsed.get("vehicle_count", _vehicle_count)), 0, 18)
		_pedestrian_count = clampi(int(parsed.get("pedestrian_count", _pedestrian_count)), 0, 20)
		var speed_data: Variant = parsed.get("traffic_speed_mps", {})
		if speed_data is Dictionary:
			_minimum_speed_mps = clampf(float(speed_data.get("minimum", _minimum_speed_mps)), 3.0, 16.0)
			_maximum_speed_mps = clampf(float(speed_data.get("maximum", _maximum_speed_mps)), 3.0, 18.0)
		if _maximum_speed_mps < _minimum_speed_mps:
			_maximum_speed_mps = _minimum_speed_mps


func _spawn_traffic_vehicles() -> void:
	var routes: Array = [ROUTE_INNER, ROUTE_OUTER]
	var colors: Array[Color] = [
		Color("#426477"), Color("#75816e"), Color("#7f5143"), Color("#b3a48a"),
		Color("#38434d"), Color("#8e8f91"), Color("#6e6b83"), Color("#536f61")
	]
	for vehicle_index in range(_vehicle_count):
		var route_slot := vehicle_index % routes.size()
		var route: Array[Vector3] = ROUTE_INNER.duplicate() if route_slot == 0 else ROUTE_OUTER.duplicate()
		var vehicles_on_route := int(ceil(float(_vehicle_count - route_slot) / float(routes.size())))
		var slot_on_route := int(vehicle_index / routes.size())
		_spawn_vehicle_on_route(route, slot_on_route, vehicles_on_route, colors[vehicle_index % colors.size()])


func _spawn_vehicle_on_route(route: Array[Vector3], vehicle_index: int, vehicles_on_route: int, paint_color: Color) -> void:
	var route_length := 0.0
	for point_index in range(route.size()):
		route_length += route[point_index].distance_to(route[(point_index + 1) % route.size()])
	if route_length <= 0.1:
		return
	var spacing := route_length / float(maxi(vehicles_on_route, 1))
	var distance_along := fposmod(float(vehicle_index) * spacing + 13.0, route_length)
	var segment_index := 0
	while segment_index < route.size() - 1:
		var segment_length := route[segment_index].distance_to(route[(segment_index + 1) % route.size()])
		if distance_along <= segment_length:
			break
		distance_along -= segment_length
		segment_index += 1
	segment_index = mini(segment_index, route.size() - 1)
	var start_point := route[segment_index]
	var end_point := route[(segment_index + 1) % route.size()]
	var segment_length := maxf(start_point.distance_to(end_point), 0.01)
	var start_position := start_point.lerp(end_point, clampf(distance_along / segment_length, 0.0, 1.0))
	start_position.y = 0.12
	var direction := (end_point - start_point).normalized()
	var speed := _rng.randf_range(_minimum_speed_mps, _maximum_speed_mps)
	var vehicle := TRAFFIC_VEHICLE_SCRIPT.new() as CharacterBody3D
	vehicle.call("configure", route, (segment_index + 1) % route.size(), start_position, direction, speed, paint_color, signal_manager)
	vehicle.name = "TrafficVehicle_%02d" % vehicle_index
	add_child(vehicle)
	_spawned_vehicles += 1


func _spawn_pedestrians() -> void:
	var sidewalk_routes: Array[Array] = [
		[Vector3(-61.0, 0.04, -63.9), Vector3(61.0, 0.04, -63.9), Vector3(61.0, 0.04, -80.1), Vector3(-61.0, 0.04, -80.1)],
		[Vector3(-61.0, 0.04, 63.9), Vector3(61.0, 0.04, 63.9), Vector3(61.0, 0.04, 80.1), Vector3(-61.0, 0.04, 80.1)],
		[Vector3(-63.9, 0.04, -61.0), Vector3(-63.9, 0.04, 61.0), Vector3(-80.1, 0.04, 61.0), Vector3(-80.1, 0.04, -61.0)],
		[Vector3(63.9, 0.04, -61.0), Vector3(63.9, 0.04, 61.0), Vector3(80.1, 0.04, 61.0), Vector3(80.1, 0.04, -61.0)]
	]
	var shirts: Array[Color] = [Color("#47728a"), Color("#8b6750"), Color("#617b60"), Color("#79627d"), Color("#a18b55")]
	for pedestrian_index in range(_pedestrian_count):
		var route: Array[Vector3] = sidewalk_routes[pedestrian_index % sidewalk_routes.size()].duplicate()
		var segment := pedestrian_index % route.size()
		var next_segment := (segment + 1) % route.size()
		var start_position := route[segment].lerp(route[next_segment], float((pedestrian_index / 4) % 3 + 1) * 0.22)
		var pedestrian := PEDESTRIAN_SCRIPT.new() as Node3D
		pedestrian.call("configure", route, next_segment, start_position, shirts[pedestrian_index % shirts.size()])
		pedestrian.name = "Pedestrian_%02d" % pedestrian_index
		add_child(pedestrian)
		_spawned_pedestrians += 1
