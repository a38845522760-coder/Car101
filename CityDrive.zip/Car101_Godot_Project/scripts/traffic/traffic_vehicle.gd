extends CharacterBody3D
class_name TrafficVehicle

## Low-cost civilian traffic car. It follows a closed road loop, obeys timed
## signals, and slows when another vehicle or obstacle is detected ahead.

@export_range(5.0, 18.0, 0.25) var cruise_speed: float = 10.0
@export_range(4.0, 14.0, 0.25) var acceleration: float = 7.0

var _route_points: Array[Vector3] = []
var _target_index: int = 0
var _traffic_signals: Node
var _current_speed: float = 0.0
var _paint_color: Color = Color("#426477")
var _obstacle_check_timer: float = 0.0


func configure(
	route_points: Array[Vector3],
	target_index: int,
	spawn_position: Vector3,
	initial_direction: Vector3,
	speed_value: float,
	paint_color: Color,
	signal_manager: Node
) -> void:
	_route_points = route_points.duplicate()
	_target_index = target_index
	position = spawn_position
	_current_speed = speed_value * 0.72
	cruise_speed = speed_value
	_paint_color = paint_color
	_traffic_signals = signal_manager
	if initial_direction.length_squared() > 0.01:
		rotation.y = atan2(-initial_direction.x, -initial_direction.z)


func _ready() -> void:
	name = "TrafficVehicle"
	add_to_group("traffic_vehicles")
	collision_layer = 8
	collision_mask = 1 | 8 | 16
	floor_snap_length = 0.3
	floor_max_angle = deg_to_rad(50.0)
	_build_vehicle_visuals()


func _physics_process(delta: float) -> void:
	if _route_points.size() < 2:
		return
	var target := _route_points[_target_index]
	var to_target := target - global_position
	to_target.y = 0.0
	# Keep the current waypoint until the vehicle has actually crossed the junction.
	if to_target.length() < 2.2:
		_target_index = (_target_index + 1) % _route_points.size()
		target = _route_points[_target_index]
		to_target = target - global_position
		to_target.y = 0.0
	if to_target.length_squared() < 0.05:
		return

	var direction := to_target.normalized()
	var direction_axis := "horizontal" if absf(direction.x) >= absf(direction.z) else "vertical"
	var desired_speed := cruise_speed
	if _traffic_signals != null and is_instance_valid(_traffic_signals):
		if to_target.length() < 20.0 and bool(_traffic_signals.call("should_stop_for_red", target, direction_axis)):
			desired_speed = 0.0

	_obstacle_check_timer -= delta
	if _obstacle_check_timer <= 0.0:
		_obstacle_check_timer = 0.16
		var obstacle_distance := _get_obstacle_distance(direction, 10.0)
		if obstacle_distance >= 0.0:
			desired_speed = minf(desired_speed, maxf(0.0, (obstacle_distance - 3.2) * 1.35))

	_current_speed = move_toward(_current_speed, desired_speed, acceleration * delta)
	velocity.x = direction.x * _current_speed
	velocity.z = direction.z * _current_speed
	velocity.y = -0.45
	move_and_slide()
	if is_on_floor():
		velocity.y = 0.0
	var desired_yaw := atan2(-direction.x, -direction.z)
	rotation.y = lerp_angle(rotation.y, desired_yaw, clampf(delta * 4.2, 0.0, 1.0))


func _get_obstacle_distance(direction: Vector3, ray_length: float) -> float:
	var space_state := get_world_3d().direct_space_state
	var origin := global_position + Vector3.UP * 0.92
	var query := PhysicsRayQueryParameters3D.create(origin, origin + direction * ray_length)
	query.collision_mask = 1 | 8 | 16
	query.exclude = [get_rid()]
	var result := space_state.intersect_ray(query)
	if result.is_empty():
		return -1.0
	return origin.distance_to(result.get("position", origin))


func _build_vehicle_visuals() -> void:
	var body_material := _make_material(_paint_color, 0.42, 0.18)
	var roof_material := _make_material(_paint_color.darkened(0.18), 0.48, 0.12)
	var glass_material := _make_material(Color("#263a49"), 0.2, 0.1)
	var tire_material := _make_material(Color("#171b20"), 0.94)
	var rim_material := _make_material(Color("#a9b5bc"), 0.35, 0.72)
	var headlight_material := _make_material(Color("#fff0bd"), 0.24, 0.0, Color("#ffe7a6"), 1.2)
	var tail_material := _make_material(Color("#b63832"), 0.3, 0.0, Color("#c72f2a"), 0.7)

	_add_box("Body", Vector3(0.0, 0.62, 0.0), Vector3(1.82, 0.55, 3.62), body_material)
	_add_box("Cabin", Vector3(0.0, 1.02, -0.10), Vector3(1.48, 0.55, 1.82), roof_material)
	_add_box("Windshield", Vector3(0.0, 1.04, -1.02), Vector3(1.30, 0.38, 0.045), glass_material)
	_add_box("RearGlass", Vector3(0.0, 1.04, 0.84), Vector3(1.30, 0.38, 0.045), glass_material)
	_add_box("FrontBumper", Vector3(0.0, 0.43, -1.82), Vector3(1.8, 0.18, 0.14), rim_material)
	_add_box("RearBumper", Vector3(0.0, 0.43, 1.82), Vector3(1.8, 0.18, 0.14), rim_material)
	for side in [-1.0, 1.0]:
		_add_box("Headlight", Vector3(side * 0.62, 0.68, -1.84), Vector3(0.34, 0.16, 0.055), headlight_material)
		_add_box("Taillight", Vector3(side * 0.62, 0.70, 1.84), Vector3(0.32, 0.16, 0.055), tail_material)
		for axle_z in [-1.18, 1.18]:
			var wheel := MeshInstance3D.new()
			var wheel_mesh := CylinderMesh.new()
			wheel_mesh.top_radius = 0.34
			wheel_mesh.bottom_radius = 0.34
			wheel_mesh.height = 0.22
			wheel.mesh = wheel_mesh
			wheel.material_override = tire_material
			wheel.position = Vector3(side * 0.94, 0.36, axle_z)
			wheel.rotation.z = PI * 0.5
			add_child(wheel)
			var hub := MeshInstance3D.new()
			var hub_mesh := CylinderMesh.new()
			hub_mesh.top_radius = 0.15
			hub_mesh.bottom_radius = 0.15
			hub_mesh.height = 0.235
			hub.mesh = hub_mesh
			hub.material_override = rim_material
			hub.position = Vector3(side * 1.055, 0.36, axle_z)
			hub.rotation.z = PI * 0.5
			add_child(hub)

	var collision := CollisionShape3D.new()
	var box := BoxShape3D.new()
	box.size = Vector3(1.9, 1.25, 3.75)
	collision.shape = box
	collision.position.y = 0.66
	add_child(collision)


func _add_box(node_name: String, local_position: Vector3, size: Vector3, material: Material) -> void:
	var mesh_instance := MeshInstance3D.new()
	mesh_instance.name = node_name
	var box := BoxMesh.new()
	box.size = size
	box.material = material
	mesh_instance.mesh = box
	mesh_instance.position = local_position
	add_child(mesh_instance)


func _make_material(
	albedo: Color,
	roughness: float,
	metallic: float = 0.0,
	emission: Color = Color.BLACK,
	emission_energy: float = 0.0
) -> StandardMaterial3D:
	var material := StandardMaterial3D.new()
	material.albedo_color = albedo
	material.roughness = roughness
	material.metallic = metallic
	if emission_energy > 0.0:
		material.emission_enabled = true
		material.emission = emission
		material.emission_energy_multiplier = emission_energy
	return material
