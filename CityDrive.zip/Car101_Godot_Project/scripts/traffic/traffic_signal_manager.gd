extends Node3D
class_name TrafficSignalManager

## Lightweight timed traffic-light controller shared by civilian traffic and police.
## The city uses one simple two-phase cycle per junction to keep CPU usage low.

const CYCLE_SECONDS: float = 20.0
const HORIZONTAL_GREEN_SECONDS: float = 8.0
const HORIZONTAL_YELLOW_SECONDS: float = 2.0
const VERTICAL_GREEN_SECONDS: float = 8.0

var _elapsed: float = 0.0
var _signal_lights: Dictionary = {}
var _junction_offsets: Dictionary = {}


func _ready() -> void:
	for node in get_tree().get_nodes_in_group("traffic_signal_lights"):
		if not node is MeshInstance3D:
			continue
		var intersection := Vector2i(
				int(node.get_meta("intersection_x", 0)),
				int(node.get_meta("intersection_z", 0))
			)
		var light_index := int(node.get_meta("light_index", 0))
		var axis_name := str(node.get_meta("direction_axis", "horizontal"))
		if not _signal_lights.has(intersection):
			_signal_lights[intersection] = {}
			_junction_offsets[intersection] = float(posmod(intersection.x * 31 + intersection.y * 17, 5)) * 1.15
		if not _signal_lights[intersection].has(axis_name):
			_signal_lights[intersection][axis_name] = {}
		_signal_lights[intersection][axis_name][light_index] = node
	_update_visual_signals()


func _process(delta: float) -> void:
	_elapsed = fposmod(_elapsed + delta, CYCLE_SECONDS)
	_update_visual_signals()


func is_green_for(world_position: Vector3, direction_axis: String) -> bool:
	var intersection := _find_nearest_intersection(world_position)
	if intersection == Vector2i(999999, 999999):
		return true
	var phase := _get_phase(intersection)
	if direction_axis == "horizontal":
		return phase < HORIZONTAL_GREEN_SECONDS
	return phase >= HORIZONTAL_GREEN_SECONDS + HORIZONTAL_YELLOW_SECONDS \
		and phase < HORIZONTAL_GREEN_SECONDS + HORIZONTAL_YELLOW_SECONDS + VERTICAL_GREEN_SECONDS


func is_within_intersection(world_position: Vector3) -> bool:
	return _find_nearest_intersection(world_position) != Vector2i(999999, 999999)


func get_nearest_intersection(world_position: Vector3) -> Vector2i:
	return _find_nearest_intersection(world_position)


func should_stop_for_red(target_position: Vector3, direction_axis: String) -> bool:
	var intersection := _find_nearest_intersection(target_position)
	if intersection == Vector2i(999999, 999999):
		return false
	return not is_green_for(target_position, direction_axis)


func _find_nearest_intersection(world_position: Vector3) -> Vector2i:
	var nearest := Vector2i(999999, 999999)
	var nearest_distance := 8.0
	for x_value in [-144, 0, 144]:
		for z_value in [-144, 0, 144]:
			var distance := Vector2(world_position.x - float(x_value), world_position.z - float(z_value)).length()
			if distance < nearest_distance:
				nearest_distance = distance
				nearest = Vector2i(x_value, z_value)
	return nearest


func _get_phase(intersection: Vector2i) -> float:
	var offset := float(_junction_offsets.get(intersection, 0.0))
	return fposmod(_elapsed + offset, CYCLE_SECONDS)


func _update_visual_signals() -> void:
	for intersection_variant in _signal_lights.keys():
		var intersection: Vector2i = intersection_variant
		var phase := _get_phase(intersection)
		var active_index := 0
		if phase < HORIZONTAL_GREEN_SECONDS:
			active_index = 2
		elif phase < HORIZONTAL_GREEN_SECONDS + HORIZONTAL_YELLOW_SECONDS:
			active_index = 1
		else:
			active_index = 0
		var signal_heads: Dictionary = _signal_lights[intersection]
		for axis_variant in signal_heads.keys():
			var axis_name := str(axis_variant)
			var head_lights: Dictionary = signal_heads[axis_variant]
			var axis_active_index := active_index
			if axis_name == "vertical":
				if phase < HORIZONTAL_GREEN_SECONDS + HORIZONTAL_YELLOW_SECONDS:
					axis_active_index = 0
				elif phase < HORIZONTAL_GREEN_SECONDS + HORIZONTAL_YELLOW_SECONDS + VERTICAL_GREEN_SECONDS:
					axis_active_index = 2
				else:
					axis_active_index = 1 if phase < CYCLE_SECONDS else 0
			for light_index_variant in head_lights.keys():
				var light_index := int(light_index_variant)
				var light := head_lights[light_index] as MeshInstance3D
				if is_instance_valid(light):
					light.visible = light_index == axis_active_index
