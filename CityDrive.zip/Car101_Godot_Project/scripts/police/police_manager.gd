extends Node
class_name PoliceManager

## Manages arcade-style driving violations, wanted level and police dispatch.
## Enforcement is a fictional game mechanic: no weapons or harmful combat logic.

const POLICE_VEHICLE_SCRIPT: Script = preload("res://scripts/police/police_vehicle_ai.gd")
const LAW_CONFIG_PATH: String = "res://data/worlds/law_config.json"
const ROAD_GRID: Array[float] = [-216.0, -144.0, -72.0, 0.0, 72.0, 144.0, 216.0]

var player_car: CarController
var character: PlayerCharacter
var interaction_manager: Node
var traffic_signal_manager: Node
var wanted_level: int = 0
var _speeding_timer: float = 0.0
var _violation_cooldown: float = 0.0
var _red_light_cooldown: float = 0.0
var _restricted_was_active: bool = false
var _stopped_near_police_timer: float = 0.0
var _notice_timer: float = 0.0
var _notice_message: String = ""
var _law_config: Dictionary = {}
var _police_vehicle: CharacterBody3D
var _last_speed_limit: int = 60
var _pending_fine_base: int = -1


func _ready() -> void:
	_load_law_config()


func configure(car: CarController, avatar: PlayerCharacter, interaction: Node, signals: Node = null) -> void:
	player_car = car
	character = avatar
	interaction_manager = interaction
	traffic_signal_manager = signals


func set_active_vehicle(vehicle: CarController) -> void:
	if vehicle != null and is_instance_valid(vehicle):
		player_car = vehicle


func _process(delta: float) -> void:
	_violation_cooldown = maxf(0.0, _violation_cooldown - delta)
	_red_light_cooldown = maxf(0.0, _red_light_cooldown - delta)
	_notice_timer = maxf(0.0, _notice_timer - delta)
	var target := _get_player_target()
	if target == null:
		return
	var player_position := target.global_position
	var is_driving := _is_driving()
	var speed := player_car.get_speed_kmh() if is_driving and player_car != null else _get_character_speed_kmh()
	_last_speed_limit = get_speed_limit_kmh(player_position)

	var speeding_margin := float(_law_config.get("speeding_threshold_over_limit_kmh", 10))
	var speeding_hold := float(_law_config.get("speeding_hold_seconds", 2.0))
	var speeding_cooldown := float(_law_config.get("violation_cooldown_seconds", 9.0))
	if is_driving and speed > float(_last_speed_limit) + speeding_margin:
		_speeding_timer += delta
		if _speeding_timer >= speeding_hold and _violation_cooldown <= 0.0:
			_register_violation(1, "سرعت غیرمجاز؛ پلیس در حال اعزام است")
			_violation_cooldown = speeding_cooldown
			_speeding_timer = 0.0
	else:
		_speeding_timer = maxf(0.0, _speeding_timer - delta * 1.8)

	if is_driving and _red_light_cooldown <= 0.0 and traffic_signal_manager != null and is_instance_valid(traffic_signal_manager):
		var velocity := player_car.linear_velocity
		var travel_axis := "horizontal" if absf(velocity.x) >= absf(velocity.z) else "vertical"
		if speed > 8.0 and bool(traffic_signal_manager.call("is_within_intersection", player_position)):
			if not bool(traffic_signal_manager.call("is_green_for", player_position, travel_axis)):
				_register_violation(1, "عبور از چراغ قرمز؛ پلیس در حال تعقیب است")
				_red_light_cooldown = 9.0

	var restricted_active := _is_inside_restricted_area(player_position)
	if restricted_active and not _restricted_was_active:
		_register_violation(
			_get_restricted_zone_stars(player_position),
			"ورود به محوطه ممنوع؛ پلیس اعزام شد",
			_get_restricted_zone_fine_base(player_position)
		)
	_restricted_was_active = restricted_active

	if wanted_level > 0:
		_ensure_police_vehicle(target)
		_update_interception(target, speed, delta)
	elif _police_vehicle != null and is_instance_valid(_police_vehicle):
		_police_vehicle.queue_free()
		_police_vehicle = null


func get_speed_limit_kmh(world_position: Vector3) -> int:
	var limits: Dictionary = _law_config.get("speed_limits_kmh", {})
	var district := "urban"
	if world_position.x < -72.0:
		district = "residential"
	elif world_position.x > 72.0:
		district = "industrial"
	elif absf(world_position.x) <= 72.0 and absf(world_position.z) <= 72.0:
		district = "downtown"
	return int(limits.get(district, 60))


func get_wanted_level() -> int:
	return wanted_level


func get_current_speed_limit_kmh() -> int:
	var target := _get_player_target()
	return _last_speed_limit if target == null else get_speed_limit_kmh(target.global_position)


func get_notice_message() -> String:
	if _notice_timer > 0.0:
		return _notice_message
	if wanted_level > 0:
		return "پلیس در تعقیب شماست"
	return ""


func is_pursuit_active() -> bool:
	return wanted_level > 0 and _police_vehicle != null and is_instance_valid(_police_vehicle)


func _register_violation(stars: int, message: String, fine_base_override: int = -1) -> void:
	wanted_level = clampi(wanted_level + stars, 1, 3)
	if fine_base_override > 0:
		_pending_fine_base = maxi(_pending_fine_base, fine_base_override)
	_notice_message = message
	_notice_timer = 5.0
	_stopped_near_police_timer = 0.0
	if _police_vehicle != null and is_instance_valid(_police_vehicle):
		_police_vehicle.set("maximum_speed", 15.0 + float(wanted_level - 1) * 1.5)
	print("Car101 law enforcement: wanted level %d." % wanted_level)


func _ensure_police_vehicle(target: Node3D) -> void:
	if _police_vehicle != null and is_instance_valid(_police_vehicle):
		_police_vehicle.call("set_target", target)
		return
	var spawn_position := _choose_police_spawn(target.global_position)
	var police := POLICE_VEHICLE_SCRIPT.new() as CharacterBody3D
	police.set("maximum_speed", 15.0 + float(wanted_level - 1) * 1.5)
	police.call("configure", target, spawn_position)
	police.name = "PoliceDispatchVehicle"
	get_parent().add_child(police)
	_police_vehicle = police


func _choose_police_spawn(target_position: Vector3) -> Vector3:
	var best_position := Vector3(target_position.x - 42.0, 0.0, target_position.z)
	var best_score := INF
	for x_value in ROAD_GRID:
		for z_value in ROAD_GRID:
			var candidate := Vector3(x_value, 0.0, z_value)
			var distance := candidate.distance_to(target_position)
			if distance < 42.0 or distance > 125.0:
				continue
			var score := absf(distance - 78.0)
			if score < best_score:
				best_score = score
				best_position = candidate
	return best_position


func _update_interception(target: Node3D, player_speed_kmh: float, delta: float) -> void:
	if _police_vehicle == null or not is_instance_valid(_police_vehicle):
		return
	var distance := _police_vehicle.global_position.distance_to(target.global_position)
	var stop_radius := float(_law_config.get("interception_stop_radius_m", 8.0))
	var stop_hold := float(_law_config.get("interception_hold_seconds", 2.5))
	var player_is_stopped := player_speed_kmh < 4.0
	if distance <= stop_radius and player_is_stopped:
		_stopped_near_police_timer += delta
		if _stopped_near_police_timer >= stop_hold:
			_resolve_fine()
	else:
		_stopped_near_police_timer = 0.0


func _resolve_fine() -> void:
	var fine_base := _pending_fine_base if _pending_fine_base > 0 else int(_law_config.get("fine_base", 250))
	var fine_per_star := int(_law_config.get("fine_per_wanted_star", 350))
	var fine := fine_base + wanted_level * fine_per_star
	var existing_debt := maxi(0, int(GameState.get_progress("unpaid_fines", 0)))
	var total_due := existing_debt + fine
	if GameState.spend_money(total_due):
		GameState.set_progress("unpaid_fines", 0)
		_notice_message = "توقف پلیس؛ %d سکه جریمه و بدهی پرداخت شد" % total_due
		_notice_timer = 6.0
	else:
		GameState.set_progress("unpaid_fines", total_due)
		GameState.add_score(-25 * wanted_level)
		_notice_message = "توقف پلیس؛ %d سکه به بدهی اضافه شد" % fine
		_notice_timer = 6.0
	wanted_level = 0
	_pending_fine_base = -1
	_stopped_near_police_timer = 0.0
	_speeding_timer = 0.0
	_red_light_cooldown = 4.0
	_restricted_was_active = _is_inside_restricted_area(_get_player_target().global_position) if _get_player_target() != null else false
	if _police_vehicle != null and is_instance_valid(_police_vehicle):
		_police_vehicle.queue_free()
	_police_vehicle = null


func _get_player_target() -> Node3D:
	if _is_driving():
		return player_car
	return character


func _is_driving() -> bool:
	return interaction_manager == null or not is_instance_valid(interaction_manager) or bool(interaction_manager.get("is_driving"))


func _get_character_speed_kmh() -> float:
	if character == null or not is_instance_valid(character):
		return 0.0
	return Vector2(character.velocity.x, character.velocity.z).length() * 3.6


func _get_restricted_zone_stars(world_position: Vector3) -> int:
	var zones: Array = _law_config.get("restricted_zones", [])
	for zone_variant in zones:
		if not zone_variant is Dictionary:
			continue
		var zone: Dictionary = zone_variant
		var center_data: Array = zone.get("center_xz", [180.0, 180.0])
		var size_data: Array = zone.get("size_xz", [51.0, 51.0])
		if center_data.size() < 2 or size_data.size() < 2:
			continue
		var half_x := float(size_data[0]) * 0.5
		var half_z := float(size_data[1]) * 0.5
		if absf(world_position.x - float(center_data[0])) <= half_x and absf(world_position.z - float(center_data[1])) <= half_z:
			return clampi(int(zone.get("wanted_stars", 2)), 1, 3)
	return 1


func _get_restricted_zone_fine_base(world_position: Vector3) -> int:
	var zones: Array = _law_config.get("restricted_zones", [])
	for zone_variant in zones:
		if not zone_variant is Dictionary:
			continue
		var zone: Dictionary = zone_variant
		var center_data: Array = zone.get("center_xz", [180.0, 180.0])
		var size_data: Array = zone.get("size_xz", [51.0, 51.0])
		if center_data.size() < 2 or size_data.size() < 2:
			continue
		var half_x := float(size_data[0]) * 0.5
		var half_z := float(size_data[1]) * 0.5
		if absf(world_position.x - float(center_data[0])) <= half_x and absf(world_position.z - float(center_data[1])) <= half_z:
			return maxi(0, int(zone.get("fine_base", _law_config.get("fine_base", 250))))
	return int(_law_config.get("fine_base", 250))


func _is_inside_restricted_area(world_position: Vector3) -> bool:
	var zones: Array = _law_config.get("restricted_zones", [])
	for zone_variant in zones:
		if not zone_variant is Dictionary:
			continue
		var zone: Dictionary = zone_variant
		var center_data: Array = zone.get("center_xz", [180.0, 180.0])
		var size_data: Array = zone.get("size_xz", [51.0, 51.0])
		if center_data.size() < 2 or size_data.size() < 2:
			continue
		var half_x := float(size_data[0]) * 0.5
		var half_z := float(size_data[1]) * 0.5
		if absf(world_position.x - float(center_data[0])) <= half_x and absf(world_position.z - float(center_data[1])) <= half_z:
			return true
	return false


func _load_law_config() -> void:
	if not FileAccess.file_exists(LAW_CONFIG_PATH):
		return
	var file := FileAccess.open(LAW_CONFIG_PATH, FileAccess.READ)
	if file == null:
		return
	var parsed: Variant = JSON.parse_string(file.get_as_text())
	if parsed is Dictionary:
		_law_config = parsed
