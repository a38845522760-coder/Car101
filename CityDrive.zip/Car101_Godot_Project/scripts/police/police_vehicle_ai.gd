extends CharacterBody3D
class_name PoliceVehicleAI

## Non-lethal arcade pursuit vehicle. It follows the city's road grid and stops
## near the player to allow the enforcement manager to resolve the incident.

const ROAD_GRID: Array[float] = [-216.0, -144.0, -72.0, 0.0, 72.0, 144.0, 216.0]

var target: Node3D
var _waypoints: Array[Vector3] = []
var _waypoint_index: int = 0
var _replan_timer: float = 0.0
var _current_speed: float = 0.0
var _siren_clock: float = 0.0
var _red_light: MeshInstance3D
var _blue_light: MeshInstance3D
var maximum_speed: float = 15.0


func configure(target_node: Node3D, spawn_position: Vector3) -> void:
	target = target_node
	position = spawn_position + Vector3(0.0, 0.12, 0.0)


func set_target(target_node: Node3D) -> void:
	if target != target_node:
		target = target_node
		_replan_timer = 0.0


func _ready() -> void:
	name = "PolicePursuitVehicle"
	add_to_group("police_units")
	collision_layer = 16
	collision_mask = 1 | 4 | 8
	floor_snap_length = 0.3
	_build_police_visuals()


func _physics_process(delta: float) -> void:
	if target == null or not is_instance_valid(target):
		velocity = Vector3.ZERO
		_current_speed = move_toward(_current_speed, 0.0, 12.0 * delta)
		move_and_slide()
		return
	_replan_timer -= delta
	if _replan_timer <= 0.0 or _waypoints.is_empty():
		_replan_route()
		_replan_timer = 1.5

	var target_distance := Vector2(global_position.x - target.global_position.x, global_position.z - target.global_position.z).length()
	var desired_speed := maximum_speed
	if target_distance < 7.0:
		desired_speed = 0.0
	elif _waypoint_index < _waypoints.size():
		var waypoint_distance := Vector2(global_position.x - _waypoints[_waypoint_index].x, global_position.z - _waypoints[_waypoint_index].z).length()
		if waypoint_distance < 5.0:
			_waypoint_index += 1
	var destination := target.global_position
	if _waypoint_index < _waypoints.size():
		destination = _waypoints[_waypoint_index]
	var direction := destination - global_position
	direction.y = 0.0
	if direction.length_squared() > 0.05:
		direction = direction.normalized()
		_current_speed = move_toward(_current_speed, desired_speed, 8.5 * delta)
		velocity.x = direction.x * _current_speed
		velocity.z = direction.z * _current_speed
		rotation.y = lerp_angle(rotation.y, atan2(-direction.x, -direction.z), clampf(delta * 3.6, 0.0, 1.0))
	else:
		_current_speed = move_toward(_current_speed, 0.0, 10.0 * delta)
		velocity.x = 0.0
		velocity.z = 0.0
	velocity.y = -0.45
	move_and_slide()
	if is_on_floor():
		velocity.y = 0.0
	_update_siren(delta)


func _replan_route() -> void:
	_waypoints.clear()
	_waypoint_index = 0
	if target == null or not is_instance_valid(target):
		return
	var start_x := _nearest_grid_index(global_position.x)
	var start_z := _nearest_grid_index(global_position.z)
	var end_x := _nearest_grid_index(target.global_position.x)
	var end_z := _nearest_grid_index(target.global_position.z)
	var current_x := start_x
	var current_z := start_z
	if global_position.distance_to(Vector3(ROAD_GRID[start_x], 0.0, ROAD_GRID[start_z])) > 4.0:
		_waypoints.append(Vector3(ROAD_GRID[start_x], 0.0, ROAD_GRID[start_z]))
	while current_x != end_x:
		current_x += 1 if end_x > current_x else -1
		_waypoints.append(Vector3(ROAD_GRID[current_x], 0.0, ROAD_GRID[current_z]))
	while current_z != end_z:
		current_z += 1 if end_z > current_z else -1
		_waypoints.append(Vector3(ROAD_GRID[current_x], 0.0, ROAD_GRID[current_z]))
	# The final short approach is only used after the road-grid route reaches the
	# nearest street junction; it lets officers approach a parked car or walker.
	_waypoints.append(target.global_position)


func _nearest_grid_index(value: float) -> int:
	var best_index := 0
	var best_distance := INF
	for index in range(ROAD_GRID.size()):
		var distance := absf(value - ROAD_GRID[index])
		if distance < best_distance:
			best_distance = distance
			best_index = index
	return best_index


func _update_siren(delta: float) -> void:
	_siren_clock += delta
	var red_active := fposmod(_siren_clock, 0.48) < 0.24
	if _red_light != null:
		_red_light.visible = red_active
	if _blue_light != null:
		_blue_light.visible = not red_active


func _build_police_visuals() -> void:
	var body_material := _make_material(Color("#f1f2f3"), 0.42)
	var dark_material := _make_material(Color("#202c3b"), 0.45)
	var glass_material := _make_material(Color("#283f54"), 0.2)
	var tire_material := _make_material(Color("#171b20"), 0.9)
	var metal_material := _make_material(Color("#b8c0c7"), 0.35, 0.6)
	var red_material := _make_material(Color("#e1393e"), 0.25, 0.0, Color("#ff2028"), 2.4)
	var blue_material := _make_material(Color("#2c73ec"), 0.25, 0.0, Color("#246cff"), 2.4)
	_add_box("Body", Vector3(0.0, 0.62, 0.0), Vector3(1.9, 0.56, 3.8), body_material)
	_add_box("Hood", Vector3(0.0, 0.77, -1.15), Vector3(1.82, 0.16, 1.15), body_material)
	_add_box("Cabin", Vector3(0.0, 1.04, 0.05), Vector3(1.48, 0.52, 1.85), dark_material)
	_add_box("Windshield", Vector3(0.0, 1.06, -0.91), Vector3(1.28, 0.36, 0.04), glass_material)
	_add_box("RearGlass", Vector3(0.0, 1.06, 0.96), Vector3(1.28, 0.36, 0.04), glass_material)
	_add_box("DoorStripe", Vector3(0.0, 0.72, -0.08), Vector3(1.93, 0.16, 1.65), dark_material)
	_add_box("FrontBumper", Vector3(0.0, 0.43, -1.91), Vector3(1.9, 0.18, 0.14), metal_material)
	for side in [-1.0, 1.0]:
		for axle_z in [-1.22, 1.22]:
			var wheel := MeshInstance3D.new()
			var cylinder := CylinderMesh.new()
			cylinder.top_radius = 0.34
			cylinder.bottom_radius = 0.34
			cylinder.height = 0.23
			wheel.mesh = cylinder
			wheel.material_override = tire_material
			wheel.position = Vector3(side * 0.98, 0.36, axle_z)
			wheel.rotation.z = PI * 0.5
			add_child(wheel)
	_red_light = _add_box("RedSiren", Vector3(-0.32, 1.38, 0.0), Vector3(0.42, 0.14, 0.25), red_material)
	_blue_light = _add_box("BlueSiren", Vector3(0.32, 1.38, 0.0), Vector3(0.42, 0.14, 0.25), blue_material)
	var collision := CollisionShape3D.new()
	var box := BoxShape3D.new()
	box.size = Vector3(2.0, 1.25, 3.9)
	collision.shape = box
	collision.position.y = 0.66
	add_child(collision)


func _add_box(node_name: String, local_position: Vector3, size: Vector3, material: Material) -> MeshInstance3D:
	var mesh_instance := MeshInstance3D.new()
	mesh_instance.name = node_name
	var box := BoxMesh.new()
	box.size = size
	box.material = material
	mesh_instance.mesh = box
	mesh_instance.position = local_position
	add_child(mesh_instance)
	return mesh_instance


func _make_material(color: Color, roughness: float, metallic: float = 0.0, emission: Color = Color.BLACK, emission_energy: float = 0.0) -> StandardMaterial3D:
	var material := StandardMaterial3D.new()
	material.albedo_color = color
	material.roughness = roughness
	material.metallic = metallic
	if emission_energy > 0.0:
		material.emission_enabled = true
		material.emission = emission
		material.emission_energy_multiplier = emission_energy
	return material
